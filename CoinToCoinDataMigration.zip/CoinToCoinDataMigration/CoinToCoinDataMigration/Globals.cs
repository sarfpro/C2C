using System;
using System.Data;
using HolisticFS.HSDB;
using System.Text.RegularExpressions;
using System.Collections.Specialized;
using System.IO;
using System.Collections;
using System.Text;
using System.Collections.Generic;
using CommonUtility;

namespace CoinToCoinDataMigration
{
	/// <summary>
	/// Summary description for Globals.
	/// </summary>
	public class Globals
	{
		public static HSDBCommProvider commProvider;
		public static DataSet dsCoinGlobals, dsCoinByClient,dsCoinByAdviser;
	    public static bool ZipFileAttachments = false;
        public static bool ProductsInHolding = true;
        public static bool ServiceInSM = true;
        public static bool IncludeDatafeedHoldings = false;
        public static string SavePath = "";
        public static string CoinVersion = "";
        public static List<string> ProductInHoldingList = new List<string>();
        public static List<string> ServiceInSMList = new List<string>();
        public static Dictionary<string, string> ClientFeeAttachmentList = new Dictionary<string, string>();
        public static Dictionary<string, string> ClientFeeNoteList = new Dictionary<string, string>();
        public static Dictionary<string, string> IncludedDatafeedList = new Dictionary<string, string>();

        public static bool IncludeDeletedEG = false;

        public static string NotesTextConverter(string note)
        {
            #region Usage
            // (ccc) = Comma
            // (nnn) = New Line
            // Use Script To Correct once in Coin "\\co00162in\Scripts\TextFieldFixer.sql"
            #endregion
            string result;
            if (!string.IsNullOrEmpty(note))
            {              
                result = Regex.Replace(note.Replace(",", "(ccc)"), @"\r\n|[\r\n]", "(nnn)");
                //removed this special space, it turns to be a '?' mark in word 
                result = result.Replace(char.ConvertFromUtf32(160), "");
                //result = result.Replace(char.ConvertFromUtf32(32), " ");  
                return result.Trim();
            }
            else
                return "";
        }

        public static string NotesTextConverter(object note)
        {
            #region Usage
            // (ccc) = Comma
            // (nnn) = New Line
            // Use Script To Correct once in Coin "\\co00162in\Scripts\TextFieldFixer.sql"
            #endregion
            string result;

            if (!string.IsNullOrEmpty(note.ToString()))
            {
                result = Regex.Replace(note.ToString().Replace(",", "(ccc)"), @"\r\n|[\r\n]", "(nnn)");
                //removed this special space, it turns to be a '?' mark in word 
                result = result.Replace(char.ConvertFromUtf32(160), "");
                //result = result.Replace(char.ConvertFromUtf32(32), " ");    
                if (result.Length > 8000)
                    return result.Substring(0, 8000).Trim();
                else
                    return result.Trim();
            }
            else
                return "";
        }


		public static string Clean(object word)
		{
			if (word == null)
				return "";
			else
			{
				string result = Regex.Replace(word.ToString(), "\r\n|[\\r\\n,\\\"]", "", RegexOptions.Compiled);
                //removed this special space, it turns to be a '?' mark in word 
                result = result.Replace(char.ConvertFromUtf32(160), "");    
                //result = result.Replace(char.ConvertFromUtf32(32), " ");
                return result.Trim();
			}
		}

		static SortedList CoinSetupList = new SortedList();
		static StringCollection Setup = new StringCollection();
        
		public static void AddToSetup(string value)
		{
			string upperValue = value.ToUpper();
			if(!Setup.Contains(upperValue))
			{
                CoinSetupList.Add(value, null);
				Setup.Add(upperValue);
			}
		}

		public static void WriteSetupFileToText(string exportLocation)
		{
			using(StreamWriter sw = new StreamWriter(Path.Combine(exportLocation,"CoinSetup.txt"),false))
			{
				StringCollection cat = new StringCollection();
				StringCollection catVal = new StringCollection();

                for (int i = 0; i < CoinSetupList.Count; i++)
				{
                    string record = CoinSetupList.GetKey(i).ToString();
					
					string[] values = record.Split('|');
					if(values != null)
					{
						if(values.Length >= 2)
						{
							if(!cat.Contains(values[0].ToUpper()))
							{
								sw.WriteLine("\r\n\r\n"+values[0]+"\r\n--------------------------------------\r\n");
								cat.Add(values[0].ToUpper());
							}
							if(!catVal.Contains(record.ToUpper()))
							{
								if(values.Length == 3)
									sw.WriteLine(values[1] +"|"+ values[2]);
								else
									sw.WriteLine(values[1]);
								catVal.Add(record.ToUpper());
							}
						}
					}
				
				}
			}
		}

        public static void WriteSetupFileToXML(string exportLocation)
        {
            try
            {
                CoinSetup.WriteSetupFileToXML(exportLocation, CoinSetupList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static string GetDateString(object date)
        {
            string result = "";
            DateTime testDate;
            if ((date != null) && (date.ToString().Length > 0))
            {
                DateTime.TryParse(date.ToString(), out testDate);
                if (testDate > DateTime.MinValue)
                    result = testDate.ToString("yyyy-MM-dd HH:mm:ss");
            }
            return result;
        }
	}
}
