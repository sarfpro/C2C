using System;
using System.Data;

namespace CoinToCoinDataMigration.DataModule
{
	public class ClientEstateHandler:ITableHandler
	{
		public ClientEstateHandler()
		{
			this.Description = "Estates and Wills";
			this.Code = "EW";
			this.DataRelated = DataRelatedEnum.Client;
		}

		public override void Import() 
		{
			DataTable dt = InitTable();
			string clientID = "'" + this.Importer.CurrentClient.ToString() + "'";

			string filter = "ClientID =" + clientID;
			WillExecutor ClientWe,SpouseWe;
			ClientWe = GetOneWillExecutor(clientID,"CLI");
			SpouseWe = GetOneWillExecutor(clientID,"SPS");
			PoA ClientPoA,SpousePoA;
			ClientPoA = GetOnePoA(clientID,"CLI");
			SpousePoA = GetOnePoA(clientID,"SPS");

			foreach(DataRow row in Globals.dsCoinByClient.Tables["ClientEstates"].Select(filter))
			{
				dt.Rows[0]["GroupID"] = row["ClientID"];
				dt.Rows[0]["GroupEstateNotes"] = Globals.NotesTextConverter(row["Notes"].ToString());
				dt.Rows[0]["ClientWillExists"] = (row["CWillExists"] != DBNull.Value ? ((bool)row["CWillExists"]?1:0 ):0);
				dt.Rows[0]["ClientWillCurrent"] =(row["CWillCurrent"] != DBNull.Value ? ((bool)row["CWillCurrent"]?1:0 ):0);
				dt.Rows[0]["ClientWillDate"] = Globals.GetDateString(row["CWillDate"]);
				dt.Rows[0]["ClientWillLocation"] = Globals.Clean(row["CWillLocation"]);
				dt.Rows[0]["ClientTestamentryTrust"] =(row["CTestTru"] != DBNull.Value ? ((bool)row["CTestTru"]?1:0 ):0);
				dt.Rows[0]["ClientExecutorFirstName"] =ClientWe.FirstName;
				dt.Rows[0]["ClientExecutorLastName"] = ClientWe.Surname;
				dt.Rows[0]["ClientExecutorRelationship"] = ClientWe.Relationship;
				dt.Rows[0]["ClientPowerAttorneyType"] = ClientPoA.Type;
				dt.Rows[0]["ClientPowerAttorneyFirstName"] = ClientPoA.FirstName;
				dt.Rows[0]["ClientPowerAttorneyLastName"] = ClientPoA.Surname;
				dt.Rows[0]["ClientPowerAttorneyRelationship"] = ClientPoA.Relationship;
				dt.Rows[0]["ClientPowerAttorneyLastReviewDate"] = ClientPoA.LastReview;
				dt.Rows[0]["ClientPowerAttorneyExpiryDate"] = ClientPoA.Expiry;
				dt.Rows[0]["ClientPowerAttorneyLocation"] = ClientPoA.Location;
				dt.Rows[0]["SpouseWillExists"] = (row["SWillExists"] != DBNull.Value ? ((bool)row["SWillExists"]?1:0 ):0);
				dt.Rows[0]["SpouseWillCurrent"] = (row["SWillCurrent"] != DBNull.Value ? ((bool)row["SWillCurrent"]?1:0 ):0);
				dt.Rows[0]["SpouseWillDate"] = Globals.GetDateString(row["SWillDate"]);
				dt.Rows[0]["SpouseWillLocation"] = Globals.Clean(row["SWillLocation"]);
				dt.Rows[0]["SpouseTestamentryTrust"] = (row["STestTru"] != DBNull.Value ? ((bool)row["STestTru"]?1:0 ):0);
				dt.Rows[0]["SpouseExecutorFirstName"] = SpouseWe.FirstName;
				dt.Rows[0]["SpouseExecutorLastName"] = SpouseWe.Surname;
				dt.Rows[0]["SpouseExecutorRelationship"] = SpouseWe.Relationship;
				dt.Rows[0]["SpousePowerAttorneyType"] = SpousePoA.Type;
				dt.Rows[0]["SpousePowerAttorneyFirstName"] = SpousePoA.FirstName;
				dt.Rows[0]["SpousePowerAttorneyLastName"] = SpousePoA.Surname;
				dt.Rows[0]["SpousePowerAttorneyRelationship"] = SpousePoA.Relationship;
				dt.Rows[0]["SpousePowerAttorneyLastReviewDate"] = SpousePoA.LastReview;
				dt.Rows[0]["SpousePowerAttorneyExpiryDate"] = SpousePoA.Expiry;
				dt.Rows[0]["SpousePowerAttorneyLocation"] = SpousePoA.Location;

				this.Lines.Append(this.RowToString(dt));
				++this.Count;
			}
		}

		struct PoA
		{
			internal string Type;
			internal string FirstName;
			internal string Surname;
			internal string Relationship;
			internal string LastReview;
			internal string Expiry;
			internal string Location;
		}
		struct WillExecutor
		{
			internal string FirstName;
			internal string Surname;
			internal string Relationship;
		}

		WillExecutor GetOneWillExecutor(string clientID, string Type)
		{
			string filter = string.Format("EntityTypeCode = '{0}' AND ClientID = {1}", Type,clientID);
			DataRow[] rows = Globals.dsCoinByClient.Tables["WillExecutors"].Select(filter);
			WillExecutor we = new WillExecutor();
			if((rows != null) &&(rows.Length >0))
			{
				we.FirstName = rows[0]["FirstName"].ToString();
				we.Surname = rows[0]["Surname"].ToString();
				we.Relationship = Globals.Clean(rows[0]["Relationship"]);
			}
			return we;
		}

		PoA GetOnePoA(string clientID, string Type)
		{
			string filter = string.Format("EntityTypeCode = '{0}' AND ClientID = {1}", Type,clientID);
			DataRow[] rows = Globals.dsCoinByClient.Tables["PowerofAttorneys"].Select(filter);
			PoA poa = new PoA();

			if((rows != null) &&(rows.Length >0))
			{
                if (!Globals.CoinVersion.StartsWith("2.")) // version 3+ onwards...
                    poa.Type = rows[0]["POAType"].ToString();
                else
                    poa.Type = rows[0]["Type"].ToString();

				poa.FirstName = rows[0]["FirstName"].ToString();
				poa.Surname = rows[0]["Surname"].ToString();
				poa.Relationship = Globals.Clean(rows[0]["Relationship"]);
				poa.LastReview = Globals.GetDateString(rows[0]["POADate"]);
				poa.Expiry  = Globals.GetDateString(rows[0]["ExpiryDate"]);
				poa.Location = Globals.Clean(rows[0]["Location"]);
			}
			return poa;
		}

		protected override void InitFields(DataTable dt)
		{
			string[] columns = {"GroupID","GroupEstateNotes","ClientWillExists","ClientWillCurrent","ClientWillDate","ClientWillLocation","ClientTestamentryTrust","ClientExecutorFirstName","ClientExecutorLastName","ClientExecutorRelationship","ClientPowerAttorneyType","ClientPowerAttorneyFirstName","ClientPowerAttorneyLastName","ClientPowerAttorneyRelationship","ClientPowerAttorneyLastReviewDate","ClientPowerAttorneyExpiryDate","ClientPowerAttorneyLocation","SpouseWillExists","SpouseWillCurrent","SpouseWillDate","SpouseWillLocation","SpouseTestamentryTrust","SpouseExecutorFirstName","SpouseExecutorLastName","SpouseExecutorRelationship","SpousePowerAttorneyType","SpousePowerAttorneyFirstName","SpousePowerAttorneyLastName","SpousePowerAttorneyRelationship","SpousePowerAttorneyLastReviewDate","SpousePowerAttorneyExpiryDate","SpousePowerAttorneyLocation"};
			foreach(string col in columns)
				dt.Columns.Add(col);
		}

	}
}
