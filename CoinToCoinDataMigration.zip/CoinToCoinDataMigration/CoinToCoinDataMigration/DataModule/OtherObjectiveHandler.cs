﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;
using CoinDataConversionsIO;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
    class OtherObjectiveHandler:ITableHandler
    {
        public OtherObjectiveHandler()
		{
            Description = "Other Objective";
            Code = "OO";
            DataRelated = DataRelatedEnum.Client;
		}

        public override void Import()
        {
            DataView dvOtherObjectives = Globals.dsCoinByClient.Tables["OtherObjectives"].DefaultView;
            dvOtherObjectives.RowFilter = "ClientID='" + Importer.CurrentClient.ToString() + "'";

            DataTable dt = InitTable();

            for (int i = 0; i < dvOtherObjectives.Count; ++i)
            {
                DataRow othObjectiveRow = dvOtherObjectives[i].Row;

                dt.Rows[0]["ID"] = othObjectiveRow["ID"];
                dt.Rows[0]["ObjectiveID"] = othObjectiveRow["ObjectiveID"];
                dt.Rows[0]["ClientID"] = othObjectiveRow["ClientID"];
                dt.Rows[0]["Description"] = Globals.NotesTextConverter(othObjectiveRow["Description"].ToString());
                dt.Rows[0]["Code"] = othObjectiveRow["code"];

                //Globals.AddToSetup("Note Categories|" + fileNoteRow["Subject"]);
                this.Lines.Append(this.RowToString(dt));
                ++this.Count;
            }
        }

        protected override void InitFields(DataTable dt)
        {
            dt.Columns.Add("ID");
            dt.Columns.Add("ObjectiveID");
            dt.Columns.Add("ClientID");
            dt.Columns.Add("Description");
            dt.Columns.Add("Code");
        }
    }
}
