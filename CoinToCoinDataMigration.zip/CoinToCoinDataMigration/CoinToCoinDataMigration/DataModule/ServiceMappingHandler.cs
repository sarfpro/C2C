using System;
using System.Data;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
	/// <summary>
	/// Summary description for ServiceMappingHandler.
	/// </summary>
	public class ServiceMappingHandler : ITableHandler
	{
		public ServiceMappingHandler()
		{
			//
			// TODO: Add constructor logic here
			//
            this.Description = "Service Mapping";
            this.Code = "SM";
            this.DataRelated = DataRelatedEnum.Client;
		}

        public override void Import() 
        {
            DataView dvEntClients  = Globals.dsCoinByClient.Tables["Ent_Clients"].DefaultView;
            dvEntClients.RowFilter = "EntityGroupID='" + this.Importer.CurrentClient.ToString() + "'";
            ImportAssetGroups(dvEntClients, "CLI");

            DataView dvEntSpouses  = Globals.dsCoinByClient.Tables["Ent_Spouses"].DefaultView;
            dvEntSpouses.RowFilter = "EntityGroupID='" + this.Importer.CurrentClient.ToString() + "'";
            ImportAssetGroups(dvEntSpouses, "SPS");

            DataView dvJoint  = Globals.dsCoinByClient.Tables["Joint"].DefaultView;
            dvJoint.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";
            ImportAssetGroups(dvJoint, "JOI");

            DataView dvCompanies  = Globals.dsCoinByClient.Tables["Companies"].DefaultView;
            dvCompanies.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";
            ImportAssetGroups(dvCompanies, "COM");

            DataView dvSuperFund  = Globals.dsCoinByClient.Tables["SuperFund"].DefaultView;
            dvSuperFund.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";
            ImportAssetGroups(dvSuperFund, "SUP");

            DataView dvTrusts  = Globals.dsCoinByClient.Tables["Trusts"].DefaultView;
            dvTrusts.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";
            ImportAssetGroups(dvTrusts, "TRU");

            DataView dvOther  = Globals.dsCoinByClient.Tables["Other"].DefaultView;
            dvOther.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";
            ImportAssetGroups(dvOther, "OTH");
        }

        protected override void InitFields(DataTable dt) 
        {
            dt.Columns.Add("ClientID");
            dt.Columns.Add("AccountID");
            dt.Columns.Add("ServiceID");
            dt.Columns.Add("ServiceName");
            dt.Columns.Add("Description");
            dt.Columns.Add("MappingID");
            dt.Columns.Add("MappingSourceID");
        }

        private void ImportAssetGroups(DataView dv, string type) 
        {
            for (int i = 0; i < dv.Count; ++i) 
            {
                DataRow entRow = dv[i].Row;
                string entID = (type == "CLI" || type == "SPS") ? dv[i].Row["EntityID"].ToString() : dv[i].Row["ID"].ToString();

                DataView dvAssetGroups = Globals.dsCoinByClient.Tables["P_AssetGroups"].DefaultView;
                dvAssetGroups.RowFilter = "AG_OWNER='" + entID + "'";

                for (int j = 0; j < dvAssetGroups.Count; ++j) 
                {
                    DataTable dt = InitTable();

                    DataRow agRow = dvAssetGroups[j].Row;

                    DataView dvDataFeed = Globals.dsCoinGlobals.Tables["DataFeedClientMapping"].DefaultView;
                    dvDataFeed.RowFilter = "IntID='" + agRow["AG_ID"].ToString() + "'";

                    string mappingID       = (dvDataFeed.Count > 0) ? dvDataFeed[0].Row["ExtID"].ToString()  : "";
                    string mappingSourceID = (dvDataFeed.Count > 0) ? dvDataFeed[0].Row["ExtGroup"].ToString() : "";

                    dt.Rows[0]["ClientID"]        = agRow["AG_Owner"];
                    dt.Rows[0]["AccountID"]       = agRow["AG_ID"];
                    dt.Rows[0]["ServiceID"]       = agRow["AG_SE"];
                    dt.Rows[0]["Description"]     = agRow["AG_AccountName"];
                    dt.Rows[0]["MappingID"]       = mappingID;
                    dt.Rows[0]["MappingSourceID"] = mappingSourceID;

                    this.Lines.Append(this.RowToString(dt));
                    ++this.Count;

                    // if service in holding is ticked
                    if (Globals.ServiceInSM)
                    {
                        // add the service id into the library
                        if (!Globals.ServiceInSMList.Contains(agRow["AG_SE"].ToString()))
                            Globals.ServiceInSMList.Add(agRow["AG_SE"].ToString());
                    }
                }
            }
        }
	}
}
