using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Diagnostics;
using HolisticFS.HSDB;
using CoinToCoinDataMigration.Utils;

namespace CoinToCoinDataMigration.DataModule
{
    class ProfessionalMappingHandler : ITableHandler
    {
        public ProfessionalMappingHandler()
        {
            this.Description = "Professional Mapping";
            this.Code = "PM";
            this.DataRelated = DataRelatedEnum.Client;
        }

        protected override void InitFields(DataTable dt)
        {
            dt.Columns.Add("GroupID");
            dt.Columns.Add("ProfessionalID");
            dt.Columns.Add("RefDate");
            dt.Columns.Add("RefClientID");
            dt.Columns.Add("MapType");
        }

        public override void Import()
        {
            DataTable dt = InitTable();
            DataView dvProMapping = Globals.dsCoinByClient.Tables["ProfessionalMapping"].DefaultView;
            dvProMapping.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";

            for (int i = 0; i < dvProMapping.Count; ++i)
            {
                DataRow proMappingRow = dvProMapping[i].Row;

                dt.Rows[0]["GroupID"] = proMappingRow["ClientID"];
                dt.Rows[0]["ProfessionalID"] = proMappingRow["ProfessionalID"];
                dt.Rows[0]["RefDate"] = string.IsNullOrEmpty(proMappingRow["RefDate"].ToString()) ? "" : Convert.ToDateTime(proMappingRow["RefDate"].ToString()).ToString("yyyy-MM-dd");
                dt.Rows[0]["RefClientID"] = proMappingRow["RefClientID"];
                dt.Rows[0]["MapType"] = proMappingRow["Referal"];

                this.Lines.Append(this.RowToString(dt));
                ++this.Count;
            }
        }
    }
}
