using System;
using System.Data;
using System.Collections.Generic;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
	/// <summary>
	/// Summary description for ClientHandler.
	/// </summary>
	public class ClientHandler : ITableHandler
	{
		public ClientHandler()
		{
			this.Description = "Client";
			this.Code = "CL";
			this.DataRelated = DataRelatedEnum.Client;
		}

		public override void Import() 
		{
			DataView dvEntClients  = Globals.dsCoinByClient.Tables["Ent_Clients"].DefaultView;
			dvEntClients.RowFilter = "EntityGroupID='" + this.Importer.CurrentClient.ToString() + "'";
			ImportClient(dvEntClients, "CLI");

			DataView dvCompanies  = Globals.dsCoinByClient.Tables["Companies"].DefaultView;
			dvCompanies.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";
			ImportClient(dvCompanies, "COM");

			DataView dvSuperFund  = Globals.dsCoinByClient.Tables["SuperFund"].DefaultView;
			dvSuperFund.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";
			ImportClient(dvSuperFund, "SUP");

			DataView dvTrusts  = Globals.dsCoinByClient.Tables["Trusts"].DefaultView;
			dvTrusts.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";
			ImportClient(dvTrusts, "TRU");

			DataView dvOther  = Globals.dsCoinByClient.Tables["Other"].DefaultView;
			dvOther.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";
			ImportClient(dvOther, "OTH");
		}

		protected override void InitFields(DataTable dt) 
		{
			dt.Columns.Add("ClientID");
			dt.Columns.Add("ClientSurname");
			dt.Columns.Add("ClientFirstName");
			dt.Columns.Add("ClientMiddleName");
			dt.Columns.Add("ClientPreferredName");
			dt.Columns.Add("ClientTitle");
			dt.Columns.Add("ClientSex");
			dt.Columns.Add("ClientMaritalStatus");
			dt.Columns.Add("ClientDOB");
			dt.Columns.Add("ClientType");
			dt.Columns.Add("ClientStatus");
			dt.Columns.Add("ClientCategory");
            dt.Columns.Add("Reference");
            dt.Columns.Add("FSGProvideDate");
            dt.Columns.Add("FirstAppointDate");
			dt.Columns.Add("LastAppointDate");
			dt.Columns.Add("CreatedDate");
			dt.Columns.Add("NextReviewDate");
			dt.Columns.Add("FactFindDate");
			dt.Columns.Add("AdviserID");
			dt.Columns.Add("ClientPreferredAddress");
			dt.Columns.Add("Client_H_Salutation");
			dt.Columns.Add("Client_H_AddressLine1");
			dt.Columns.Add("Client_H_AddressLine2");
			dt.Columns.Add("Client_H_Suburb");
			dt.Columns.Add("Client_H_State");
			dt.Columns.Add("Client_H_PostCode");
			dt.Columns.Add("Client_H_Country");
			dt.Columns.Add("Client_B_Salutation");
			dt.Columns.Add("Client_B_AddressLine1");
			dt.Columns.Add("Client_B_AddressLine2");
			dt.Columns.Add("Client_B_Suburb");
			dt.Columns.Add("Client_B_State");
			dt.Columns.Add("Client_B_PostCode");
			dt.Columns.Add("Client_B_Country");
			dt.Columns.Add("Client_O_Salutation");
			dt.Columns.Add("Client_O_AddressLine1");
			dt.Columns.Add("Client_O_AddressLine2");
			dt.Columns.Add("Client_O_Suburb");
			dt.Columns.Add("Client_O_State");
			dt.Columns.Add("Client_O_PostCode");
			dt.Columns.Add("Client_O_Country");
			dt.Columns.Add("ClientHomePhone");
			dt.Columns.Add("ClientWorkPhone");
			dt.Columns.Add("ClientMobile");
			dt.Columns.Add("ClientFaxHome");
			dt.Columns.Add("ClientFaxWork");
			dt.Columns.Add("ClientEmailAddress");
            dt.Columns.Add("ClientEmailAddress2");
            dt.Columns.Add("ClientWebPage");
			dt.Columns.Add("ClientOccupationType");
			dt.Columns.Add("ClientOccupation");
			dt.Columns.Add("ClientEmployer");
            dt.Columns.Add("ClientStartEmp");
            dt.Columns.Add("ClientHealth");
			dt.Columns.Add("ClientSmoker");
			dt.Columns.Add("ClientTFN");
            dt.Columns.Add("ClientPrivHealthIns");
            dt.Columns.Add("ClientAgeToRetire");
            dt.Columns.Add("ClientCustomerIdentification");
			dt.Columns.Add("ClientCustomerID");
			dt.Columns.Add("SpouseID");
			dt.Columns.Add("SpouseSurname");
			dt.Columns.Add("SpouseFirstName");
			dt.Columns.Add("SpouseMiddleName");
			dt.Columns.Add("SpousePreferredName");
			dt.Columns.Add("SpouseTitle");
			dt.Columns.Add("SpouseSex");
			dt.Columns.Add("SpouseDOB");
			dt.Columns.Add("SpousePreferredAddress");
			dt.Columns.Add("Spouse_H_Salutation");
			dt.Columns.Add("Spouse_H_AddressLine1");
			dt.Columns.Add("Spouse_H_AddressLine2");
			dt.Columns.Add("Spouse_H_Suburb");
			dt.Columns.Add("Spouse_H_State");
			dt.Columns.Add("Spouse_H_PostCode");
			dt.Columns.Add("Spouse_H_Country");
			dt.Columns.Add("Spouse_B_Salutation");
			dt.Columns.Add("Spouse_B_AddressLine1");
			dt.Columns.Add("Spouse_B_AddressLine2");
			dt.Columns.Add("Spouse_B_Suburb");
			dt.Columns.Add("Spouse_B_State");
			dt.Columns.Add("Spouse_B_PostCode");
			dt.Columns.Add("Spouse_B_Country");
			dt.Columns.Add("Spouse_O_Salutation");
			dt.Columns.Add("Spouse_O_AddressLine1");
			dt.Columns.Add("Spouse_O_AddressLine2");
			dt.Columns.Add("Spouse_O_Suburb");
			dt.Columns.Add("Spouse_O_State");
			dt.Columns.Add("Spouse_O_PostCode");
			dt.Columns.Add("Spouse_O_Country");
			dt.Columns.Add("SpouseHomePhone");
			dt.Columns.Add("SpouseWorkPhone");
			dt.Columns.Add("SpouseMobile");
			dt.Columns.Add("SpouseFaxHome");
			dt.Columns.Add("SpouseFaxWork");
			dt.Columns.Add("SpouseEmailAddress");
            dt.Columns.Add("SpouseEmailAddress2");
            dt.Columns.Add("SpouseWebPage");
			dt.Columns.Add("SpouseOccupationType");
			dt.Columns.Add("SpouseOccupation");
			dt.Columns.Add("SpouseEmployer");
            dt.Columns.Add("SpouseStartEmp");
            dt.Columns.Add("SpouseHealth");
			dt.Columns.Add("SpouseSmoker");
			dt.Columns.Add("SpouseTFN");
            dt.Columns.Add("SpousePrivHealthIns");
            dt.Columns.Add("SpouseAgeToRetire");
            dt.Columns.Add("SpouseCustomerIdentification");
			dt.Columns.Add("SpouseCustomerID");
			dt.Columns.Add("GroupName");
			dt.Columns.Add("GroupID");
			dt.Columns.Add("EntityName");
			dt.Columns.Add("EntityABN");
			dt.Columns.Add("EntityTFN");
			dt.Columns.Add("EntityCustomerID");
			dt.Columns.Add("Comments");
            dt.Columns.Add("Deleted");
        }

		private void ImportClient(DataView dv, string type) 
		{
            // ------------------------------------------
            // This bit is for CBA
            // ------------------------------------------
            //Dictionary<string, string> ClassMapping = new Dictionary<string, string>(StringComparer.CurrentCultureIgnoreCase);
            //ClassMapping.Add("", "");
            //ClassMapping.Add("Bronze", "C");
            //ClassMapping.Add("Deceased", "");
            //ClassMapping.Add("Gold", "A");
            //ClassMapping.Add("No Contact", "F");
            //ClassMapping.Add("Overseas Client", "E");
            //ClassMapping.Add("Platinum", "AA");
            //ClassMapping.Add("Prospect", "D");
            //ClassMapping.Add("Silver", "B");

            //Dictionary<string, string> StatusMapping = new Dictionary<string, string>(StringComparer.CurrentCultureIgnoreCase);
            //StatusMapping.Add("", "");
            //StatusMapping.Add("Active", "Client - existing");
            //StatusMapping.Add("Prospect", "Prospect");
            //StatusMapping.Add("Review", "Client - standard review");
            // ------------------------------------------

			DataView dvEntityGroups  = Globals.dsCoinByClient.Tables["EntityGroups"].DefaultView;
			dvEntityGroups.RowFilter = "ID='" + this.Importer.CurrentClient.ToString() + "'";
			DataRow egRow  = dvEntityGroups[0].Row;

			DataView dvUsers = Globals.dsCoinGlobals.Tables["Users"].DefaultView;
			dvUsers.RowFilter = "ID='" + egRow["UserID"].ToString() + "'";
			string userName = dvUsers[0].Row["UserName"].ToString();

			Console.WriteLine(this.Importer.CurrentClient.ToString());

			DataView dvClientCategories = Globals.dsCoinByClient.Tables["ClientCategories"].DefaultView;
			dvClientCategories.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'" + " and Description='Status'";
            //For non-CBA, use the next line of code
            string clientStatus = (dvClientCategories.Count > 0) ? GetClientStatus(dvClientCategories[0]["ItemID"].ToString()) : "";
            //for CBA, use the next line of code
            if (CommonUI.MappingControl.CustomMapping && CommonUI.MappingControl.statusMapping.ContainsKey(clientStatus))
                clientStatus = CommonUI.MappingControl.statusMapping[clientStatus];
            if (clientStatus.Trim().Length > 0) Globals.AddToSetup("Status|" + clientStatus);

            dvClientCategories.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'" + " and Description='Class'";			
            //For non-CBA, use the next line of code
            string clientClass = (dvClientCategories.Count > 0) ? GetClientStatus(dvClientCategories[0]["ItemID"].ToString()) : "";
            //for CBA, use the next line of code
            if (CommonUI.MappingControl.CustomMapping && CommonUI.MappingControl.classMapping.ContainsKey(clientClass))
                clientClass = CommonUI.MappingControl.classMapping[clientClass];
            if(clientClass.Trim().Length>0) {Globals.AddToSetup("Class|" + clientClass);}

			for (int i = 0; i < dv.Count; ++i) 
			{
				DataTable dt = this.InitTable();
				DataRow row  = dv[i].Row;

				dt.Rows[0]["GroupName"]           = egRow["EntityGroupName"];
				dt.Rows[0]["GroupID"]             = egRow["ID"];
				dt.Rows[0]["AdviserID"]           = userName; // egRow["UserID"];
				dt.Rows[0]["ClientStatus"]        = clientStatus;
				dt.Rows[0]["ClientCategory"]      = clientClass;
				dt.Rows[0]["ClientMaritalStatus"] = egRow["MaritalStatusID"];
				dt.Rows[0]["Comments"] = Globals.NotesTextConverter(egRow["Comments"].ToString());
                dt.Rows[0]["reference"] = egRow["reference"];
                dt.Rows[0]["FSGProvideDate"] = Globals.GetDateString(egRow["FSGProvideDate"]);
                dt.Rows[0]["CreatedDate"] = Globals.GetDateString(egRow["CreatedDate"]);
                dt.Rows[0]["NextReviewDate"] = Globals.GetDateString(egRow["NextReviewDate"]);
                dt.Rows[0]["FactFindDate"] = Globals.GetDateString(egRow["FactFindDate"]);
                dt.Rows[0]["FirstAppointDate"] = Globals.GetDateString(egRow["FirstAppointDate"]);
                dt.Rows[0]["LastAppointDate"] = Globals.GetDateString(egRow["LastAppointDate"]);

                if (egRow["Deleted"].Equals(true))
                {  dt.Rows[0]["Deleted"] = "1"; }
                else
                {  dt.Rows[0]["Deleted"] = "0"; }
                


                if (type == "CLI") 
				{
					// import clients

					DataRow ecRow            = dv[i].Row;
					dt.Rows[0]["ClientType"] = "CLI";

					ImportClientOrSpouse(ecRow, dt.Rows[0], "Client");

					// import spouses

					DataView dvEntSpouses  = Globals.dsCoinByClient.Tables["Ent_Spouses"].DefaultView;
					dvEntSpouses.RowFilter = "EntityGroupID='" + this.Importer.CurrentClient.ToString() + "'";


					if (dvEntSpouses.Count > 0) 
					{
						ImportClientOrSpouse(dvEntSpouses[0].Row, dt.Rows[0], "Spouse");

						DataView dvJoint  = Globals.dsCoinByClient.Tables["Joint"].DefaultView;
						dvJoint.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";						
						if(dvJoint.Count > 0)
						{
							DataTable dtJoint = InitTable();
							dtJoint.Rows[0]["ClientID"]      = dvJoint[0].Row["ID"];
							dtJoint.Rows[0]["ClientSurname"] = "Joint";
							dtJoint.Rows[0]["ClientType"]    = "JOI";
							dtJoint.Rows[0]["GroupName"]     = egRow["EntityGroupName"];
							dtJoint.Rows[0]["GroupID"]       = egRow["ID"];
							dtJoint.Rows[0]["AdviserID"]     = userName; 

							this.Lines.Append(this.RowToString(dtJoint));
							++this.Count;
						}
					}

				} 
				else if (type == "COM" || type == "TRU" || type == "SUP" || type == "OTH") 
				{
					ImportComSupTruOth(row, dt.Rows[0], type);
				}
				this.Lines.Append(this.RowToString(dt));
				++this.Count;
			}
		}

		private void ImportClientOrSpouse(DataRow sourceRow, DataRow targetRow, string type) 
		{
			targetRow[type + "ID"]             = sourceRow["EntityID"];
			targetRow[type + "Surname"]        = sourceRow["Surname"];
			targetRow[type + "FirstName"]      = sourceRow["GivenName"];
			targetRow[type + "MiddleName"]     = sourceRow["MiddleName"];
			targetRow[type + "PreferredName"]  = sourceRow["PreferredName"];
			targetRow[type + "Title"]          = sourceRow["Title"];
			targetRow[type + "Sex"]            = sourceRow["Sex"];
			targetRow[type + "DOB"]            = sourceRow["DOB"];

			ImportAddress(sourceRow["AddressListID"].ToString(), targetRow, type);

			targetRow[type + "HomePhone"]       = sourceRow["PhoneH"];
			targetRow[type + "WorkPhone"]       = sourceRow["Phone"];
			targetRow[type + "Mobile"]          = sourceRow["PhoneMob"];
			targetRow[type + "FaxHome"]         = sourceRow["FaxHome"];
			targetRow[type + "FaxWork"]         = sourceRow["Fax"];
			targetRow[type + "EmailAddress"]    = sourceRow["Email"];
            targetRow[type + "WebPage"]         = sourceRow["WebPage"];
            targetRow[type + "EmailAddress2"]   = sourceRow["Email2"];
			targetRow[type + "OccupationType"]  = sourceRow["OccType"];
			targetRow[type + "Occupation"]      = sourceRow["Occupation"];
			targetRow[type + "Employer"]        = sourceRow["Employer"];
            targetRow[type + "StartEmp"]        = sourceRow["StartEmp"];
            targetRow[type + "Health"]          = sourceRow["Health"];
			targetRow[type + "Smoker"]          = (sourceRow["Smoker"] != DBNull.Value ? ((bool)sourceRow["Smoker"] ?1:0): 0);

            string decrypted = HolisticFS.GenUtils.SafeCast.ToString(sourceRow["TFN"]);

            if (!string.IsNullOrEmpty(decrypted))
            {
                try
                {
                    targetRow[type + "TFN"] = HolisticFS.GenUtils.GeneralRevEncrypt.Decrypt(decrypted);
                }
                catch (Exception)
                {
                    targetRow[type + "TFN"] = sourceRow["TFN"];
                }
            }

            //targetRow[type + "TFN"] = string.IsNullOrEmpty(decrypted) ? "" : HolisticFS.GenUtils.GeneralRevEncrypt.Decrypt(decrypted);
                        
            targetRow[type + "PrivHealthIns"] = (sourceRow["PrivHealthIns"] != DBNull.Value ? ((bool)sourceRow["PrivHealthIns"] ? 1 : 0) : 0);
            targetRow[type + "CustomerIdentification"] = (sourceRow["CustomerIdentification"] != DBNull.Value ? ((bool)sourceRow["CustomerIdentification"] ? 1 : 0) : 0);
            targetRow[type + "CustomerID"]      = sourceRow["CustomerID"];
            targetRow[type + "AgeToRetire"] = sourceRow["AgeToRetire"];

		}

		private void ImportComSupTruOth(DataRow sourceRow, DataRow targetRow, string type) 
		{
            string decrypted = HolisticFS.GenUtils.SafeCast.ToString(sourceRow["TFN"]);
            
            targetRow["ClientID"]   = sourceRow["ID"];
			targetRow["ClientType"] = type;

			ImportAddress(sourceRow["AddressListID"].ToString(), targetRow, "Client");

			targetRow["ClientHomePhone"]    = sourceRow["PhoneH"];
			targetRow["ClientWorkPhone"]    = sourceRow["Phone"];
			targetRow["ClientMobile"]       = sourceRow["PhoneM"];
			targetRow["ClientFaxHome"]      = sourceRow["FaxH"];
			targetRow["ClientFaxHome"]      = sourceRow["Fax"];
			targetRow["ClientEmailAddress"] = sourceRow["Email"];
            //targetRow["ClientTFN"] = string.IsNullOrEmpty(decrypted) ? "" : HolisticFS.GenUtils.GeneralRevEncrypt.Decrypt(decrypted);
			targetRow["EntityName"]         = (type == "COM" || type == "TRU") ? sourceRow["Name"] : sourceRow["EntityName"];
			targetRow["EntityABN"]          = (type == "COM") ? sourceRow["ACN"] : sourceRow["ABN"];
            //targetRow["EntityTFN"] = string.IsNullOrEmpty(decrypted) ? "" : HolisticFS.GenUtils.GeneralRevEncrypt.Decrypt(decrypted);
			targetRow["EntityCustomerID"]   = sourceRow["CustomerID"];

            if (!string.IsNullOrEmpty(decrypted))
            {
                try
                {
                    targetRow["ClientTFN"] = HolisticFS.GenUtils.GeneralRevEncrypt.Decrypt(decrypted);
                    targetRow["EntityTFN"] = HolisticFS.GenUtils.GeneralRevEncrypt.Decrypt(decrypted);
                }
                catch (Exception)
                {
                    targetRow["ClientTFN"] = sourceRow["TFN"];
                    targetRow["EntityTFN"] = sourceRow["TFN"];
                }
            }
		}

		private string GetClientStatus(string itemID) 
		{
			string clientStatus = "";
			if (itemID != null && itemID != "") 
			{
				DataView dvItems = Globals.dsCoinByClient.Tables["Items"].DefaultView;
				dvItems.RowFilter = "ID='" + itemID + "'";

				if (dvItems.Count > 0) 
				{
					clientStatus = dvItems[0].Row["Name"].ToString().Trim();
				}
			}
			return clientStatus;
		}

		private void ImportAddress(string addressListID, DataRow targetRow, string type) 
		{
			DataRow addressRow = null;

			if (addressListID != null && addressListID.Trim() != "") 
			{

				string[] addressTypes = {"Home","Business","Other"};

				foreach(string addType in addressTypes)
				{
					DataView dvAddressList  = Globals.dsCoinByClient.Tables["AddressList"].DefaultView;
					dvAddressList.RowFilter = "Type = '"+addType+"' AND AddressListID='" + addressListID + "'";

					if (dvAddressList.Count > 0) 
					{
						DataRow addressListRow = dvAddressList[0].Row;
						string addressID       = addressListRow["AddressID"].ToString();					
						DataView dvAddress  = Globals.dsCoinByClient.Tables["Address"].DefaultView;
						dvAddress.RowFilter = "ID='" + addressID + "'";					
						addressRow = dvAddress[0].Row;
						string prefix = string.Format("_{0}_",addType[0].ToString());
						if (addressRow != null) 
						{
							if((bool)addressListRow["IsPreferred"])	targetRow[type + "PreferredAddress"] =addType[0].ToString();
							targetRow[type + prefix+"Salutation"]     = addressRow["Title"];
							targetRow[type + prefix+"AddressLine1"] = addressRow["Street1"];
							targetRow[type + prefix+"AddressLine2"] = addressRow["Street2"];
							targetRow[type + prefix+"Suburb"]       = addressRow["Suburb"];
							targetRow[type + prefix+"State"]        = addressRow["State"];
							targetRow[type + prefix+"Postcode"]     = System.Text.RegularExpressions.Regex.Replace(addressRow["PostCode"].ToString(), @"\D", "");
							targetRow[type + prefix+"Country"]      = addressRow["Country"];
						}
					}
				}
			}
		}
	}
}
