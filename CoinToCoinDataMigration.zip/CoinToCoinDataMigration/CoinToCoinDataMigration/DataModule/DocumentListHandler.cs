using System;
using System.Data;
using HolisticFS.HSDB;
using CoinToCoinDataMigration.Utils;

namespace CoinToCoinDataMigration.DataModule
{
    /// <summary>
    /// Summary description for DocumentListHandler.
    /// </summary>
    public class DocumentListHandler : ITableHandler
    {
        public DocumentListHandler()
        {
            //
            // TODO: Add constructor logic here
            //
            this.Description = "Document List";
            this.Code = "DL";
            this.DataRelated = DataRelatedEnum.Client;
        }

        //CD 2011.4.5 bug 17404 to add _Archive _Old support, and blob storage support
        public override void Import()
        {
            Import("");
            Import("_Archive");
            Import("_Old");
            Import("_DeletedClientGroups");
        }

        private void Import(string suffix)
        {
            DataTable dt = InitTable();
            DataView dvDocumentList = Globals.dsCoinByClient.Tables["DocumentList" + suffix].DefaultView;
            dvDocumentList.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";

            for (int i = 0; i < dvDocumentList.Count; ++i)
            {
                DataRow documentListRow = dvDocumentList[i].Row;
                dt.Rows[0]["ID"] = documentListRow["ID"];
                dt.Rows[0]["ClientID"] = documentListRow["ClientID"];
                
                DataView dvUsers = Globals.dsCoinGlobals.Tables["Users"].DefaultView;
                dvUsers.RowFilter = "ID='" + documentListRow["UserID"].ToString() + "'";
                string userName = dvUsers[0].Row["UserName"].ToString();

                dt.Rows[0]["UserID"] = userName;
                dt.Rows[0]["Date"] = documentListRow["Date"];
                dt.Rows[0]["DocName"] = FileHandler.FormatFileName(documentListRow["DocName"].ToString());
                dt.Rows[0]["FileType"] = documentListRow["FileType"];
                dt.Rows[0]["Source"] = documentListRow["Source"];
                dt.Rows[0]["Reviewed"] = documentListRow["Reviewed"];
                dt.Rows[0]["Status"] = documentListRow["Status"];
                dt.Rows[0]["Progress"] = documentListRow["Progress"];
                dt.Rows[0]["IsSOA"] = documentListRow["IsSOA"];
                dt.Rows[0]["FinalisedDate"] = documentListRow["FinalisedDate"];
                dt.Rows[0]["FaxStatusCode"] = documentListRow["FaxStatusCode"];
                dt.Rows[0]["StatusType"] = documentListRow["StatusType"];
                dt.Rows[0]["StatusDate"] = documentListRow["StatusDate"];
                dt.Rows[0]["FaxStatusDesc"] = documentListRow["FaxStatusDesc"];
                this.Lines.Append(this.RowToString(dt));
                ++this.Count;
            }
        }
        
        protected override void InitFields(DataTable dt)
        {
            dt.Columns.Add("ID");
            dt.Columns.Add("ClientID");
            dt.Columns.Add("UserID");
            dt.Columns.Add("Date");
            dt.Columns.Add("DocName");
            dt.Columns.Add("FileType");
            dt.Columns.Add("Source");
            dt.Columns.Add("Reviewed");
            dt.Columns.Add("Status");
            dt.Columns.Add("Progress");
            dt.Columns.Add("IsSOA");
            dt.Columns.Add("FaxStatusCode");
            dt.Columns.Add("StatusType");
            dt.Columns.Add("StatusDate");
            dt.Columns.Add("FaxStatusDesc");
            dt.Columns.Add("FinalisedDate");
        }
    }
}
