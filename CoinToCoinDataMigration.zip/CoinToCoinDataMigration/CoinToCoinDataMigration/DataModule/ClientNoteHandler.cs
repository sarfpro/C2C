using System;
using System.Data;
using System.Collections.Generic;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
    /// <summary>
    /// Summary description for ClientNoteHandler.
    /// </summary>
    public class ClientNoteHandler : ITableHandler
    {
        public ClientNoteHandler()
        {
            //
            // TODO: Add constructor logic here
            //
            this.Description = "Client Note";
            this.Code = "CN";
            this.DataRelated = DataRelatedEnum.Client;
        }

        //CD 2011.4.5 bug 17404 to add _Archive _Old support, and blob storage support
        public override void Import()
        {
            Import("");
            Import("_Archive");
            Import("_Old");
            Import("_DeletedClientGroups");
            ImportClientFeeFoFA();
        }

        private void Import(string suffix)
        {
            DataTable dt = InitTable();


            DataView dvFileNotes = Globals.dsCoinByClient.Tables["FileNotes" + suffix].DefaultView;
            dvFileNotes.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";

            // ------------------------------------------
            // This bit is for CBA
            // ------------------------------------------
            //Dictionary<string, string> NoteCategoryMapping = new Dictionary<string, string>(StringComparer.CurrentCultureIgnoreCase);
            //NoteCategoryMapping.Add("", "Other");
            //NoteCategoryMapping.Add("Client Correspondence", "Other");
            //NoteCategoryMapping.Add("Fact Find", "Other");
            //NoteCategoryMapping.Add("Note", "Note");
            //NoteCategoryMapping.Add("Other", "Other");
            //NoteCategoryMapping.Add("Quotes", "Quote sent");
            // ------------------

            string NoteCategory = "";
            for (int i = 0; i < dvFileNotes.Count; ++i)
            {
                DataRow fileNoteRow = dvFileNotes[i].Row;

                dt.Rows[0]["ClientNoteID"] = fileNoteRow["ID"];
                dt.Rows[0]["GroupID"] = fileNoteRow["ClientID"];

                //For non-CBA, use the next line of code
                NoteCategory = fileNoteRow["Subject"].ToString();
                //for CBA, use the next line of code
                //NoteCategory = NoteCategoryMapping[((dvFileNotes.Count > 0) ? fileNoteRow["Subject"].ToString().Trim() : "")];
                if (CommonUI.MappingControl.CustomMapping && CommonUI.MappingControl.noteCategoryMapping.ContainsKey(NoteCategory))
                    NoteCategory = CommonUI.MappingControl.noteCategoryMapping[NoteCategory];

                dt.Rows[0]["Subject"] = NoteCategory;

                //for CBA Kowy Investments only
                //switch (fileNoteRow["Subject"].ToString().Trim())
                //{
                //    case "Client Correspondence": dt.Rows[0]["noteSubject"] = "Client Correspondence"; break;
                //    case "Fact Find": dt.Rows[0]["noteSubject"] = "FNA"; break;
                //    default: dt.Rows[0]["noteSubject"] = fileNoteRow["noteSubject"]; break;
                //}
                //for non-CBA
                dt.Rows[0]["noteSubject"] = fileNoteRow["noteSubject"];

                dt.Rows[0]["Date"] = Globals.GetDateString(fileNoteRow["FNDate"]);
                dt.Rows[0]["Note"] = Globals.NotesTextConverter(fileNoteRow["Notes"].ToString());

                // only do it if userid is not null
                if (fileNoteRow["UserID"] != DBNull.Value)
                {
                    DataView dvUsers = Globals.dsCoinGlobals.Tables["Users"].DefaultView;
                    dvUsers.RowFilter = "ID='" + fileNoteRow["UserID"].ToString() + "'";
                    string userName = dvUsers[0].Row["UserName"].ToString();

                    dt.Rows[0]["UserID"] = userName;
                }

                Globals.AddToSetup("Note Categories|" + NoteCategory);
                this.Lines.Append(this.RowToString(dt));
                ++this.Count;
            }
        }

        protected override void InitFields(DataTable dt)
        {
            dt.Columns.Add("ClientNoteID");
            dt.Columns.Add("GroupID");
            dt.Columns.Add("Subject");
            dt.Columns.Add("noteSubject");
            dt.Columns.Add("Date");
            dt.Columns.Add("Note");
            dt.Columns.Add("UserID");
        }

        private void ImportClientFeeFoFA()
        {
            DataView dvPackage = Globals.dsCoinByClient.Tables["Package"].DefaultView;
            dvPackage.RowFilter = "EntityGroupID='" + this.Importer.CurrentClient.ToString() + "'";

            if (dvPackage != null && dvPackage.Count > 0)
                CreateClientFeeFoFANote(this.Importer.CurrentClient.ToString());
            else
            { 
                DataView dvAdditionalService = Globals.dsCoinByClient.Tables["AdditionalService"].DefaultView;
                dvAdditionalService.RowFilter = "EntityGroupID='" + this.Importer.CurrentClient.ToString() + "'";
            
                if (dvAdditionalService != null && dvAdditionalService.Count > 0)
                    CreateClientFeeFoFANote(this.Importer.CurrentClient.ToString());
            }
        }

        private void CreateClientFeeFoFANote(string entityGroupID)
        {

            DataTable dt = InitTable();

            string NoteCategory = "Other";

            dt.Rows[0]["ClientNoteID"] = Guid.NewGuid().ToString();
            dt.Rows[0]["GroupID"] = entityGroupID;

            //for CBA, use the next line of code
            //NoteCategory = NoteCategoryMapping[((dvFileNotes.Count > 0) ? fileNoteRow["Subject"].ToString().Trim() : "")];
            if (CommonUI.MappingControl.CustomMapping && CommonUI.MappingControl.noteCategoryMapping.ContainsKey(NoteCategory))
                NoteCategory = CommonUI.MappingControl.noteCategoryMapping[NoteCategory];

            dt.Rows[0]["Subject"] = NoteCategory;
            dt.Rows[0]["noteSubject"] = "Client Group FoFA Data Image";
            dt.Rows[0]["Date"] = DateTime.Today.ToShortDateString();
            dt.Rows[0]["Note"] = "Attached is a copy of the FoFA data for this client group from (Fact Find > Client Fees). The copy was taken on " + DateTime.Today.ToShortDateString() + ".";

            Globals.AddToSetup("Note Categories|" + NoteCategory);
            this.Lines.Append(this.RowToString(dt));
            Globals.ClientFeeNoteList.Add(dt.Rows[0]["GroupID"].ToString(), dt.Rows[0]["ClientNoteID"].ToString());
            ++this.Count;

        }
    }
}
