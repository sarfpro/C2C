using System;
using System.Data;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
	public class ClientCustomCategoryHandler:ITableHandler
	{
		public ClientCustomCategoryHandler()
		{
			this.Description = "Client Custom Cats";
			this.Code = "CC";
			this.DataRelated = DataRelatedEnum.Client;
		}
		public override void Import() 
		{
			DataTable dt = InitTable();
			DataView dvCC  = Globals.dsCoinByClient.Tables["CLIENTCATEGORIES"].DefaultView;
			dvCC.RowFilter = "IsSystem = 0 AND ClientID='" + this.Importer.CurrentClient.ToString() + "'";

			for (int i = 0; i < dvCC.Count; ++i) 
			{
				DataRow row        = dvCC[i].Row;
                dt.Rows[0]["GroupID"] = row["ClientID"];

                string categoryName = row["Description"].ToString().Trim();
                string categoryValue = GetCustomCategory(row["ItemID"].ToString());
                string customCategory = categoryName + "|" + categoryValue;
                if (CommonUI.MappingControl.CustomMapping && CommonUI.MappingControl.customCategoryMapping.ContainsKey(customCategory))
                {
                    customCategory = CommonUI.MappingControl.customCategoryMapping[customCategory];
                    string[] categories = customCategory.Split('|');
                    categoryName = categories.Length > 0 ? categories[0].Trim() : "";
                    categoryValue = categories.Length > 1 ? categories[1].Trim() : "";
                }
                dt.Rows[0]["CategoryName"] = categoryName;
                dt.Rows[0]["CategoryValue"] = categoryValue;

                Globals.AddToSetup("Custom Categories|" + customCategory);

				this.Lines.Append(this.RowToString(dt));
				++this.Count;
			}
		}

		private string GetCustomCategory(string itemID) 
		{
			string customCategory = "";
			if (itemID != null && itemID != "") 
			{
				DataView dvItems = Globals.dsCoinByClient.Tables["Items"].DefaultView;
                dvItems.RowFilter = "ID='" + itemID + "'";
				if (dvItems.Count > 0) 
					customCategory = dvItems[0].Row["Name"].ToString();
			}
			return customCategory;
		}
		protected override void InitFields(DataTable dt)
		{
			string[] columns = {"GroupID","CategoryName","CategoryValue"};
			foreach(string col in columns)
				dt.Columns.Add(col);
		}

	}
}
