using System;
using System.Data;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
	/// <summary>
	/// Summary description for TransactionTypeHandler.
	/// </summary>
	public class TransactionTypeHandler : ITableHandler
	{
		public TransactionTypeHandler()
		{
			//
			// TODO: Add constructor logic here
			//
            this.Description = "Transaction Type";
            this.Code = "TT";
            this.DataRelated = DataRelatedEnum.Other;
		}

        public override void Import() 
        {
            DataView dvTransTypes = Globals.dsCoinGlobals.Tables["P_TransTypes"].DefaultView;
            dvTransTypes.Sort     = "TP_DispOrder";

            for (int i = 0; i < dvTransTypes.Count; ++i) 
            {
                DataTable dt = InitTable();
                DataRow ttRow = dvTransTypes[i].Row;

                dt.Rows[0]["TransactionType"]     = ttRow["TP_ID"];
                dt.Rows[0]["Description"]         = ttRow["TP_Desc"];
                dt.Rows[0]["CoinTransactionType"] = ttRow["TP_ID"];

                this.Lines.Append(this.RowToString(dt));
                ++this.Count;
            }
        }

        protected override void InitFields(DataTable dt) 
        {
            dt.Columns.Add("TransactionType");
            dt.Columns.Add("Description");
            dt.Columns.Add("CoinTransactionType");
        }
	}
}
