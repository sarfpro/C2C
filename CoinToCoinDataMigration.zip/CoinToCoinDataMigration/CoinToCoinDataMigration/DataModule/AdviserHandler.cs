using System;
using System.Data;
using HolisticFS.HSDB;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.Collections.Generic;

namespace CoinToCoinDataMigration.DataModule
{
    public class AdviserHandler : ITableHandler
    {
        //private static Dictionary<string, string> AdviserLookup = null;

        public AdviserHandler()
        {
            this.Description = "Adviser";
            this.Code = "AD";
            this.DataRelated = DataRelatedEnum.Other;
            //AdviserLookup = new Dictionary<string,string>();

        }

        static Regex regex = new Regex(@"(?<First>^[\S\s]+[^\S$]|^\S+$)(?<Last>\S+$)?", RegexOptions.Compiled);
        public override void Import()
        {
            DataView dvUsers = Globals.dsCoinGlobals.Tables["Users"].DefaultView;
            foreach (Guid userID in this.Importer.Advisers)
            {
                DataTable dt = InitTable();

                dvUsers.RowFilter = "ID='" + userID.ToString() + "'";
                DataRow userRow = dvUsers[0].Row;
                Debug.Assert(userRow != null, "User cannot be Null");
                string UserName = Globals.Clean(userRow["UserName"]);
                Match m = regex.Match(UserName);
                string fname = Globals.Clean(m.Groups["First"].Value);
                string lname = Globals.Clean(m.Groups["Last"].Value);
                Globals.AddToSetup("Adviser|" + UserName);
                Debug.Assert((fname + " " + lname).Trim() == UserName, "UserName must = fname and lname");
                dt.Rows[0]["AdviserID"] = UserName;
                dt.Rows[0]["Surname"] = lname;
                dt.Rows[0]["GivenName"] = fname;

                ++this.Count;
                this.Lines.Append(this.RowToString(dt));

                //AdviserLookup.Add("'"+userID+"'", UserName);
            }
        }

        protected override void InitFields(DataTable dt)
        {
            dt.Columns.Add("AdviserID");
            dt.Columns.Add("Surname");
            dt.Columns.Add("GivenName");
            dt.Columns.Add("Title");
            dt.Columns.Add("Qualification");
            dt.Columns.Add("CompanyName");
            dt.Columns.Add("Address1");
            dt.Columns.Add("Address2");
            dt.Columns.Add("Suburb");
            dt.Columns.Add("State");
            dt.Columns.Add("PostCode");
            dt.Columns.Add("WorkPhone");
            dt.Columns.Add("MobilePhone");
            dt.Columns.Add("Fax");
            dt.Columns.Add("Email");
            dt.Columns.Add("COINAdviserID");
        }

    }
}
