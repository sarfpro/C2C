using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Text.RegularExpressions;
using System.Diagnostics;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
    class VersionHandler : ITableHandler
    {
        public VersionHandler()
        {
            this.Description = "Version";
            this.Code = "Version";
            this.DataRelated = DataRelatedEnum.Other;
        }

        protected override void InitFields(DataTable dt)
        {
            dt.Columns.Add("Version");
        }

        public override void Import()
        {
            DataView dvVersion = Globals.dsCoinGlobals.Tables["CoinVersion"].DefaultView;
            DataRow versionRow = dvVersion[0].Row;

            DataTable dt = InitTable();
            dt.Rows[0]["Version"] = versionRow["Version"];

            ++this.Count;
            this.Lines.Append(this.RowToString(dt));
        }
    }
}
