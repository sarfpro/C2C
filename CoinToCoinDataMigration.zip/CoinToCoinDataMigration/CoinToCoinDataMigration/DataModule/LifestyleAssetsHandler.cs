using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
    public class LifestyleAssetsHandler : ITableHandler
    {
        public LifestyleAssetsHandler()
        {
            //
            // TODO: Add constructor logic here
            //
            this.Description = "Lifestyle Assets";
            this.Code = "LS";
            this.DataRelated = DataRelatedEnum.Client;
        }

        protected override void InitFields(DataTable dt)
        {
            dt.Columns.Add("ID");
            dt.Columns.Add("Group ID");
            dt.Columns.Add("Entity ID");
            dt.Columns.Add("Description");
            dt.Columns.Add("Amount");
            dt.Columns.Add("Centrelink Amount");
            dt.Columns.Add("Retain");
            dt.Columns.Add("Purchase Price");
            dt.Columns.Add("Purchase Date");
            dt.Columns.Add("Used As Security for Borrowing");
        }

        public override void Import()
        {
            DataTable dt = InitTable();
            DataView dvLSAsset = Globals.dsCoinByClient.Tables["LifestyleAssets"].DefaultView;
            dvLSAsset.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";

            for (int i = 0; i < dvLSAsset.Count; ++i)
            {
                DataRow lsAssetRow = dvLSAsset[i].Row;

                dt.Rows[0]["ID"] = lsAssetRow["ID"];
                dt.Rows[0]["Group ID"] = lsAssetRow["ClientID"];
                dt.Rows[0]["Entity ID"] = lsAssetRow["EntID"];
                dt.Rows[0]["Description"] = lsAssetRow["Description"];
                dt.Rows[0]["Amount"] = lsAssetRow["Amount"];
                dt.Rows[0]["Centrelink Amount"] = lsAssetRow["CentrelinkAmount"];
                dt.Rows[0]["Retain"] = lsAssetRow["LifeFFRetain"];
                dt.Rows[0]["Purchase Price"] = lsAssetRow["PurchasePrice"];
                dt.Rows[0]["Purchase Date"] = lsAssetRow["PurchaseDate"];
                dt.Rows[0]["Used As Security for Borrowing"] = lsAssetRow["AsSecurity"] != DBNull.Value ? ((bool)lsAssetRow["AsSecurity"] ? 1 : 0) : 0;
                
                //Globals.AddToSetup("Note Categories|" + fileNoteRow["Subject"]);
                this.Lines.Append(this.RowToString(dt));
                ++this.Count;
            }
        }
    }
}
