﻿using System;
using System.Data;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
    public class InsuranceOwnerHandler : ITableHandler
    {
        public InsuranceOwnerHandler()
		{
			this.Description = "Insurance Owner";
			this.Code = "IO";
			this.DataRelated = DataRelatedEnum.Client;
		}

        public override void Import()
        {
            DataTable dt = InitTable();

            string clientID = "'" + this.Importer.CurrentClient.ToString() + "'";

            string filter = "ClientID = " + clientID;

            foreach (DataRow row in Globals.dsCoinByClient.Tables["InsuranceOwner"].Select(filter))
            {
                dt.Rows[0]["Insurance Option ID"] = row["Insurance Option ID"];
                dt.Rows[0]["Amount"] = row["Amount"];
                dt.Rows[0]["Insurance ID"] = row["Insurance ID"];
                dt.Rows[0]["Entity ID"] = row["Entity ID"];
                dt.Rows[0]["TypeOfEntity"] = row["TypeofEntity"];
                dt.Rows[0]["EntityName"] = row["EntityName"];
                this.Lines.Append(this.RowToString(dt));
                ++this.Count;
            }
        }

        protected override void InitFields(DataTable dt)
        {
            string[] columns = { "Insurance ID", "Insurance Option ID", "Entity ID", "Amount", "TypeOfEntity", "EntityName" };
            foreach (string col in columns)
                dt.Columns.Add(col);
        }
    }
}
