using System;
using System.Data;

namespace CoinToCoinDataMigration.DataModule
{
	public class InsuranceOptionAmountHandler:ITableHandler
	{
		public InsuranceOptionAmountHandler()
		{
			this.Description = "Insurance Option Amount";
			this.Code = "IA";
			this.DataRelated = DataRelatedEnum.Client;
		}

		public override void Import() 
		{
			DataTable dt = InitTable();

			string clientID = "'" + this.Importer.CurrentClient.ToString() + "'";

			string filter = "ClientID = " + clientID;
		
			foreach(DataRow row in Globals.dsCoinByClient.Tables["InsuranceOptionAmount"].Select(filter))
			{
				dt.Rows[0]["Insurance Type"]		= row["Insurance Type"];
				dt.Rows[0]["Amount"]				= row["Amount"];
				dt.Rows[0]["Insurance ID"]			= row["Insurance ID"];

				this.Lines.Append(this.RowToString(dt));
				++this.Count;
			}

		}

		protected override void InitFields(DataTable dt)
		{
			string[] columns = {"Insurance Type","Amount","Insurance ID"};
			foreach(string col in columns)
				dt.Columns.Add(col);
		}
	}
}
