using System;
using System.Data;
using System.Collections.Generic;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
	public class ClientPreferenceHandler:ITableHandler
	{
        public ClientPreferenceHandler()
		{
			this.Description = "Client Preference";
			this.Code = "PR";
			this.DataRelated = DataRelatedEnum.Client;
		}
		public override void Import() 
		{
            // ------------------------------------------
            // This bit is for CBA
            // ------------------------------------------
            //Dictionary<string, string> PreferenceMapping = new Dictionary<string, string>(StringComparer.CurrentCultureIgnoreCase);
            //PreferenceMapping.Add("", "");
            //PreferenceMapping.Add("Monthly Newsletters", "Newsletter");
            //PreferenceMapping.Add("Calendar", "Generic 2");
            //PreferenceMapping.Add("June 30 Super Newsletter", "Generic 1");
            //PreferenceMapping.Add("Newsletter", "Newsletter");
            // ------------------------------------------

			DataTable dt = InitTable();
	
            DataView dv = Globals.dsCoinByClient.Tables["CLIENTCATEGORIES"].DefaultView;
            dv.RowFilter = "Description = 'Preference' AND ClientID='" + this.Importer.CurrentClient.ToString() + "'";
            string prefName = "";
			for (int i = 0; i < dv.Count; ++i) 
			{
                DataRow row = dv[i].Row;

                //For non-CBA, use the next line of code
                prefName = GetPrefName(row["ItemID"].ToString());
                //for CBA, use the next line of code
                //prefName = PreferenceMapping[((dv.Count > 0) ? GetPrefName(row["ItemID"].ToString()) : "")];
                if (CommonUI.MappingControl.CustomMapping && CommonUI.MappingControl.preferenceMapping.ContainsKey(prefName))
                    prefName = CommonUI.MappingControl.preferenceMapping[prefName];
                if (prefName.Trim().Length > 0)
                {
                    dt.Rows[0]["GroupID"] = row["ClientID"];
                    dt.Rows[0]["PreferenceName"] = prefName;
                    dt.Rows[0]["PreferenceValue"] = 1;
                    this.Lines.Append(this.RowToString(dt));
                    Globals.AddToSetup("Preferences|" + prefName);
                }
			    ++this.Count;
			}
		}

        private string GetPrefName(string itemID)
        {
            string prefName = "";
            if (itemID != null && itemID != "")
            {
                DataView dvItems = Globals.dsCoinByClient.Tables["Items"].DefaultView;
                dvItems.RowFilter = "ID='" + itemID + "'";
                if (dvItems.Count > 0)
                    prefName = dvItems[0].Row["Name"].ToString();
            }
            return prefName;
        }


		protected override void InitFields(DataTable dt)
		{
			string[] columns = {"GroupID","PreferenceName","PreferenceValue"};
			foreach(string col in columns)
				dt.Columns.Add(col);
		}

	}
}
