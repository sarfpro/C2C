using System;
using System.Data;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
	public class ClientDependentHandler:ITableHandler
	{
		public ClientDependentHandler()
		{
			this.Description = "Client Dependents";
			this.Code = "CD";
			this.DataRelated = DataRelatedEnum.Client;
		}
		public override void Import() 
		{
			DataTable dt = InitTable();
			DataView dvDependants  = Globals.dsCoinByClient.Tables["Dependants"].DefaultView;
            dvDependants.RowFilter = "EntityGroupID='" + this.Importer.CurrentClient.ToString() + "'";

			for (int i = 0; i < dvDependants.Count; ++i) 
			{
				DataRow dependantRow        = dvDependants[i].Row;
				dt.Rows[0]["ID"]				= dependantRow["ID"];
				dt.Rows[0]["EntityGroupID"]      = dependantRow["EntityGroupID"];
				dt.Rows[0]["ChildName"]			= dependantRow["ChildName"];
				dt.Rows[0]["Surname"]				= dependantRow["Surname"];
				dt.Rows[0]["ChildDOB"]				= dependantRow["ChildDOB"];
				dt.Rows[0]["Sex"]							= dependantRow["Sex"];
				dt.Rows[0]["Relationship"]         = dependantRow["Relationship"];
				dt.Rows[0]["Dependant"]			= (dependantRow["Dependant"] != DBNull.Value ? ((bool)dependantRow["Dependant"]?1:0 ):0);
				dt.Rows[0]["Occupation"]			= dependantRow["Occupation"];
                dt.Rows[0]["DepAge"]            = dependantRow["DepAge"];
				this.Lines.Append(this.RowToString(dt));
				++this.Count;
			}
		}
		protected override void InitFields(DataTable dt)
		{
			string[] columns = {"ID","EntityGroupID","ChildName","Surname","ChildDOB","Sex","Relationship","Dependant","Occupation","DepAge"};
			foreach(string col in columns)
				dt.Columns.Add(col);
		}

	}
}
