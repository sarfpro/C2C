using System;
using System.Data;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
	/// <summary>
	/// Summary description for AdviserTaskAssigneeHandler.
	/// </summary>
	public class AdviserTaskAssigneeHandler : ITableHandler
	{
		public AdviserTaskAssigneeHandler()
		{
			//
			// TODO: Add constructor logic here
			//
            this.Description = "Adviser Task Assignee";
            this.Code = "KS";
            this.DataRelated = DataRelatedEnum.Adviser; 
		}

        //CD 2011.4.5 bug 17404 to add _Archive _Old support, and blob storage support
        public override void Import()
        {
            Import("");
            Import("_Archive");
            Import("_Old");
        }
        // Bug 17404 to support _Archive/_Old tabes as well.
        private void Import(string suffix) 
        {
            DataTable dt = InitTable();
            DataView dvReviewUsers  = Globals.dsCoinByAdviser.Tables["AdviserReviewUsers" + suffix].DefaultView;
            dvReviewUsers.RowFilter = "UserID='" + this.Importer.CurrentAdviser.ToString() 
                                    + "' AND ClientID is null";

            for (int i = 0; i < dvReviewUsers.Count; ++i) {
                DataRow reviewUsersRow        = dvReviewUsers[i].Row;

                dt.Rows[0]["ID"]= reviewUsersRow["ID"];
                dt.Rows[0]["ReviewID"] = reviewUsersRow["ReviewID"];

                DataView dvUsers = Globals.dsCoinGlobals.Tables["Users"].DefaultView;
                dvUsers.RowFilter = "ID='" + reviewUsersRow["UserID"].ToString() + "'";
                string userName = dvUsers[0].Row["UserName"].ToString();

                dt.Rows[0]["UserID"] = userName;

                this.Lines.Append(this.RowToString(dt));
                ++this.Count;
            }
        }

        protected override void InitFields(DataTable dt) 
        {
            dt.Columns.Add("ID");
            dt.Columns.Add("ReviewID"); 
            dt.Columns.Add("UserID"); 
        }
	}
}
