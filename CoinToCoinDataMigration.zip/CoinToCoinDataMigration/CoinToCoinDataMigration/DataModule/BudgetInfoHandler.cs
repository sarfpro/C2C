using System;
using System.Data;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
	/// <summary>
	/// Summary description for BudgetInfoHandler.
	/// </summary>
	public class BudgetInfoHandler : ITableHandler
	{
		public BudgetInfoHandler()
		{
			//
			// TODO: Add constructor logic here
			//
            this.Description = "Budget Info";
            this.Code = "BU";
            this.DataRelated = DataRelatedEnum.Client;
		}

        public override void Import() 
        {
            DataView dvIncomeExpense  = Globals.dsCoinByClient.Tables["IncomeExpensesFactFind"].DefaultView;
            dvIncomeExpense.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";

            for (int i = 0; i < dvIncomeExpense.Count; ++i) 
            {
                DataRow ieRow = dvIncomeExpense[i].Row;

                DataTable dt = InitTable();
                dt.Rows[0]["EntityID"] = ieRow["ClientID"];
                dt.Rows[0]["EffectiveDate"] = Globals.GetDateString(ieRow["EffectiveDate"]);
                dt.Rows[0]["ClientSalary"] = ieRow["CWages"];
                dt.Rows[0]["SpouseSalary"] = ieRow["SWages"];
                dt.Rows[0]["ClientBonus"] = ieRow["CBonusComm"];
                dt.Rows[0]["SpouseBonus"] = ieRow["SBonusComm"];
                dt.Rows[0]["ClientCentrelinkTaxableIncome"] = ieRow["CCLinkIncome"];
                dt.Rows[0]["SpouseCentrelinkTaxableIncome"] = ieRow["SCLinkIncome"];
                dt.Rows[0]["ClientCentrelinkNonTaxableIncome"] = ieRow["CCLinkNonTaxable"];
                dt.Rows[0]["SpouseCentrelinkNonTaxableIncome"] = ieRow["SCLinkNonTaxable"];
                dt.Rows[0]["ClientOtherTaxableIncome"] = ieRow["COTI"];
                dt.Rows[0]["SpouseOtherTaxableIncome"] = ieRow["SOTI"];
                dt.Rows[0]["ClientOtherNonTaxableIncome"] = ieRow["CONTI"];
                dt.Rows[0]["SpouseOtherNonTaxableIncome"] = ieRow["SONTI"];
                dt.Rows[0]["ClientReportableFringeBenefits"] = ieRow["CORFB"];
                dt.Rows[0]["SpouseReportableFringeBenefits"] = ieRow["SORFB"];
                dt.Rows[0]["ClientTaxDeductions"] = ieRow["ClientTaxDeductExp"];
                dt.Rows[0]["SpouseTaxDeductions"] = ieRow["SpouseTaxDeductExp"];
                dt.Rows[0]["HousingExpenses"] = ieRow["HousingExp"];
                dt.Rows[0]["LoansExpenses"] = ieRow["LoansExp"];
                dt.Rows[0]["InsurancesExpenses"] = ieRow["InsuranceExp"];
                dt.Rows[0]["OtherExpenses"] = ieRow["PersonalExp"];

                this.Lines.Append(this.RowToString(dt));
                ++this.Count;
            }
        }

        protected override void InitFields(DataTable dt) 
        {
            dt.Columns.Add("EntityID");
            dt.Columns.Add("EffectiveDate");
            dt.Columns.Add("ClientSalary");
            dt.Columns.Add("SpouseSalary");
            dt.Columns.Add("ClientBonus");
            dt.Columns.Add("SpouseBonus");
            dt.Columns.Add("ClientCentrelinkTaxableIncome");
            dt.Columns.Add("SpouseCentrelinkTaxableIncome");
            dt.Columns.Add("ClientCentrelinkNonTaxableIncome");
            dt.Columns.Add("SpouseCentrelinkNonTaxableIncome");
            dt.Columns.Add("ClientOtherTaxableIncome");
            dt.Columns.Add("SpouseOtherTaxableIncome");
            dt.Columns.Add("ClientOtherNonTaxableIncome");
            dt.Columns.Add("SpouseOtherNonTaxableIncome");
            dt.Columns.Add("ClientReportableFringeBenefits");
            dt.Columns.Add("SpouseReportableFringeBenefits");
            dt.Columns.Add("ClientTaxDeductions");
            dt.Columns.Add("SpouseTaxDeductions");
            dt.Columns.Add("HousingExpenses");
            dt.Columns.Add("LoansExpenses");
            dt.Columns.Add("InsurancesExpenses");
            dt.Columns.Add("OtherExpenses");
        }
	}
}
