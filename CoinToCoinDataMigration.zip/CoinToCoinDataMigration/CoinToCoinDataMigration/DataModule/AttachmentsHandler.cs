using System;
using System.IO;
using System.Data;
using CoinDataConversionsIO;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
	/// <summary>
	/// Summary description for AttachmentsHandler.
	/// </summary>
	public class AttachmentsHandler : ITableHandler
	{
		public AttachmentsHandler()
		{
            Description = "Attachments";
            Code = "AT";
            DataRelated = DataRelatedEnum.Client;
		}

        //CD 2011.4.5 bug 17404 to add _Archive _Old support, and blob storage support
        public override void Import()
        {
            Import("");
            Import("_Archive");
            Import("_Old");
            Import("_DeletedClientGroups");
            ImportClientFeeFOFA();
        }

        private void Import(string suffix) 
        {
            DataView dvFileNotes  = Globals.dsCoinByClient.Tables["FileNotes" + suffix].DefaultView;
            dvFileNotes.RowFilter = "ClientID='" + Importer.CurrentClient.ToString() + "'";

            for (int i = 0; i < dvFileNotes.Count; ++i) 
            {
                DataRow fileNoteRow = dvFileNotes[i].Row;
                DataView dvAttachments;
                dvAttachments = Globals.dsCoinByClient.Tables["FileNoteAttachments" + suffix].DefaultView;
                dvAttachments.RowFilter = "FileNoteID='" + fileNoteRow["ID"].ToString() + "'";

				for (int j = 0; j < dvAttachments.Count; ++j) 
				{
					DataTable dt = InitTable();
					DataRow attachmentRow = dvAttachments[j].Row;

                    string fileName = "NoName";
                    if (!string.IsNullOrEmpty(attachmentRow["Description"].ToString()))
                        fileName = Utils.FileHandler.FormatFileName(attachmentRow["Description"].ToString());
                    if (fileName.Length > 60)
                    {
                        int fstart = fileName.Length - 59;
                        fileName = fileName.Substring(fstart);
                    }

                    Guid attachid = (Guid)attachmentRow["ID"];

					dt.Rows[0]["AttachmentID"]   = attachid;
					dt.Rows[0]["ClientNoteID"]   = attachmentRow["FileNoteID"];
					dt.Rows[0]["AttachmentDate"] = Globals.GetDateString(attachmentRow["AttDate"]);
                    //if (filename.Length > 80)
                    //    filename = filename.Replace(" ", "");

                    dt.Rows[0]["FileName"] = fileName;

                    string location1 = "attachments\\" + attachmentRow["ID"];
                    string fullpath1 = location1 + "\\" + fileName;

                    string location = attachmentRow["ID"].ToString();
                    string fullpath = location + "\\" + fileName;

                    dt.Rows[0]["Location"] = fullpath;


                    ProcessAttachments(attachid, location1, fullpath1, suffix);
                    Lines.Append(RowToString(dt));
					++Count;
				}
            }
        }

        private void ImportClientFeeFOFA()
        {
            if (Globals.ClientFeeAttachmentList != null && Globals.ClientFeeAttachmentList.Count > 0)
            {
                DataTable dt = InitTable();
                string groupID = this.Importer.CurrentClient.ToString();
                string noteID = null;
                string location = null;

                dt.Rows[0]["AttachmentID"] = Guid.NewGuid().ToString();
                if (Globals.ClientFeeNoteList.ContainsKey(groupID) && Globals.ClientFeeNoteList.TryGetValue(groupID, out noteID))
                    dt.Rows[0]["ClientNoteID"] = noteID;

                dt.Rows[0]["AttachmentDate"] = System.DateTime.Today.ToShortDateString();
                dt.Rows[0]["FileName"] = "Client Group FoFA Data.CSV";
                if (Globals.ClientFeeAttachmentList.ContainsKey(groupID) && Globals.ClientFeeAttachmentList.TryGetValue(groupID, out location))
                    dt.Rows[0]["Location"] = location;

                Lines.Append(RowToString(dt));
                ++Count;
            }
        }

        protected override void InitFields(DataTable dt) 
        {
            dt.Columns.Add("AttachmentID");
            dt.Columns.Add("ClientNoteID");
            dt.Columns.Add("AttachmentDate");
            dt.Columns.Add("FileName");
            dt.Columns.Add("Location");
        }

        private static void ProcessAttachments(Guid attachid, string location, string filename, string suffix)
        {
            //string execString = string.Format("SELECT Attachment FROM FileNoteAttachments Where Id = '{0}'", attachid);

            //byte[] image;
            //image = (byte [])HSDBInterfaceManager.RunExecuteScalar(Globals.commProvider, execString);

            //bug 17404 - to add blob storage support.
            byte[] image = null;
            try
            {                
                HSDBTableSpecs ts = new HSDBTableSpecs();
                ts.IsStoredProcedure = true;
                ts.SelectSql = "%HS.BS.Get.FileNoteAttachments" + suffix + ".Attachment";
                ts.AddParameter("PK_ID", attachid, ParamValueType.vtNativeID, ParameterDirection.Input);
                HSDBSqlParam pData = ts.AddOutputParameter("BlobData", ParamValueType.vtImage);

                HSDBInterfaceManager.RunExecuteNonQueryMulti(Globals.commProvider, new HSDBTableSpecs[] { ts }, false);

                if (pData.Value != DBNull.Value)
                    image = (byte[])pData.Value;
                else
                    image = new byte[0];

                string tempFileName = Path.GetTempFileName();

                Utils.FileHandler.WriteToFile(tempFileName, image);
                Directory.CreateDirectory(location);
                try
                {
                    Utils.FileHandler.DecompressAttachmentFile(tempFileName, filename);
                }
                catch
                {
                    Utils.FileHandler.WriteToFile(filename, image);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
	}
}
