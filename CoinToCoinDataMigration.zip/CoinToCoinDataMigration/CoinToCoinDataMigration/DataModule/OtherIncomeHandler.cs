using System;
using System.Data;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
	/// <summary>
	/// Summary description for OtherIncomeHandler.
	/// </summary>
	public class OtherIncomeHandler : ITableHandler
	{
		public OtherIncomeHandler()
		{
			//
			// TODO: Add constructor logic here
			//
            this.Description = "Other Income";
            this.Code = "IN";
            this.DataRelated = DataRelatedEnum.Client;
		}

        public override void Import() 
        {
            DataView dvClientLifeStyle  = Globals.dsCoinByClient.Tables["ClientLifeStyleGoals"].DefaultView;
            dvClientLifeStyle.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";

            for (int i = 0; i < dvClientLifeStyle.Count; ++i) 
            {
                DataRow clientLifeStyleRow = dvClientLifeStyle[i].Row;

                DataView dvLifeStyle  = Globals.dsCoinGlobals.Tables["LifeStyleGoals"].DefaultView;
                dvLifeStyle.RowFilter = "ID='" + clientLifeStyleRow["LifeStyleGoalID"].ToString() + "'";
                DataRow lifeStyleRow  = dvLifeStyle[0].Row;
                string isIncome       = lifeStyleRow["IsIncome"].ToString();

                if (isIncome.ToLower() == "true") 
                {                    
                    DataTable dt = InitTable();

                    string entityID = "";
                    if (clientLifeStyleRow["Entity"].ToString() == "CLI") 
                    {
                        DataView dvEntClient  = Globals.dsCoinByClient.Tables["Ent_Clients"].DefaultView;
                        dvEntClient.RowFilter = "EntityGroupID='" + this.Importer.CurrentClient.ToString() + "'";
                        entityID = dvEntClient[0].Row["EntityID"].ToString();
                    } 
                    else if (clientLifeStyleRow["Entity"].ToString() == "SPS") 
                    {
                        DataView dvEntSpouse  = Globals.dsCoinByClient.Tables["Ent_Spouses"].DefaultView;
                        dvEntSpouse.RowFilter = "EntityGroupID='" + this.Importer.CurrentClient.ToString() + "'";
                        entityID = dvEntSpouse[0].Row["EntityID"].ToString();
                    } 
                    else if (clientLifeStyleRow["Entity"].ToString() == "JOI") 
                    {
                        DataView dvJoint  = Globals.dsCoinByClient.Tables["Joint"].DefaultView;
                        dvJoint.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";
                        entityID = dvJoint[0].Row["ID"].ToString();
                    }

                    dt.Rows[0]["EntityID"]    = entityID;
                    dt.Rows[0]["AgeFrom"]     = clientLifeStyleRow["AgeFrom"];
                    dt.Rows[0]["AgeTo"]       = clientLifeStyleRow["AgeTo"];
                    dt.Rows[0]["Capital"]     = clientLifeStyleRow["Capital"];
                    dt.Rows[0]["Taxable"]     = clientLifeStyleRow["Taxable"];
                    dt.Rows[0]["Frequency"]   = clientLifeStyleRow["Frequency"];

                    //dt.Rows[0]["Description"] = Globals.Clean(lifeStyleRow["Description"]);

                    //For non-CBA, use the next line of code
                    string income = Globals.Clean(lifeStyleRow["Description"]);

                    //for CBA, use the next line of code
                    if (CommonUI.MappingControl.CustomMapping && CommonUI.MappingControl.incomeMapping.ContainsKey(income))
                        income = CommonUI.MappingControl.incomeMapping[income];
                    
                    dt.Rows[0]["Description"] = income;

                    Globals.AddToSetup("Income|" + Globals.Clean(income));
                    this.Lines.Append(this.RowToString(dt));
                    ++this.Count;
                }
            }
        }

        protected override void InitFields(DataTable dt) 
        {
            dt.Columns.Add("EntityID");
            dt.Columns.Add("AgeFrom");
            dt.Columns.Add("AgeTo");
            dt.Columns.Add("Capital");
            dt.Columns.Add("Taxable");
            dt.Columns.Add("Frequency");
            dt.Columns.Add("Description");
			dt.Columns.Add("Unknown");
        }
	}
}