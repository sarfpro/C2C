using System;
using System.Data;
using System.Text;
using System.Windows.Forms;
using CoinDataConversionsIO;

namespace CoinToCoinDataMigration.DataModule
{
    public enum DataRelatedEnum { Adviser, Client, Other };

	/// <summary>
	/// Summary description for ITableHandler.
	/// </summary>
	public abstract class ITableHandler
	{
        public ITableHandler()
        {
            //
            // TODO: Add constructor logic here
            //
            this.Description = "";
            this.Code = "";
            this.IsMigrated = true;
        }

        private string description;
        public string Description
        {
            get{return this.description;}
            set{this.description = value;}
        }

        private string code;
        public string Code
        {
            get{return this.code;}
            set{this.code = value;}
        }

        private bool isMigrated;
        public bool IsMigrated
        {
            get{return this.isMigrated;}
            set{this.isMigrated = value;}
        }

        private bool isClientRelated;
        public bool IsClientRelated
        {
            get { return this.isClientRelated; }
            set { this.isClientRelated = value; }
        }

        private DataRelatedEnum dataRelated;

        public DataRelatedEnum DataRelated
        {
            get{return this.dataRelated;}
            set{this.dataRelated = value;}
        }

        private int count;
        public int Count
        {
            get{return this.count;}
            set{this.count = value;}
        }

        private StringBuilder lines = new StringBuilder();
        public StringBuilder Lines
        {
            get{return this.lines;}
        }

        private Importer.Importer importer;
        public Importer.Importer Importer
        {
            get{return this.importer;}
            set{this.importer = value;}
        }

        public override string ToString() 
        {
            return Description + " (" + Code + ")";
        }

        public abstract void Import();

        protected DataTable InitTable() 
        {
            DataTable dt = new DataTable(this.Description);
            DataRow row = dt.NewRow();
            dt.Rows.Add(row);

            InitFields(dt);

            foreach (DataColumn column in dt.Columns) 
            {
                dt.Rows[0][column] = "";
            }

            return dt;
        }

        protected abstract void InitFields(DataTable dt);

        protected string RowToString(DataTable dt) 
        {
            string line = "";
            for (int i = 0; i < dt.Columns.Count; ++i) 
            {
                DataColumn column = dt.Columns[i];
                line += ((i != 0) ? "," : "") + Globals.Clean(dt.Rows[0][column.ColumnName].ToString().Trim().Replace(",", "(ccc)").Replace(Environment.NewLine, "(nnn)"));
            }
            line += Environment.NewLine;

            return line;
        }
	}
}
