using System;
using System.Data;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
    /// <summary>
    /// Summary description for RiskProfileHandler.
    /// </summary>
    public class RiskProfileHandler : ITableHandler
    {
        public RiskProfileHandler()
        {
            //
            // TODO: Add constructor logic here
            //
            this.Description = "Risk Profile";
            this.Code = "RP";
            this.DataRelated = DataRelatedEnum.Client;
        }

        public override void Import()
        {
            DataView dvEntClients = Globals.dsCoinByClient.Tables["Ent_Clients"].DefaultView;
            dvEntClients.RowFilter = "EntityGroupID='" + this.Importer.CurrentClient.ToString() + "'";

            string clientRiskProfile = "";
            if (dvEntClients.Count > 0)
            {
                clientRiskProfile = GetRiskProfile(dvEntClients[0].Row["RiskProfileID"].ToString());
                if (CommonUI.MappingControl.CustomMapping && CommonUI.MappingControl.riskprofileMapping.ContainsKey(clientRiskProfile))
                    clientRiskProfile = CommonUI.MappingControl.riskprofileMapping[clientRiskProfile];
                Globals.AddToSetup("Risk Profile|" + clientRiskProfile);
            }

            DataView dvEntSpouses = Globals.dsCoinByClient.Tables["Ent_Spouses"].DefaultView;
            dvEntSpouses.RowFilter = "EntityGroupID='" + this.Importer.CurrentClient.ToString() + "'";

            string spouseRiskProfile = "";
            if (dvEntSpouses.Count > 0)
            {
                spouseRiskProfile = GetRiskProfile(dvEntSpouses[0].Row["RiskProfileID"].ToString());
                if (CommonUI.MappingControl.CustomMapping && CommonUI.MappingControl.riskprofileMapping.ContainsKey(spouseRiskProfile))
                    spouseRiskProfile = CommonUI.MappingControl.riskprofileMapping[spouseRiskProfile];
                Globals.AddToSetup("Risk Profile|" + spouseRiskProfile);
            }

            DataView dvClientCategories = Globals.dsCoinByClient.Tables["ClientCategories"].DefaultView;
            dvClientCategories.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "' and Description='Class'";

            string rating = "";
            if (dvClientCategories.Count > 0)
            {
                rating = GetRating(dvClientCategories[0].Row["ItemID"].ToString());
            }

            DataTable dt = InitTable();
            dt.Rows[0]["GroupID"] = (dvEntClients.Count > 0) ? dvEntClients[0].Row["EntityGroupID"] : Guid.Empty;
            dt.Rows[0]["ClientRiskProfile"] = clientRiskProfile;
            dt.Rows[0]["ClientRating"] = rating;
            dt.Rows[0]["SpouseRiskProfile"] = spouseRiskProfile;
            dt.Rows[0]["SpouseRating"] = rating;

            this.Lines.Append(this.RowToString(dt));
            ++this.Count;
        }

        protected override void InitFields(DataTable dt)
        {
            dt.Columns.Add("GroupID");
            dt.Columns.Add("ClientRating");
            dt.Columns.Add("ClientRiskProfile");
            dt.Columns.Add("SpouseRating");
            dt.Columns.Add("SpouseRiskProfile");
        }

        private string GetRiskProfile(string riskProfileID)
        {
            string riskProfile = "";
            if (riskProfileID != null && riskProfileID.Trim() != "")
            {
                DataView dvRiskProfiles = Globals.dsCoinGlobals.Tables["InvestmentProfiles"].DefaultView;
                dvRiskProfiles.RowFilter = "ID='" + riskProfileID + "'";

                if (dvRiskProfiles.Count > 0)
                {
                    riskProfile = dvRiskProfiles[0].Row["Name"].ToString();
                }
            }
            return riskProfile;
        }

        private string GetRating(string itemID)
        {
            string rating = "";
            if (itemID != null && itemID.Trim() != "")
            {
                DataView dvItems = Globals.dsCoinByClient.Tables["Items"].DefaultView;
                dvItems.RowFilter = "ID='" + itemID + "'";

                if (dvItems.Count > 0)
                {
                    rating = dvItems[0].Row["Name"].ToString();
                }
            }
            return rating;
        }
    }
}
