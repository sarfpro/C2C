using System;
using System.Data;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
    /// <summary>
    /// Summary description for LoansHandler.
    /// </summary>
    public class LoansHandler : ITableHandler
    {
        public LoansHandler()
        {
            //
            // TODO: Add constructor logic here
            //
            this.Description = "Loan";
            this.Code = "LO";
            this.DataRelated = DataRelatedEnum.Client;
        }

        public override void Import()
        {
            DataTable dt = InitTable();
            DataView dvLoans = Globals.dsCoinByClient.Tables["Loans"].DefaultView;
            dvLoans.RowFilter = "[Group ID]='" + this.Importer.CurrentClient.ToString() + "'";

            for (int i = 0; i < dvLoans.Count; ++i)
            {
                DataRow loanRow = dvLoans[i].Row;

                dt.Rows[0]["ID"] = loanRow["ID"];
                dt.Rows[0]["Description"] = loanRow["Description"];
                dt.Rows[0]["Loan Type"] = loanRow["Loan Type"];
                dt.Rows[0]["Repayment Rate"] = loanRow["Repayment Rate"];
                dt.Rows[0]["Amount"] = loanRow["Amount"];
                dt.Rows[0]["Repayment Type"] = loanRow["Repayment Type"];
                dt.Rows[0]["Frequency"] = loanRow["Frequency"];
                dt.Rows[0]["Repayment Amount"] = loanRow["Repayment Amount"];
                dt.Rows[0]["Regular Fees (per month)"] = loanRow["Regular Fees (per month)"];
                dt.Rows[0]["Fee Limit Amount"] = loanRow["Fee Limit Amount"];
                dt.Rows[0]["Apply Limit on Fees"] = loanRow["Apply Limit on Fees"];
                dt.Rows[0]["Secured By"] = loanRow["Secured By"];
                dt.Rows[0]["Group ID"] = loanRow["Group ID"];
                dt.Rows[0]["Comment"] = Globals.NotesTextConverter(loanRow["Comment"].ToString());
                dt.Rows[0]["Available Redraw Amount"] = loanRow["Available Redraw Amount"];
                dt.Rows[0]["Margin Lending Type Description"] = loanRow["Margin Lending Type Description"];
                dt.Rows[0]["Deductible %"] = loanRow["Deductible %"];
                dt.Rows[0]["Early Repay Costs"] = loanRow["Early Repay Costs"];
                dt.Rows[0]["Account Number"] = loanRow["Account Number"];
                dt.Rows[0]["Lender"] = loanRow["Lender"];
                dt.Rows[0]["Valuation Date"] = Globals.GetDateString(loanRow["Valuation Date"]);
                dt.Rows[0]["Repayment End Date"] = Globals.GetDateString(loanRow["Repayment End Date"]);
                dt.Rows[0]["Loan Status ID"] = loanRow["Loan Status ID"];
                dt.Rows[0]["Retain"] = loanRow["Retain"];
                dt.Rows[0]["Entity ID"] = loanRow["Entity ID"];

                //Globals.AddToSetup("Note Categories|" + fileNoteRow["Subject"]);
                this.Lines.Append(this.RowToString(dt));
                ++this.Count;
            }
        }

        protected override void InitFields(DataTable dt)
        {
            dt.Columns.Add("ID");
            dt.Columns.Add("Description");
            dt.Columns.Add("Loan Type");
            dt.Columns.Add("Repayment Rate");
            dt.Columns.Add("Amount");
            dt.Columns.Add("Repayment Type");
            dt.Columns.Add("Frequency");
            dt.Columns.Add("Repayment Amount");
            dt.Columns.Add("Regular Fees (per month)");
            dt.Columns.Add("Fee Limit Amount");
            dt.Columns.Add("Apply Limit on Fees");
            dt.Columns.Add("Secured By");
            dt.Columns.Add("Group ID");
            dt.Columns.Add("Comment");
            dt.Columns.Add("Available Redraw Amount");
            dt.Columns.Add("Margin Lending Type Description");
            dt.Columns.Add("Deductible %");
            dt.Columns.Add("Early Repay Costs");
            dt.Columns.Add("Account Number");
            dt.Columns.Add("Lender");
            dt.Columns.Add("Valuation Date");
            dt.Columns.Add("Repayment End Date");
            dt.Columns.Add("Loan Status ID");
            dt.Columns.Add("Retain");
            dt.Columns.Add("Entity ID");
        }
    }
}
