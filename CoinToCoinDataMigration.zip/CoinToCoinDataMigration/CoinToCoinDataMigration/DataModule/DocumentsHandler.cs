using System;
using System.IO;
using System.Data;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
	/// <summary>
	/// Summary description for DocumentsHandler.
	/// </summary>
	public class DocumentsHandler : ITableHandler
	{
		public DocumentsHandler()
		{
            this.Description = "Documents";
            this.Code = "DO";
            this.DataRelated = DataRelatedEnum.Client;
		}

        //CD 2011.4.5 bug 17404 to add _Archive _Old support, and blob storage support
        public override void Import()
        {
            Import("");
            Import("_Archive");
            Import("_Old");
            Import("_DeletedClientGroups");
        }
        // suffix: to support _Archive/_Old tabes as well.
        private void Import(string suffix) 
        {
            DataView dvDocumentList  = Globals.dsCoinByClient.Tables["DocumentList" + suffix].DefaultView;
            dvDocumentList.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";

            for (int i = 0; i < dvDocumentList.Count; ++i) 
            {
                DataRow documentListRow = dvDocumentList[i].Row;
                DataView dvDocuments = Globals.dsCoinByClient.Tables["Documents" + suffix].DefaultView;
                dvDocuments.RowFilter = "ID='" + documentListRow["ID"].ToString() + "'";
 
			    DataTable dt = InitTable();
			    DataRow documentRow = dvDocuments[0].Row;

                Guid id = (Guid) documentRow["ID"];

			    dt.Rows[0]["ID"]   = id;
                dt.Rows[0]["Zipped"] = documentRow["Zipped"];

                string filename = "NoName";
                if (!string.IsNullOrEmpty(Utils.FileHandler.FormatFileName(documentListRow["DocName"].ToString())) && (!string.IsNullOrEmpty(documentListRow["FileType"].ToString()))) 
                    //Sometimes the file type column contains a "."     
                    filename = Utils.FileHandler.FormatFileName(documentListRow["DocName"].ToString()) + "." + documentListRow["FileType"].ToString().Replace(".", string.Empty);
                if (filename.Length > 60)
                {
                    int fstart = filename.Length - 59;
                    filename = filename.Substring(fstart);
                }

                dt.Rows[0]["FileName"] = filename.TrimStart(' ');
                string directoryPath = "documents\\" + documentRow["ID"].ToString() + "\\";
                dt.Rows[0]["Location"] = directoryPath + filename.TrimStart(' ');
                Directory.CreateDirectory(directoryPath);

                //Documents are either compressed or not compressed (unlike Task Attachments which are always compressed)
                ProcessAttachments(id, directoryPath, directoryPath + filename.TrimStart(' '), (bool)documentRow["Zipped"], suffix);                 
			    this.Lines.Append(this.RowToString(dt));
			    ++this.Count;				
            }
        }

        protected override void InitFields(DataTable dt) 
        {
            dt.Columns.Add("ID");
            dt.Columns.Add("Zipped");
            dt.Columns.Add("FileName");
            dt.Columns.Add("Location");
        }

        private void ProcessAttachments(Guid attachid, string location, string filename, bool Zipped, string suffix)
        {
            //string execString = string.Format("SELECT Document FROM Documents Where Id = '{0}'", attachid);

            //bug 17404 - to add blob storage support.
            byte[] image = null;
            try
            {
                //byte[] image=null;
                //image = (byte[])HSDBInterfaceManager.RunExecuteScalar(Globals.commProvider, execString);
                HSDBTableSpecs ts = new HSDBTableSpecs();
                ts.IsStoredProcedure = true;
                ts.SelectSql = "%HS.BS.Get.Documents" + suffix + ".Document";
                ts.AddParameter("PK_ID", attachid, ParamValueType.vtNativeID, ParameterDirection.Input);
                HSDBSqlParam pData = ts.AddOutputParameter("BlobData", ParamValueType.vtImage);

                HSDBInterfaceManager.RunExecuteNonQueryMulti(Globals.commProvider, new HSDBTableSpecs[] { ts }, false);

                if (pData.Value != DBNull.Value)
                    image = (byte[])pData.Value;
                else
                    image = new byte[0];

                //if (Zipped)
                //{
                    string tempFileName = Path.GetTempFileName();
                    Utils.FileHandler.WriteToFile(tempFileName, image);
                    //Directory.CreateDirectory(location);
                    try
                    {
                        Utils.FileHandler.DecompressAttachmentFile(tempFileName, filename);
                    }
                    catch
                    {
                        Utils.FileHandler.WriteToFile(filename, image);
                    }
                //}
                //else
                //    Utils.FileHandler.WriteToFile(filename, (byte[])image);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
	}
}
