using System;
using System.Data;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
	/// <summary>
	/// Summary description for IrregularExpensesHandler.
	/// </summary>
	public class IrregularExpensesHandler : ITableHandler
	{
		public IrregularExpensesHandler()
		{
			//
			// TODO: Add constructor logic here
			//
            this.Description = "Irregular Expenses";
            this.Code = "EX";
            this.DataRelated = DataRelatedEnum.Client;
		}

        public override void Import() 
        {
            DataView dvClientLifeStyle  = Globals.dsCoinByClient.Tables["ClientLifeStyleGoals"].DefaultView;;
            dvClientLifeStyle.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";

            for (int i = 0; i < dvClientLifeStyle.Count; ++i) 
            {
                DataRow clientLifeStyleRow = dvClientLifeStyle[i].Row;

                DataView dvLifeStyle  = Globals.dsCoinGlobals.Tables["LifeStyleGoals"].DefaultView;                
                if (clientLifeStyleRow["LifeStyleGoalID"] != null)
                {
                    dvLifeStyle.RowFilter = "ID='" + clientLifeStyleRow["LifeStyleGoalID"].ToString() + "'";
                    DataRow lifeStyleRow  = dvLifeStyle[0].Row;
                    string isIncome       = lifeStyleRow["IsIncome"].ToString();

                    if (isIncome.ToLower() == "false")
                    {
                        DataTable dt = InitTable();

                        string entityID = "";
                        if (clientLifeStyleRow["Entity"].ToString() == "CLI")
                        {
                            DataView dvEntClient = Globals.dsCoinByClient.Tables["Ent_Clients"].DefaultView;
                            entityID = dvEntClient[0].Row["EntityID"].ToString();
                        }
                        else if (clientLifeStyleRow["Entity"].ToString() == "SPS")
                        {
                            DataView dvEntSpouse = Globals.dsCoinByClient.Tables["Ent_Spouses"].DefaultView;
                            entityID = dvEntSpouse[0].Row["EntityID"].ToString();
                        }
                        else if (clientLifeStyleRow["Entity"].ToString() == "JOI")
                        {
                            DataView dvJoint = Globals.dsCoinByClient.Tables["Joint"].DefaultView;
                            entityID = dvJoint[0].Row["ID"].ToString();
                        }

                        dt.Rows[0]["EntityID"] = entityID;
                        dt.Rows[0]["AgeFrom"] = clientLifeStyleRow["AgeFrom"];
                        dt.Rows[0]["AgeTo"] = clientLifeStyleRow["AgeTo"];
                        dt.Rows[0]["Capital"] = clientLifeStyleRow["Capital"];
                        dt.Rows[0]["Frequency"] = clientLifeStyleRow["Frequency"];
                        dt.Rows[0]["Description"] = lifeStyleRow["Description"];

                        Globals.AddToSetup("Expense|" + Globals.Clean(lifeStyleRow["Description"]));
                        this.Lines.Append(this.RowToString(dt));
                        ++this.Count;
                    }
                }
            }
        }

        protected override void InitFields(DataTable dt) 
        {
            dt.Columns.Add("EntityID");
            dt.Columns.Add("AgeFrom");
            dt.Columns.Add("AgeTo");
            dt.Columns.Add("Capital");
            dt.Columns.Add("Frequency");
            dt.Columns.Add("Description");
			dt.Columns.Add("Unknown");
        }
	}
}
