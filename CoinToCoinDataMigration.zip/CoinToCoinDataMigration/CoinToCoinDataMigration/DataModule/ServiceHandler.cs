using System;
using System.Data;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
	/// <summary>
	/// Summary description for ServiceHandler.
	/// </summary>
	public class ServiceHandler : ITableHandler
	{
		public ServiceHandler()
		{
			//
			// TODO: Add constructor logic here
			//
            this.Description = "Service";
            this.Code = "SE";
            this.DataRelated = DataRelatedEnum.Other;
		}

        public override void Import() 
        {
            DataTable dt = InitTable();
            DataView dvServices = Globals.dsCoinGlobals.Tables["Services"].DefaultView;

            string filter = "";
            foreach (Guid userID in this.Importer.Advisers) 
            {
                filter += " OR UserID='" + userID.ToString() + "'";
            }
            filter = "UserID is null " + filter;

            dvServices.RowFilter = filter;

            for (int i = 0; i < dvServices.Count; ++i) 
            {
                if (!Globals.ServiceInSM)
                {
                    DataRow serviceRow = dvServices[i].Row;

                    dt.Rows[0]["ServiceID"] = serviceRow["ID"];
                    dt.Rows[0]["ServiceName"] = serviceRow["Description"].ToString().Replace(",", "").Replace("'", "");
                    dt.Rows[0]["ServiceType"] = serviceRow["ServiceType"];
                    dt.Rows[0]["ServiceCode"] = serviceRow["ID"];

                    this.Lines.Append(this.RowToString(dt));
                    ++this.Count;
                }
                else
                {
                    DataRow serviceRow = dvServices[i].Row;

                    if (Globals.ServiceInSMList.Contains(serviceRow["ID"].ToString()))
                    {
                        dt.Rows[0]["ServiceID"] = serviceRow["ID"];
                        dt.Rows[0]["ServiceName"] = serviceRow["Description"].ToString().Replace(",", "").Replace("'", "");
                        dt.Rows[0]["ServiceType"] = serviceRow["ServiceType"];
                        dt.Rows[0]["ServiceCode"] = serviceRow["ID"];

                        this.Lines.Append(this.RowToString(dt));
                        ++this.Count;
                    }
                }
            }
        }

        protected override void InitFields(DataTable dt) 
        {
            dt.Columns.Add("ServiceID");
            dt.Columns.Add("ServiceName");
            dt.Columns.Add("ServiceType");
            dt.Columns.Add("ServiceCode");
        }
	}
}
