using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Diagnostics;
using HolisticFS.HSDB;
using CoinToCoinDataMigration.Utils;

namespace CoinToCoinDataMigration.DataModule
{
    class ProfessionalAdvisersHandler : ITableHandler
    {
        public ProfessionalAdvisersHandler()
        {
            this.Description = "Professional Advisers";
            this.Code = "PA";
            this.DataRelated = DataRelatedEnum.Other;
        }

        protected override void InitFields(DataTable dt)
        {
            dt.Columns.Add("ProfessionalID");
            dt.Columns.Add("ProfessionalType");
            dt.Columns.Add("Surname");
            dt.Columns.Add("FirstName");
            dt.Columns.Add("Title");
            dt.Columns.Add("Company");
            dt.Columns.Add("Position");
            dt.Columns.Add("WorkPhone");
            dt.Columns.Add("WorkFax");
            dt.Columns.Add("Email");
            dt.Columns.Add("Mobile");
            dt.Columns.Add("BusinessAddressLine1");
            dt.Columns.Add("BusinessAddressLine2");
            dt.Columns.Add("BusinessSuburb");
            dt.Columns.Add("BusinessState");
            dt.Columns.Add("BusinessPostCode");
            dt.Columns.Add("BusinessCountry");
        }

        public override void Import()
        {
            DataTable dt = InitTable();
            DataView dvProAdvisers = Globals.dsCoinGlobals.Tables["Professionals"].DefaultView;

            for (int i = 0; i < dvProAdvisers.Count; ++i)
            {
                DataRow proAdviserRow = dvProAdvisers[i].Row;

                dt.Rows[0]["ProfessionalID"] = proAdviserRow["ID"];
                dt.Rows[0]["ProfessionalType"] = proAdviserRow["Type"];
                dt.Rows[0]["Surname"] = proAdviserRow["Surname"];
                dt.Rows[0]["FirstName"] = proAdviserRow["FirstName"];
                dt.Rows[0]["Title"] = proAdviserRow["Title"];
                dt.Rows[0]["Company"] = proAdviserRow["Company"];
                dt.Rows[0]["Position"] = proAdviserRow["Position"];
                dt.Rows[0]["WorkPhone"] = proAdviserRow["WorkPhone"];
                dt.Rows[0]["WorkFax"] = proAdviserRow["WorkFax"];
                dt.Rows[0]["Email"] = proAdviserRow["Email"];
                dt.Rows[0]["Mobile"] = proAdviserRow["Mobile"];
                dt.Rows[0]["BusinessAddressLine1"] = proAdviserRow["BALine1"];
                dt.Rows[0]["BusinessAddressLine2"] = proAdviserRow["BALine2"];
                dt.Rows[0]["BusinessSuburb"] = proAdviserRow["BASuburb"];
                dt.Rows[0]["BusinessState"] = proAdviserRow["BAState"];
                dt.Rows[0]["BusinessPostCode"] = proAdviserRow["BAPostCode"];
                dt.Rows[0]["BusinessCountry"] = proAdviserRow["BACountry"];

                this.Lines.Append(this.RowToString(dt));
                ++this.Count;
            }
        }
    }
}
