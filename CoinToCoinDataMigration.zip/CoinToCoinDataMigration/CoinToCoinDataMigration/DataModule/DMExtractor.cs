										using System;
using System.Data;
using System.Collections;
using System.Globalization;

using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
	/// <summary>
	/// Summary description for DMExtractor.
	/// </summary>
    /// 
    public class DMExtractor
	{
        public static DataSet GetCoinDataSetGlobals() 
        {
            int i = 0;
            HSDBTableSpecs[] tsCoin = HSDBTableSpecs.NewArray(10);  
            tsCoin[i].TableName     = "Users";
            tsCoin[i++].SelectSql   = "SELECT ID, UserName, DealerGroupID FROM Users WHERE LoginID != '__upgrade' AND LoginID != 'dgadmin'";
            tsCoin[i].TableName     = "UserContact";
            tsCoin[i++].SelectSql   = "SELECT UserID, AdvisorTitle, Qualification, AdvisorCompany, Addr1, Addr2, Suburb, State, PostCode, HomePhone, Mobile, Fax, Email FROM UserContact";
            tsCoin[i].TableName     = "Products";
            tsCoin[i++].SelectSql   = "SELECT ID, Description, SectorCode, APIRCode, IsUnitised, TaxCode, DealerGroupID FROM Products";
            tsCoin[i].TableName     = "Services";
            tsCoin[i++].SelectSql   = "SELECT ID, Description, ServiceType, UserID FROM Services";
            tsCoin[i].TableName     = "InvestmentProfiles";
            tsCoin[i++].SelectSql   = "select ID, Name from investmentprofiles";
            tsCoin[i].TableName     = "LifeStyleGoals";
            tsCoin[i++].SelectSql   = "select ID, Description, IsIncome from LifeStyleGoals";
            tsCoin[i].TableName     = "P_TransTypes";
            tsCoin[i++].SelectSql   = "SELECT TP_ID, TP_Desc, TP_DispOrder FROM P_TransTypes";
            tsCoin[i].TableName     = "DataFeedClientMapping";
            tsCoin[i++].SelectSql   = "SELECT * FROM DataFeedClientMapping";
            tsCoin[i].TableName = "Professionals";
            tsCoin[i++].SelectSql = "select professionals.id as ID, professionals.type as Type, professionals.surname as Surname, professionals.firstname as Firstname, professionals.title as Title, professionals.company as Company, professionals.position as Position, professionals.workphone as Workphone, professionals.workfax as Workfax, professionals.email as Email, professionals.mobile as Mobile, address.street1 as BALine1, address.street2 as BALine2, address.suburb as BASuburb, address.state as BAState, address.postcode as BAPostcode, address.country as BACountry from (professionals join addresslist on professionals.addresslistid = addresslist.addresslistid) join address on addresslist.addressid = address.id where addresslist.Type = 'Business'";
            tsCoin[i].TableName = "CoinVersion";
            tsCoin[i++].SelectSql = "select max(version) as Version from dbversion";

            DataSet dsCoin = HSDBInterfaceManager.RunSelect(Globals.commProvider, tsCoin, false);
            return dsCoin;
        }

        public static DataSet GetCoinDataSetByAdviser(ArrayList egIDs, int dateType, DateTime startDate, DateTime endDate)
        {

            int i = 0;
            HSDBTableSpecs[] tsCoin = HSDBTableSpecs.NewArray(11); //DATACON-258: 9-11


            //CD 2011.4.5 bug 17404 to add _Archive _Old support, and blob storage support
            tsCoin[i++] = GetAdverserReviewTableSpec (egIDs, "AdviserReviews","");  // to get spec for "AdviserReviews"
            tsCoin[i++] = GetAdverserReviewTableSpec(egIDs, "AdviserReviews", "_Archive");  // to get spec for "AdviserReviews_Archive"
            tsCoin[i++] = GetAdverserReviewTableSpec(egIDs, "AdviserReviews", "_Old");  // to get spec for "AdviserReviews_Old"
            tsCoin[i++] = GetAdverserReviewTableSpec(egIDs, "AdviserReviews", "_DeletedClientGroups");  // to get spec for "AdviserReviews_DeletedClientGroups"

            tsCoin[i++] = GetAdviserReviewUserTableSpec (egIDs, "AdviserReviewUsers", "");  // to get spec for "AdviserReviewUsers"
            tsCoin[i++] = GetAdviserReviewUserTableSpec(egIDs, "AdviserReviewUsers", "_Archive");  // to get spec for "AdviserReviewUsers_Archive"
            tsCoin[i++] = GetAdviserReviewUserTableSpec(egIDs, "AdviserReviewUsers", "_Old");  // to get spec for "AdviserReviewUsers_Old"

            tsCoin[i++] = GetAdviserTaskAttachmentTableSpec(egIDs, "TaskAttachments", "");  // to get spec for "TaskAttachments"
            tsCoin[i++] = GetAdviserTaskAttachmentTableSpec(egIDs, "TaskAttachments", "_Archive");  // to get spec for "TaskAttachments_Archive"
            tsCoin[i++] = GetAdviserTaskAttachmentTableSpec(egIDs, "TaskAttachments", "_Old");  // to get spec for "TaskAttachments_Old"
            tsCoin[i++] = GetAdviserTaskAttachmentTableSpec(egIDs, "TaskAttachments", "_DeletedClientGroups");  // to get spec for "TaskAttachments_DeletedClientGroups"

            foreach (HSDBTableSpecs ts in tsCoin)
            {
                ts.CommandTimeout = 0;
            }
//            tsCoin[i].TableName = "AdviserReviews";
//            tsCoin[i++].SelectSql = @"select	r.ID						as [ID],
//                                                r.Date          			as [Date],
//                                                IsNull(r.Status,'')			as [Status],
//                                                IsNull(CAST(r.Comments AS VARCHAR(4000)),'')
//                                                                            as [Comments],
//                                                ClientID					as [ClientID],
//                                                IsNull(r.Priority,'')		as [Priority],
//                                                r.AssignedBy				as [AssignedBy],
//                                                DateCompleted           	as [DateCompleted],
//                                                IsNull(r.Notify,'')			as [Notify],
//                                                IsNull(r.TimeSpentType,'')	as [TimeSpentType],
//                                                r.TimeSpentValue			as [TimeSpentValue],
//                                                IsNull(r.Notify2,'')		as [Notify2],
//                                                IsNull(r.Subject,'')		as [Subject],
//                                                IsNull(r.Frequency,'')		as [Frequency],
//                                                IsNull(r.AutoGen,'')		as [AutoGen],
//                                                IsNull(rc.Description, '')	as [Category Description],
//                                                IsNull(r.TimeSpentNonBillable,'')	
//																			as [TimeSpentNonBillable],
//                                                IsNull(r.TimeSpentBillable,'')
//																			as [TimeSpentBillable],
//                                                IsNull(r.TimeSpentTotal,'')	as [TimeSpentTotal],
//                                                IsNull(r.HourlyRate,'')		as [HourlyRate],
//                                                IsNull(r.TotalCharge,'')	as [TotalCharge],
//                                                IsNull(r.InvoiceAmount,'')	as [InvoiceAmount],
//                                                r.DateCreated           	as [DateCreated],
//                                                ru.UserID                   as [UserID]
//                                      from Reviews	r
//                                      inner join ReviewUsers  ru
//                                      on r.id = ru.ReviewID
//                                      inner join Users u
//                                      on r.AssignedBy = u.ID
//                                      left join ReviewCategories rc on r.CategoryID = rc.id
//            						  WHERE (" + GetCondition("ru.UserID", egIDs) + ") OR (" + GetCondition("r.AssignedBy", egIDs) + ")";

//            tsCoin[i].TableName = "AdviserReviewUsers";
//            tsCoin[i++].SelectSql = @"select	ru.ID                       as [ID],
//                                                ru.ReviewID                 as [ReviewID],
//                                                ru.UserID                   as [UserID],
//                                                r.ClientID                  as [ClientID]
//                                      from ReviewUsers	ru
//                                      inner join Reviews r 
//                                      on r.id = ru.ReviewID
//                                      WHERE (" + GetCondition("ru.UserID", egIDs) + ")";

//            tsCoin[i].TableName = "TaskAttachments";
//            tsCoin[i++].SelectSql = @"select	t.ID                         as [ID], 
//		                                        t.TaskID                     as [TaskID],
//		                                        t.FileName                   as [FileName],
//		                                        t.Date                       as	[Date]
//                                      from TaskAttachments t              
//                                      inner join Reviews	r
//                                      on t.TaskID = r.ID
//                                      inner join ReviewUsers  ru
//                                      on r.id = ru.ReviewID
//                                      inner join Users u
//                                      on r.AssignedBy = u.ID
//                                      WHERE (" + GetCondition("ru.UserID", egIDs) + ") OR (" + GetCondition("r.AssignedBy", egIDs) + ")";

            DataSet dsCoin = HSDBInterfaceManager.RunSelect(Globals.commProvider, tsCoin, false);


            return dsCoin;

        }

        private static HSDBTableSpecs GetAdverserReviewTableSpec(ArrayList egIDs, string prefix, string suffix)
        {
            HSDBTableSpecs ts = new HSDBTableSpecs();
            ts.TableName = prefix + suffix;
            ts.SelectSql =                      @"select	r.ID						as [ID],
                                                r.Date          			as [Date],
                                                IsNull(r.Status,'')			as [Status],
                                                IsNull(CAST(r.Comments AS nvarchar(max)),'')
                                                                            as [Comments],
                                                ClientID					as [ClientID],
                                                IsNull(r.Priority,'')		as [Priority],
                                                r.AssignedBy				as [AssignedBy],
                                                DateCompleted           	as [DateCompleted],
                                                IsNull(r.Notify,'')			as [Notify],
                                                IsNull(r.TimeSpentType,'')	as [TimeSpentType],
                                                r.TimeSpentValue			as [TimeSpentValue],
                                                IsNull(r.Notify2,'')		as [Notify2],
                                                IsNull(r.Subject,'')		as [Subject],
                                                IsNull(r.Frequency,'')		as [Frequency],
                                                IsNull(r.AutoGen,'')		as [AutoGen],
                                                IsNull(rc.Description, '')	as [Category Description],
                                                IsNull(r.TimeSpentNonBillable,'')	
																			as [TimeSpentNonBillable],
                                                IsNull(r.TimeSpentBillable,'')
																			as [TimeSpentBillable],
                                                IsNull(r.TimeSpentTotal,'')	as [TimeSpentTotal],
                                                IsNull(r.HourlyRate,'')		as [HourlyRate],
                                                IsNull(r.TotalCharge,'')	as [TotalCharge],
                                                IsNull(r.InvoiceAmount,'')	as [InvoiceAmount],
                                                r.DateCreated           	as [DateCreated],
                                                ru.UserID                   as [UserID]
                                      from Reviews" + suffix + @"	r 
                                      inner join ReviewUsers" + suffix + @" ru 
                                      on r.id = ru.ReviewID 
                                      inner join Users u
                                      on r.AssignedBy = u.ID
                                      left join ReviewCategories rc on r.CategoryID = rc.id
            						  WHERE (" + GetCondition("ru.UserID", egIDs) + ") OR (" + GetCondition("r.AssignedBy", egIDs) + ")";
            return ts;
        }

        private static HSDBTableSpecs GetClientReviewTableSpec(ArrayList egIDs, string prefix, string suffix)
        {
            HSDBTableSpecs ts = new HSDBTableSpecs();
            ts.TableName = prefix + suffix;
            ts.SelectSql = @"select	r.ID						as [ID],
                                                r.Date           			as [Date],
                                                IsNull(r.Status,'')			as [Status],
                                                IsNull(CAST(r.Comments AS nvarchar(max)),'')
                                                                            as [Comments],
                                                ClientID					as [ClientID],
                                                IsNull(r.Priority,'')		as [Priority],
                                                r.AssignedBy				as [AssignedBy],
                                                r.DateCompleted         	as [DateCompleted],
                                                IsNull(r.Notify,'')			as [Notify],
                                                IsNull(r.TimeSpentType,'')	as [TimeSpentType],
                                                r.TimeSpentValue			as [TimeSpentValue],
                                                IsNull(r.Notify2,'')		as [Notify2],
                                                IsNull(r.Subject,'')        as [Subject],
                                                IsNull(r.Frequency,'')		as [Frequency],
                                                IsNull(r.AutoGen,'')		as [AutoGen],
                                                IsNull(rc.Description, '')	as [Category Description],
                                                IsNull(r.TimeSpentNonBillable,'')	
																			as [TimeSpentNonBillable],
                                                IsNull(r.TimeSpentBillable,'')
																			as [TimeSpentBillable],
                                                IsNull(r.TimeSpentTotal,'')	as [TimeSpentTotal],
                                                IsNull(r.HourlyRate,'')		as [HourlyRate],
                                                IsNull(r.TotalCharge,'')	as [TotalCharge],
                                                IsNull(r.InvoiceAmount,'')	as [InvoiceAmount],
                                                r.DateCreated               as [DateCreated]
                                      from Reviews" + suffix + @" r
                                      --why inner join review user?
                                      --it is not mandatory
                                      --inner join ReviewUsers  ru
                                      --on r.id = ru.ReviewID
                                      --inner join Users u
                                      --on r.AssignedBy = u.ID
                                      left join ReviewCategories rc on r.CategoryID = rc.id
            						  WHERE (" + GetCondition(@"r.ClientId", egIDs) + @")";
            return ts;
        }
        private static HSDBTableSpecs GetClientReviewUserTableSpec(ArrayList egIDs, string prefix, string suffix)
        {
            HSDBTableSpecs ts = new HSDBTableSpecs();

            ts.TableName = prefix + suffix;
            ts.SelectSql = @"select	ru.ID                 as [ID],
                              ru.ReviewID                 as [ReviewID],
                              ru.UserID                   as [UserID],
                              r.ClientID                  as [ClientID]
                              from ReviewUsers" + suffix + @" ru
                              inner join Reviews" + suffix + @" r 
                              on r.id = ru.ReviewID
                              WHERE (" + GetCondition("r.ClientId", egIDs) + ")";
            return ts;
        }

        private static HSDBTableSpecs GetAdviserReviewUserTableSpec(ArrayList egIDs, string prefix, string suffix)
        {
            HSDBTableSpecs ts = new HSDBTableSpecs();

            ts.TableName = prefix + suffix;
            ts.SelectSql = @"select	ru.ID                 as [ID],
                              ru.ReviewID                 as [ReviewID],
                              ru.UserID                   as [UserID],
                              r.ClientID                  as [ClientID]
                              from ReviewUsers" + suffix + @" ru
                              inner join Reviews" + suffix + @" r 
                              on r.id = ru.ReviewID
                              WHERE (" + GetCondition("ru.UserID", egIDs) + ")";
            return ts;
        }
        private static HSDBTableSpecs GetAdviserTaskAttachmentTableSpec(ArrayList egIDs, string prefix, string suffix)
        {
            HSDBTableSpecs ts = new HSDBTableSpecs();
            ts.TableName = prefix + suffix;
            ts.SelectSql = @"select	t.ID                 as [ID], 
		                    t.TaskID                     as [TaskID],
		                    t.FileName                   as [FileName],
		                    t.Date                       as	[Date]
                            from TaskAttachments" + suffix + @" t              
                            inner join Reviews" + suffix + @" r
                            on t.TaskID = r.ID
                            inner join ReviewUsers" + suffix + @" ru
                            on r.id = ru.ReviewID
                            inner join Users u
                            on r.AssignedBy = u.ID
                            WHERE (" + GetCondition("ru.UserID", egIDs) + ") OR (" + GetCondition("r.AssignedBy", egIDs) + ")";
            return ts;
        }

        private static HSDBTableSpecs GetClientTaskAttachmentTableSpec(ArrayList egIDs, string prefix, string suffix)
        {
            HSDBTableSpecs ts = new HSDBTableSpecs();
            ts.TableName = prefix + suffix;
            ts.SelectSql = @"select	t.ID                 as [ID], 
		                    t.TaskID                     as [TaskID],
		                    t.FileName                   as [FileName],
		                    t.Date                       as	[Date]
                            from TaskAttachments" + suffix + @" t              
                            inner join Reviews" + suffix + @" r
                            on t.TaskID = r.ID
                            inner join ReviewUsers" + suffix + @" ru
                            on r.id = ru.ReviewID
                            inner join Users u
                            on r.AssignedBy = u.ID
                            WHERE (" + GetCondition("r.ClientID", egIDs) + ")";
            return ts;
        }

        private static HSDBTableSpecs GetDocumentListTableSpec(ArrayList egIDs, string prefix, string suffix)
        {
            HSDBTableSpecs ts = new HSDBTableSpecs();
            ts.TableName = prefix + suffix;
            ts.SelectSql = @"select dl.ID                           as [ID],
                                        ClientID,
                                        UserID,
                                        Date,
                                        DocName,
                                        FileType,
                                        Source,
                                        Reviewed,
                                        Status,
                                        Progress,
                                        dl.IsSOA,
                                        FinalisedDate,
                                        TemplateID,
                                        SWDocumentID,
                                        s.Description                       as [DocumentDescription],
                                        ReferenceID,
                                        FaxStatusCode,
                                        StatusType,
                                        StatusDate,
                                        FaxStatusDesc
                                      from DocumentList" + suffix + @" dl
                                      inner join Documents" + suffix + @" d 
                                      on dl.id  = d.ID
                                      left join SWDocuments s
                                      on dl.SWDocumentID = s.id
                                      WHERE (" + GetCondition("ClientID", egIDs) + ")";
            return ts;
        }

        private static HSDBTableSpecs GetDocumentTableSpec(ArrayList egIDs, string prefix, string suffix)
        {
            HSDBTableSpecs ts = new HSDBTableSpecs();
            ts.TableName = prefix + suffix;
            ts.SelectSql = @"select d.id, d.Zipped
                                      from DocumentList" + suffix + @" dl
                                      inner join Documents" + suffix + @" d
                                      on dl.id  = d.ID
                                      WHERE (" + GetCondition("ClientID", egIDs) + ")";
            return ts;
        }

        public static DataSet GetCoinDataSetByClient(ArrayList egIDs, int dateType, DateTime startDate, DateTime endDate) 
        {
            int i = 0;
            HSDBTableSpecs[] tsCoin = HSDBTableSpecs.NewArray(63); //DATACON-258: 56-63

            tsCoin[i].TableName     = "EntityGroups";
            tsCoin[i++].SelectSql = "SELECT ID, EntityGroupName, MaritalStatusID, Deleted, UserID, PrimaryEntityType, PrimaryEntityID, ISNULL(Comments, '') AS Comments, NextReviewDate, FirstAppointDate, LastAppointDate, CreatedDate, FSGProvideDate, FactFindDate, Reference FROM EntityGroups WHERE " + GetCondition("ID", egIDs);
            tsCoin[i].TableName     = "Ent_Clients";
            tsCoin[i++].SelectSql   = "SELECT * FROM Ent_Clients WHERE " + GetCondition("EntityGroupID", egIDs);
            tsCoin[i].TableName     = "Ent_Spouses";
            tsCoin[i++].SelectSql   = "SELECT * FROM Ent_Spouses WHERE " + GetCondition("EntityGroupID", egIDs);
            tsCoin[i].TableName     = "Joint";
            tsCoin[i++].SelectSql   = "SELECT * FROM Joint WHERE " + GetCondition("ClientID", egIDs);
            tsCoin[i].TableName     = "Trusts";
            tsCoin[i++].SelectSql   = "SELECT * FROM Trusts WHERE " + GetCondition("ClientID", egIDs);
            tsCoin[i].TableName     = "Other";
            tsCoin[i++].SelectSql   = "SELECT * FROM Other WHERE " + GetCondition("ClientID", egIDs);
            tsCoin[i].TableName     = "Superfund";
            tsCoin[i++].SelectSql   = "SELECT * FROM Superfund WHERE " + GetCondition("ClientID", egIDs);
            tsCoin[i].TableName     = "Companies";
            tsCoin[i++].SelectSql   = "SELECT * FROM Companies WHERE " + GetCondition("ClientID", egIDs);
			tsCoin[i].TableName     = "Beneficiaries";
			tsCoin[i++].SelectSql   = "SELECT ISNULL(Firstname,'') as Firstname,ISNULL(Surname,'') as Surname,ISNULL(Portion,0) as Portion,ISNULL(EntitlementAge,0) as EntitlementAge,ClientID,vw_entities.id as EntityID from beneficiaries join vw_entities on vw_entities.entitygroupid = beneficiaries.clientid and vw_entities.entityType = beneficiaries.entitytypecode WHERE " + GetCondition("ClientID", egIDs);
            tsCoin[i].TableName     = "ClientCategories";
            tsCoin[i++].SelectSql   = "SELECT CLIENTCATEGORIES.*,DESCRIPTION,IsSystem FROM CLIENTCATEGORIES JOIN CATEGORIES ON CLIENTCATEGORIES.CATEGORYID = CATEGORIES.ID AND (" + GetCondition("ClientID", egIDs) + ")";
            tsCoin[i].TableName     = "Items";
            tsCoin[i++].SelectSql   = "select * from items where id in (select itemid from clientcategories where " + GetCondition("ClientID", egIDs) + ")";
            tsCoin[i].TableName     = "AddressList";
            tsCoin[i++].SelectSql   = @"select * from addresslist where addresslistid in (
                                         (select addresslistid from ent_clients where " + GetCondition("entitygroupid", egIDs) + @") union
                                         (select addresslistid from ent_spouses where " + GetCondition("entitygroupid", egIDs) + @") union
                                         (select addresslistid from companies where " + GetCondition("clientid", egIDs) + @") union
                                         (select addresslistid from superfund where " + GetCondition("clientid", egIDs) + @") union
                                         (select addresslistid from trusts where " + GetCondition("clientid", egIDs) + @") union
                                         (select addresslistid from other where " + GetCondition("clientid", egIDs) + @")
                                      )";
            tsCoin[i].TableName     = "Address";
            tsCoin[i++].SelectSql   = @"select * from address where id in (
                                          select addressid from addresslist where addresslistid in (
                                            (select addresslistid from ent_clients where " + GetCondition("entitygroupid", egIDs) + @") union
                                            (select addresslistid from ent_spouses where " + GetCondition("entitygroupid", egIDs) + @") union
                                            (select addresslistid from companies where " + GetCondition("clientid", egIDs) + @") union
                                            (select addresslistid from superfund where " + GetCondition("clientid", egIDs) + @") union
                                            (select addresslistid from trusts where " + GetCondition("clientid", egIDs) + @") union
                                            (select addresslistid from other where " + GetCondition("clientid", egIDs) + @")
                                          )
                                       )";
            tsCoin[i].TableName     = "P_Assets";
            string filter = @"select p.AS_ID, AS_EN, AS_PR, AS_AG, TaxCode, AS_PolicyAcctNo, AS_Desc, AS_ExpDate, AS_ReinvestIncome, AS_CGTTax, AS_TrailBrokrage, AS_IsWCA, AS_FUM, AS_ReportExclude, AS_ExcludeDist, AS_UsedAsSecurity, AS_ExcludeFromAdvice, AS_CentrelinkExempt, AS_Comments, AS_Source from p_assets p
                                        where as_en in (
                                          (select entityid from ent_clients where " + GetCondition("entitygroupid", egIDs) + @") union
                                          (select entityid from ent_spouses where " + GetCondition("entitygroupid", egIDs) + @") union
                                          (select id from joint where " + GetCondition("clientid", egIDs) + @") union
                                          (select id from companies where " + GetCondition("clientid", egIDs) + @") union
                                          (select id from superfund where " + GetCondition("clientid", egIDs) + @") union
                                          (select id from trusts where " + GetCondition("clientid", egIDs) + @") union
                                          (select id from other where " + GetCondition("clientid", egIDs) + @")
                                        )";
            if (!Globals.IncludeDatafeedHoldings)
                filter += " and ((p.as_id in (select distinct tx_as from p_trans where tx_fromdatafeed = 0) and (as_source is null or as_source = '')) or ((SELECT SUM(AssetValue) FROM vw_CurrentAssetValues WHERE as_id in (SELECT as_id from P_assets where as_ag = p.AS_AG and AS_AG is not null)) =0))";
            else
            {
                string source = "(''";
                foreach(var pair in Globals.IncludedDatafeedList)
                {
                    if (pair.Value == "TRUE")
                        source += ",'" + pair.Key + "'";
                } 

                source += ")";
                filter += " and p.as_id in (select distinct tx_as from p_trans) and (as_source is null or as_source in " + source + ")";
            }
                

            tsCoin[i++].SelectSql = filter;

            tsCoin[i].TableName = "P_Trans";
            if (!Globals.IncludeDatafeedHoldings)
            { 
            filter = @"select TX_ID, TX_AS, TX_TP, TX_TS, TX_Date, TX_Quantity, TX_GrossAmount, TX_UserCostBase, TX_ClientFees, TX_OtherFees, TX_OtherTax, TX_IsInitTrans, TX_GrossEntitlement, TX_DomesticWTax, TX_ForeignWTax, TX_OtherTax, TX_GrossFrankDiv, TX_UnfrankDiv, TX_ImpCredit, TX_InterestRec, TX_ForeignInt, TX_RetCapGain, TX_TaxFree, TX_TaxDef, TX_PreAnnounce, TX_PreAnnounceDisc, TX_PreAnnounceUnDisc, TX_TaxExemp, TX_ForeignCapGain, TX_ForeignTaxCred, TX_OtherIncome, TX_Comments from P_Trans
                             INNER JOIN vw_CurrentAssetValues v
                             on v.as_id = P_Trans.TX_AS
                             where (TX_AS in (
                                select AS_ID from p_assets where as_en in (
                                (select entityid from ent_clients where " + GetCondition("entitygroupid", egIDs) + @") union
                                (select entityid from ent_spouses where " + GetCondition("entitygroupid", egIDs) + @") union
                                (select id from joint where " + GetCondition("clientid", egIDs) + @") union
                                (select id from companies where " + GetCondition("clientid", egIDs) + @") union
                                (select id from superfund where " + GetCondition("clientid", egIDs) + @") union
                                (select id from trusts where " + GetCondition("clientid", egIDs) + @") union
                                (select id from other where " + GetCondition("clientid", egIDs) + @")
                                )
                            )) and (tx_fromdatafeed = 0 or v.AssetValue = 0)";
            }
            else
            {
                string source = "(''";
                foreach (var pair in Globals.IncludedDatafeedList)
                {
                    if (pair.Value == "TRUE")
                        source += ",'" + pair.Key + "'";
                }

                source += ")";
                filter += " and as_id in (select distinct tx_as from p_trans) and (as_source is null or as_source in " + source + ")";

                filter = @"select TX_ID, TX_AS, TX_TP, TX_TS, TX_Date, TX_Quantity, TX_GrossAmount, TX_UserCostBase, TX_ClientFees, TX_OtherFees, TX_OtherTax, TX_IsInitTrans, TX_GrossEntitlement, TX_DomesticWTax, TX_ForeignWTax, TX_OtherTax, TX_GrossFrankDiv, TX_UnfrankDiv, TX_ImpCredit, TX_InterestRec, TX_ForeignInt, TX_RetCapGain, TX_TaxFree, TX_TaxDef, TX_PreAnnounce, TX_PreAnnounceDisc, TX_PreAnnounceUnDisc, TX_TaxExemp, TX_ForeignCapGain, TX_ForeignTaxCred, TX_OtherIncome, TX_Comments from P_Trans where (TX_AS in (
                                select AS_ID from p_assets where as_en in (
                                (select entityid from ent_clients where " + GetCondition("entitygroupid", egIDs) + @") union
                                (select entityid from ent_spouses where " + GetCondition("entitygroupid", egIDs) + @") union
                                (select id from joint where " + GetCondition("clientid", egIDs) + @") union
                                (select id from companies where " + GetCondition("clientid", egIDs) + @") union
                                (select id from superfund where " + GetCondition("clientid", egIDs) + @") union
                                (select id from trusts where " + GetCondition("clientid", egIDs) + @") union
                                (select id from other where " + GetCondition("clientid", egIDs) + @")
                                ) and (as_source is null or as_source in " + source + @")
                            ))";
            }

            if (startDate != DateTime.MinValue && endDate != DateTime.MaxValue) 
            {
                filter += " and (" + ((dateType == Importer.Importer.TRANSACTION_DATE) ? "TX_Date" : "TX_LastModified") + " between '" + startDate.ToString("yyyy-MM-dd") + "' and '" + endDate.ToString("yyyy-MM-dd") + "')";
            }
            tsCoin[i++].SelectSql   = filter;

            tsCoin[i].TableName     = "P_AssetGroups";
            tsCoin[i++].SelectSql   = @"select AG_ID, AG_Owner, AG_SE, AG_AccountName from p_assetgroups where ag_owner in (
                                          (select entityid from ent_clients where " + GetCondition("entitygroupid", egIDs) + @") union
                                          (select entityid from ent_spouses where " + GetCondition("entitygroupid", egIDs) + @") union
                                          (select id from joint where " + GetCondition("clientid", egIDs) + @") union
                                          (select id from companies where " + GetCondition("clientid", egIDs) + @") union
                                          (select id from superfund where " + GetCondition("clientid", egIDs) + @") union
                                          (select id from trusts where " + GetCondition("clientid", egIDs) + @") union
                                          (select id from other where " + GetCondition("clientid", egIDs) + @")
                                       )";
            //
            //CD Bug 17404. to support _Archive and _Old
            tsCoin[i].TableName     = "FileNotes";
            tsCoin[i++].SelectSql   = "select ID, ClientID, Subject, noteSubject, FNDate, Notes, UserID from filenotes where " + GetCondition("clientid", egIDs);
            tsCoin[i].TableName     = "FileNotes_Archive";
            tsCoin[i++].SelectSql   = "select ID, ClientID, Subject, noteSubject, FNDate, Notes, UserID from filenotes_Archive where " + GetCondition("clientid", egIDs);
            tsCoin[i].TableName     = "FileNotes_Old";
            tsCoin[i++].SelectSql = "select ID, ClientID, Subject, noteSubject, FNDate, Notes, UserID from FileNotes_Old where " + GetCondition("clientid", egIDs);
            //DATACON-258 Option to include deleted EG
            tsCoin[i].TableName = "FileNotes_DeletedClientGroups";
            tsCoin[i++].SelectSql = "select ID, ClientID, Subject, noteSubject, FNDate, Notes, UserID from FileNotes_DeletedClientGroups where " + GetCondition("clientid", egIDs);
            

            tsCoin[i++].SelectSql   = "select ID, ClientID, Subject, noteSubject, FNDate, Notes, UserID from filenotes_Old where " + GetCondition("clientid", egIDs);
			tsCoin[i].TableName     = "Dependants";
			tsCoin[i++].SelectSql   = "SELECT ID,EntityGroupID,ChildName,Surname,ChildDOB,SEX,Relationship,Dependant,Occupation, DepAge FROM CHILDREN WHERE " + GetCondition("EntityGroupID", egIDs);
            
            //"attachment is not null" removed to support blob storage
            //tsCoin[i++].SelectSql   = "select id, filenoteid, attdate, description from filenoteattachments where attachment is not null and filenoteid in (select id from filenotes where " + GetCondition("clientid", egIDs) + ")";
            tsCoin[i].TableName     = "FileNoteAttachments";
            tsCoin[i++].SelectSql   = "select id, filenoteid, attdate, description from filenoteattachments where filenoteid in (select id from filenotes where " + GetCondition("clientid", egIDs) + ")";
            tsCoin[i].TableName     = "FileNoteAttachments_Archive";
            tsCoin[i++].SelectSql   = "select id, filenoteid, attdate, description from FileNoteAttachments_Archive where filenoteid in (select id from filenotes_Archive where " + GetCondition("clientid", egIDs) + ")";
            tsCoin[i].TableName     = "FileNoteAttachments_Old";
            tsCoin[i++].SelectSql   = "select id, filenoteid, attdate, description from filenoteattachments_Old where filenoteid in (select id from filenotes_Old where " + GetCondition("clientid", egIDs) + ")";
            //DATACON-258 Option to include deleted EG
            tsCoin[i].TableName = "FileNoteAttachments_DeletedClientGroups";
            tsCoin[i++].SelectSql = "select id, filenoteid, attdate, description from FileNoteAttachments_DeletedClientGroups where filenoteid in (select id from FileNotes_DeletedClientGroups where " + GetCondition("clientid", egIDs) + ")";

            //
            tsCoin[i].TableName     = "IncomeExpensesFactFind";
            tsCoin[i++].SelectSql   = "select ClientID, EffectiveDate, CWages, SWages, CBonusComm, SBonusComm, CCLinkIncome, SCLinkIncome, CCLinkNonTaxable, SCLinkNonTaxable, COTI, SOTI, CONTI, SONTI, CORFB, SORFB, ClientTaxDeductExp, SpouseTaxDeductExp, HousingExp, LoansExp, InsuranceExp, PersonalExp from incomeexpensesfactfind where " + GetCondition("clientid", egIDs);
            tsCoin[i].TableName     = "ClientLifeStyleGoals";
            tsCoin[i++].SelectSql   = "select * from ClientLifeStyleGoals where " + GetCondition("clientid", egIDs);
			tsCoin[i].TableName     = "ClientWillBeneficiaries";
			tsCoin[i++].SelectSql   = "SELECT vw_entities.id AS EntityId,ClientId,FirstName,Surname,ISNULL(EntitlementAge,0) as EntitlementAge,ISNULL(Portion,0) as Portion FROM Beneficiaries join vw_entities on vw_entities.EntityGroupID = Beneficiaries.ClientID AND vw_entities.EntityType = Beneficiaries.EntityTypeCode WHERE "+ GetCondition("clientid", egIDs);
			tsCoin[i].TableName     = "WillExecutors";
			tsCoin[i++].SelectSql   = "select * from WillExecutors where " + GetCondition("clientid", egIDs);
			tsCoin[i].TableName     = "PowerofAttorneys";
			tsCoin[i++].SelectSql   = "SELECT * FROM PowerofAttorneys WHERE "+ GetCondition("clientid", egIDs);
			tsCoin[i].TableName     = "ClientEstates";
			tsCoin[i++].SelectSql   = "SELECT ClientID,Notes,CWillExists,CWillCurrent,CWillDate,CWillLocation,CTestTru,SWillExists,SWillCurrent,SWillDate,SWillLocation,STestTru FROM ClientEstates WHERE "+ GetCondition("clientid", egIDs);
			tsCoin[i].TableName     = "Insurances";
            tsCoin[i++].SelectSql = @"select	i.EntID														as [Primary Owner], 
												IsNull(Cast(i.InsTypeSelection as varchar(50)),'')			as [Insurance Type], 
												IsNull(Cast(i.PlanName as varchar(50)),'')					as [Product Name], 
												IsNull(Cast(i.Underwriter as varchar(50)),'')				as [Underwriter],
												i.status													as [Insurance Status], 
												IsNull(Cast(i.ExpiryDate as varchar(50)),'')				as [Expiry Date],	
												IsNull(CAST(case ie.CountofInsTypes
												when 0 then null
	                                            else case i.InsTypeSelection 
		                                            when 8	then i.IPBenefitAmount 
		                                            when 9	then i.IPBenefitAmount 
		                                            when 10 then i.IPBenefitAmount	
		                                            else SumInsured
		                                            end	
												end as varchar(50)), '')									as [Benefit Amount / Level of Cover],
												IsNull(Cast(i.InsEscalation as varchar(50)),'')				as [Escalation], 
												IsNull(case InsTypeSelection
													when 8	then i.IPBenefitFreq
													when 9	then i.IPBenefitFreq
													when 10 then i.IPBenefitFreq
												else null
												end, '') 													as [Benefit Frequency],
												IsNull(Cast (i.Premium as varchar(50)),'')					as [Current Premium],
												IsNull(Cast(i.PremiumFrequency as varchar(50)),'')			as [Premium Frequency], 
												IsNull(Cast(i.PolicyNumber as varchar(50)),'')				as [Policy Number],
												i.EntBeneficiaryID											as [Beneficiary 1],
												i.BenPercent												as [Percentage Beneficiary 1],
												i.EntInsuredID												as [Insured], 
												IsNull(Cast(i.PolicyDate as varchar(50)),'')				as [Policy Commencement Date],
												IsNull(Cast(i.PremType as varchar(50)),'')					as [Premium Type],

												IsNull(Cast(i.BEBenPaymentPeriodOpt as varchar(50)),'') 	as [Business Expense Benefit Period - Accident],
												IsNull(Cast(i.BESicknessBenPaymentPeriodOpt as varchar(50)),'')
																											as [Business Expense Benefit Period - Sickness], 
												IsNull(Cast(i.BEWaitingPeriodOpt as varchar(50)),'')		as [Business Expense Waiting Period],
												IsNull(Cast(i.BEBenTypeOpt as varchar(50)),'')				as [Business Expense Benefit Type],  

												IsNull(Cast(i.TPDOccpOpt as varchar(50)),'')				as [Occupation Type], 

												IsNull(Cast(i.BenPaymentPeriodOpt as varchar(50)),'')		as [Income Protection Benefit Period - Accident],
												IsNull(Cast(i.SicknessBenPaymentPeriodOpt as varchar(50)),'') 
																											as [Income Protection Benefit Period - Sickness],
												IsNull(Cast(i.WaitingPeriodOpt as varchar(50)),'')			as [Income Protection Waiting Period],
												IsNull(Cast(i.BenTypeOpt as varchar(50)),'')				as [Income Protection Benefit Type],
												IsNull(Cast(ic.InitCommision as varchar(50)),'')			as [Commission percentage], 
												IsNull(Cast(ic.AdvInitComm as varchar(50)),'')				as [Adviser Entitlement], 
												IsNull(Cast(i.Comments as varchar(2000)),'')				as [Comments], 
												i.ID														as [Insurance ID],
												i.ClientID													as [ClientID],
                                                IsNull(i.PaymentID,'')				                        as [Payment ID],
                                                IsNull(Cast(i.BankAccountNo as varchar(20)),'')				as [Bank Account No],
                                                IsNull(Cast(i.BSB as varchar(10)),'')				        as [Bank Account BSB],
												IsNull(Cast(i.NextRenewalDate as varchar(50)),'')			as [Next Review Date],	
												IsNull(Cast(i.IssueDate as varchar(50)),'')					as [Issue Date],
												IsNull(Cast(i.IssueStatus as varchar(50)),'')				as [Issue Status],
												IsNull(Cast(iei.InsPol_UWSubmittedDate as varchar(50)),'')	as [Submitted Underwriter Date],
												IsNull(Cast(iei.InsPol_AnniversaryDate as varchar(50)),'')	as [Anniversary Date],
												IsNull(Cast(iei.InsPol_RenewalDate as varchar(50)),'')		as [Renewal Date],
                                                i.EntityTypeCode													as [EntityTypeCode],
                                                IsNull(Cast(i.InsuredDesc as varchar(50)),'')					as [InsuredDesc], 
                                                IsNull(Cast(i.EntityDescription as varchar(50)),'')					as [EntityDescription], 
                                                IsNull(Cast(i.OtherEntDesc as varchar(50)),'')					as [OtherEntDesc]                                             
										from Insurances i 
										left join (select InsuranceID, count(*) as CountofInsTypes from InsuranceEntities 
													group by InsuranceID ) ie	on i.ID = ie.InsuranceID 
										left join InsuranceCommission ic on i.ID = ic.InsuranceID
										left join InsurancesExtraInfo iei on i.id = iei.InsuranceID
										WHERE (source is null or source = '') and " + GetCondition("i.ClientId", egIDs);
            //Insurances.source is used to distinct insurnaces created from Factfind, Inc or QuickPlan modules with value of NULL, INC and QP accordingly

            tsCoin[i].TableName = "InsuranceOwner";
            tsCoin[i++].SelectSql = @"select distinct ie.InsuranceID										as [Insurance ID], 
                                                      ie.InsuranceType								        as [Insurance Option ID],
												      ie.EntityID										    as [Entity ID],
												      ie.Amount												as [Amount],
                                                      i.ClientID											as [ClientID],
                                                      ie.TypeofEntity                                       as [TypeofEntity],
                                                      ie.EntityName                                         as [EntityName]
										from InsuranceEntities ie inner join Insurances i on ie.InsuranceID = i.ID
										WHERE " + GetCondition("i.ClientId", egIDs);

            tsCoin[i].TableName = "InsuranceOptionAmount";
			tsCoin[i++].SelectSql   = @"select	distinct io.InsuranceOptionID								as [Insurance Type],
												io.Amount													as [Amount],
												io.InsuranceID												as [Insurance ID], 
												i.ClientID													as [ClientID]
										from InsuranceOptionAmount io	
										inner join Insurances i
										on io.InsuranceID = i.ID
										WHERE "+ GetCondition("i.ClientId", egIDs);
//										WHERE io.InsuranceOptionName is not null and io.ID <> 'CEC8BE27-F66E-454B-96C6-F6A781C0D2C4'
//										AND ("+ GetCondition("i.ClientId", egIDs) + ")";

            tsCoin[i++] = GetClientReviewTableSpec(egIDs, "ClientReviews", "");  // to get spec for "ClientReviews"
            tsCoin[i++] = GetClientReviewTableSpec(egIDs, "ClientReviews", "_Archive");  // to get spec for "ClientReviews_Archive"
            tsCoin[i++] = GetClientReviewTableSpec(egIDs, "ClientReviews", "_Old");  // to get spec for "ClientReviews_Old"
            tsCoin[i++] = GetClientReviewTableSpec(egIDs, "ClientReviews", "_DeletedClientGroups");  // to get spec for "ClientReviews_DeletedClientGroups"

            //            tsCoin[i].TableName = "ClientReviews";
            //            tsCoin[i++].SelectSql = @"select	r.ID						as [ID],
            //                                                r.Date           			as [Date],
            //                                                IsNull(r.Status,'')			as [Status],
            //                                                IsNull(CAST(r.Comments AS VARCHAR(4000)),'')
            //                                                                            as [Comments],
            //                                                ClientID					as [ClientID],
            //                                                IsNull(r.Priority,'')		as [Priority],
            //                                                r.AssignedBy				as [AssignedBy],
            //                                                r.DateCompleted         	as [DateCompleted],
            //                                                IsNull(r.Notify,'')			as [Notify],
            //                                                IsNull(r.TimeSpentType,'')	as [TimeSpentType],
            //                                                r.TimeSpentValue			as [TimeSpentValue],
            //                                                IsNull(r.Notify2,'')		as [Notify2],
            //                                                IsNull(r.Subject,'')        as [Subject],
            //                                                IsNull(r.Frequency,'')		as [Frequency],
            //                                                IsNull(r.AutoGen,'')		as [AutoGen],
            //                                                IsNull(rc.Description, '')	as [Category Description],
            //                                                IsNull(r.TimeSpentNonBillable,'')	
            //																			as [TimeSpentNonBillable],
            //                                                IsNull(r.TimeSpentBillable,'')
            //																			as [TimeSpentBillable],
            //                                                IsNull(r.TimeSpentTotal,'')	as [TimeSpentTotal],
            //                                                IsNull(r.HourlyRate,'')		as [HourlyRate],
            //                                                IsNull(r.TotalCharge,'')	as [TotalCharge],
            //                                                IsNull(r.InvoiceAmount,'')	as [InvoiceAmount],
            //                                                r.DateCreated               as [DateCreated]
            //                                      from Reviews	r
            //                                      --why inner join review user?
            //                                      --it is not mandatory
            //                                      --inner join ReviewUsers  ru
            //                                      --on r.id = ru.ReviewID
            //                                      --inner join Users u
            //                                      --on r.AssignedBy = u.ID
            //                                      left join ReviewCategories rc on r.CategoryID = rc.id
            //            						  WHERE (" + GetCondition(@"r.ClientId", egIDs) + @")";

            tsCoin[i++] = GetClientReviewUserTableSpec(egIDs, "ClientReviewUsers", "");  // to get spec for "ClientReviewUsers"
            tsCoin[i++] = GetClientReviewUserTableSpec(egIDs, "ClientReviewUsers", "_Archive");  // to get spec for "ClientReviewUsers_Archive"
            tsCoin[i++] = GetClientReviewUserTableSpec(egIDs, "ClientReviewUsers", "_Old");  // to get spec for "ClientReviewUsers_Old"
           

            //            tsCoin[i].TableName = "ClientReviewUsers";
            //            tsCoin[i++].SelectSql = @"select	ru.ID                       as [ID],
            //                                                ru.ReviewID                 as [ReviewID],    
            //                                                ru.UserID                   as [UserID],  
            //                                                r.ClientID                  as [ClientID]
            //                                      from ReviewUsers	ru
            //                                      inner join Reviews r 
            //                                      on r.id = ru.ReviewID
            //                                      WHERE (" + GetCondition("r.ClientId", egIDs) + ")";
            tsCoin[i++] = GetClientTaskAttachmentTableSpec(egIDs, "TaskAttachments", "");  // to get spec for "TaskAttachments"
            tsCoin[i++] = GetClientTaskAttachmentTableSpec(egIDs, "TaskAttachments", "_Archive");  // to get spec for "TaskAttachments_Archive"
            tsCoin[i++] = GetClientTaskAttachmentTableSpec(egIDs, "TaskAttachments", "_Old");  // to get spec for "TaskAttachments_Old"
            tsCoin[i++] = GetClientTaskAttachmentTableSpec(egIDs, "TaskAttachments", "_DeletedClientGroups");  // to get spec for "TaskAttachments_DeletedClientGroups"

            //            tsCoin[i].TableName = "TaskAttachments";
            //            tsCoin[i++].SelectSql = @"select	t.ID                         as [ID], 
            //		                                        t.TaskID                     as [TaskID],
            //		                                        t.FileName                   as [FileName],
            //		                                        t.Date                       as	[Date]
            //                                      from TaskAttachments t              
            //                                      inner join Reviews	r
            //                                      on t.TaskID = r.ID
            //                                      inner join ReviewUsers  ru
            //                                      on r.id = ru.ReviewID
            //                                      inner join Users u
            //                                      on r.AssignedBy = u.ID
            //                                      WHERE (" + GetCondition("r.ClientID", egIDs) + ")";
            tsCoin[i++] = GetDocumentListTableSpec(egIDs, "DocumentList", "");  // to get spec for "DocumentList"
            tsCoin[i++] = GetDocumentListTableSpec(egIDs, "DocumentList", "_Archive");  // to get spec for "DocumentList_Archive"
            tsCoin[i++] = GetDocumentListTableSpec(egIDs, "DocumentList", "_Old");  // to get spec for "DocumentList_Old"
            tsCoin[i++] = GetDocumentListTableSpec(egIDs, "DocumentList", "_DeletedClientGroups");  // to get spec for "_DeletedClientGroups"

            //            tsCoin[i].TableName = "DocumentList";
            //            tsCoin[i++].SelectSql = @"select dl.ID                           as [ID],
            //                                        ClientID,
            //                                        UserID,
            //                                        Date,
            //                                        DocName,
            //                                        FileType,
            //                                        Source,
            //                                        Reviewed,
            //                                        Status,
            //                                        Progress,
            //                                        dl.IsSOA,
            //                                        FinalisedDate,
            //                                        TemplateID,
            //                                        SWDocumentID,
            //                                        s.Description                       as [DocumentDescription],
            //                                        ReferenceID,
            //                                        FaxStatusCode,
            //                                        StatusType,
            //                                        StatusDate,
            //                                        FaxStatusDesc
            //                                      from DocumentList dl
            //                                      inner join Documents d
            //                                      on dl.id  = d.ID
            //                                      left join SWDocuments s
            //                                      on dl.SWDocumentID = s.id
            //                                      WHERE (" + GetCondition("ClientID", egIDs) + ")";

            tsCoin[i++] = GetDocumentTableSpec(egIDs, "Documents", "");  // to get spec for "Documents"
            tsCoin[i++] = GetDocumentTableSpec(egIDs, "Documents", "_Archive");  // to get spec for "Documents_Archive"
            tsCoin[i++] = GetDocumentTableSpec(egIDs, "Documents", "_Old");  // to get spec for "Documents_Old"
            tsCoin[i++] = GetDocumentTableSpec(egIDs, "Documents", "_DeletedClientGroups");  // to get spec for "Documents_DeletedClientGroups"

            //            tsCoin[i].TableName = "Documents";
            //            tsCoin[i++].SelectSql = @"select d.id, d.Zipped
            //                                      from DocumentList dl
            //                                      inner join Documents d
            //                                      on dl.id  = d.ID
            //                                      WHERE (" + GetCondition("ClientID", egIDs) + ")";

            tsCoin[i].TableName = "ProfessionalMapping";
            tsCoin[i++].SelectSql = @"select ClientID, ProfessionalID,RefDate,Referal,RefClientID 
                                    from clientprofessionals
                                    where (" + GetCondition("ClientID", egIDs) + ") AND (RefClientID is NULL)" +
                                    " UNION " +
                                    @"select ClientID, ProfessionalID,RefDate,Referal,RefClientID 
                                    from clientprofessionals
                                    where (" + GetCondition("ClientID", egIDs) + ") AND (" +
                                    GetCondition("RefClientID", egIDs) + ")";

            tsCoin[i].TableName = "Loans";
            tsCoin[i++].SelectSql = @"SELECT  lff.ID                                      ,
                                    lff.Description                                       ,
                                    LoanFFID AS [Loan Type]                               ,
                                    Rates            AS [Repayment Rate]                  ,
                                    Frequency                                             ,
									Amount, 
									RepaymentType    AS [Repayment Type],
                                    RepaymentAmount AS [Repayment Amount]                 ,
                                    RegularFees     AS [Regular Fees (per month)]         ,
                                    Limit           AS [Fee Limit Amount]                 ,
                                    ApplyLimit      AS [Apply Limit On Fees]              ,
                                    SecuredBy       AS [Secured By]                       ,
                                    e.EntityGroupID AS [Group Id]                         ,
                                    Comment                                               ,
                                    RedrawAmount      AS [Available Redraw Amount]        ,
                                    MarginLendingType AS [Margin Lending Type Description],
                                    Deductible        AS [Deductible %]                   ,
                                    EarlyRepayCosts   AS [Early Repay Costs]              ,
                                    AcctNo            AS [Account Number]                 ,
                                    Lender                                                ,
                                    ValuationDate AS [Valuation Date]                     ,
                                    EndDate       AS [Repayment End Date]                 ,
                                    LoanStatusID AS [Loan Status ID]                      ,
                                    Retain                                                ,
                                    EntityID AS [Entity ID]
                            FROM    LoanFactFind lff
                                    INNER JOIN LoanFactFindType lfft
                                    ON      lff.Loanffid = lfft.id
                                    INNER JOIN vw_entities e
                                    ON      e.id = lff.entityid
                                    WHERE (" + GetCondition("e.entitygroupid", egIDs) + ")";

            tsCoin[i].TableName = "LifestyleAssets";
            tsCoin[i++].SelectSql = @"select ID, ClientID, EntID, Description, Amount, CentrelinkAmount, LifeFFRetain, PurchasePrice, PurchaseDate, AsSecurity 
                                    from LifestyleFactFind
                                    where (" + GetCondition("ClientID", egIDs) + ")" +
                                    @"union 
                                    select pr.ID, pr.ClientID, e.ID as EntID, 'Principal Residence' as Description, pr.Amount, 0,0,0, pr.PurchaseDate, pr.DisplayPrincipalResidenceInReport
                                    from dbo.PrincipalResidenceFactFind pr, entities e
                                    where (" + GetCondition("pr.clientid", egIDs) + ")" + 
                                    @" and pr.clientid = e.EntityGroupID and pr.EntityTypeCode = e.EntityTypeCode
                                    union
                                    select pr.ID, pr.ClientID, j.ID as EntID, 'Principal Residence' as Description, pr.Amount, 0,0,0, pr.PurchaseDate, pr.DisplayPrincipalResidenceInReport
                                    from dbo.PrincipalResidenceFactFind pr, joint j
                                    where (" + GetCondition("pr.clientid", egIDs) + ")" + 
                                    @" and pr.clientid = j.clientid and pr.EntityTypeCode = j.EntityTypeCode";

            tsCoin[i].TableName = "PackageEntities";
            tsCoin[i++].SelectSql = @"Select * from ClientBusinessEntities";

            tsCoin[i].TableName = "Package";
            tsCoin[i++].SelectSql = @"select cb.*, cf.BillingRef
                                    from ClientBusiness cb join ClientFees cf on cb.ID = cf.ClientBusinessID
                                    where cb.Status is not null and cb.Status <> 'Recommended' and (" + GetCondition("cb.EntityGroupID", egIDs) + ")";

            tsCoin[i].TableName = "PackageService";
            tsCoin[i++].SelectSql = @"select cb.EntityGroupID, cas.*
                                    from ClientAssociatedServices cas join ClientBusiness cb on cb.ID = cas.ClientBusinessID 
                                    where (" + GetCondition("cb.EntityGroupID", egIDs) + ")";

            tsCoin[i].TableName = "PackagePayment";
            tsCoin[i++].SelectSql = @"select cb.EntityGroupID, cf.ClientBusinessID, cp.*
                                    from ClientPayments cp join ClientFees cf on cp.ClientFeeID = cf.ID
                                    join ClientBusiness cb on cf.ClientBusinessID = cb.ID where (" + GetCondition("cb.EntityGroupID", egIDs) + ")";

            tsCoin[i].TableName = "AdditionalService";
            tsCoin[i++].SelectSql = @"select cb.*, cf.BillingRef, cf.Owing
                                    from ClientBusiness cb join ClientFees cf on cb.ID = cf.ClientBusinessID
                                    where cb.Status is null and (" + GetCondition("cb.EntityGroupID", egIDs) + ")";
            tsCoin[i].TableName = "OtherObjectives";
            tsCoin[i++].SelectSql = @"select oo.*, st.code from otherObjectives oo inner join strategytags st
                                        on st.ID = oo.objectiveid
                                        where (" + GetCondition("clientid", egIDs) + @" 
                                      )";
            foreach (HSDBTableSpecs t in tsCoin)
            {
                //Console.WriteLine("\r\n-------------------------\r\n" + t.SelectSql);
                t.CommandTimeout = 0;
            }

			DataSet dsCoin = HSDBInterfaceManager.RunSelect(Globals.commProvider, tsCoin, false);

            return dsCoin;
        }

        private static string GetCondition(string field, ArrayList egIDs) 
        {
            string result = "";
            foreach (Guid egID in egIDs) 
            {
                result += ((result != "") ? " OR " : "") + field + "='" + egID.ToString() + "'";
            }
            return result;
        }
	}
}