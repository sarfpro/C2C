using System;
using System.Data;
using System.Collections.Generic;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
	/// <summary>
	/// Summary description for AdviserTaskHandler.
	/// </summary>
	public class AdviserTaskHandler : ITableHandler
	{
        private static Dictionary<string, string> AdviserTaskLookUp = null;

		public AdviserTaskHandler()
		{
            this.Description = "Adviser Task";
            this.Code = "AK";
            this.DataRelated = DataRelatedEnum.Adviser;
            AdviserTaskLookUp = new Dictionary<string, string>();
		}

        //CD 2011.4.5 bug 17404 to add _Archive _Old support, and blob storage support
        public override void Import()
        {
            Import("");
            Import("_Archive");
            Import("_Old");
        }

        private void Import(string suffix) 
        {
            DataTable dt = InitTable();
            DataView dvReviews  = Globals.dsCoinByAdviser.Tables["AdviserReviews" + suffix].DefaultView;
            dvReviews.RowFilter = "(AssignedBy='" + this.Importer.CurrentAdviser.ToString()
                                    + "' OR UserID='" + this.Importer.CurrentAdviser.ToString()
                                    + "') AND ClientID is null"; 

            for (int i = 0; i < dvReviews.Count; ++i) 
            {
                DataRow reviewRow        = dvReviews[i].Row;

                //Don't include tasks that are already written - Tasks can be assigned to more than one user
                if (!AdviserTaskLookUp.ContainsKey(reviewRow["ID"].ToString()))
                {
                    dt.Rows[0]["AdviserTaskID"] = reviewRow["ID"];
                    dt.Rows[0]["Date"] = Globals.GetDateString(reviewRow["Date"]);
                    dt.Rows[0]["Status"] = reviewRow["Status"];
                    dt.Rows[0]["Comments"] = Globals.NotesTextConverter(reviewRow["Comments"].ToString());
                    dt.Rows[0]["ClientID"] = reviewRow["ClientID"];
                    dt.Rows[0]["Priority"] = reviewRow["Priority"];

                    DataView dvUsers = Globals.dsCoinGlobals.Tables["Users"].DefaultView;
                    dvUsers.RowFilter = "ID='" + reviewRow["AssignedBy"].ToString() + "'";
                    string userName = dvUsers[0].Row["UserName"].ToString();

                    dt.Rows[0]["AssignedBy"] = userName;
                    dt.Rows[0]["DateCompleted"] = Globals.GetDateString(reviewRow["DateCompleted"]);
                    dt.Rows[0]["Notify"] = reviewRow["Notify"];
                    dt.Rows[0]["TimeSpentType"] = reviewRow["TimeSpentType"];
                    dt.Rows[0]["TimeSpentValue"] = reviewRow["TimeSpentValue"];
                    dt.Rows[0]["Notify2"] = reviewRow["Notify2"];
                    dt.Rows[0]["Subject"] = Globals.NotesTextConverter(reviewRow["Subject"].ToString());
                    dt.Rows[0]["Frequency"] = reviewRow["Frequency"];
                    dt.Rows[0]["AutoGen"] = reviewRow["AutoGen"];
                    string category = reviewRow["Category Description"].ToString();
                    if (CommonUI.MappingControl.CustomMapping && CommonUI.MappingControl.reviewCategoryMapping.ContainsKey(category))
                        category = CommonUI.MappingControl.reviewCategoryMapping[category];
                    dt.Rows[0]["Category Description"] = category;
                    dt.Rows[0]["TimeSpentnonBillable"] = reviewRow["TimeSpentnonBillable"];
                    dt.Rows[0]["TimeSpentBillable"] = reviewRow["TimeSpentBillable"];
                    dt.Rows[0]["TimeSpentTotal"] = reviewRow["TimeSpentTotal"];
                    dt.Rows[0]["HourlyRate"] = reviewRow["HourlyRate"];
                    dt.Rows[0]["TotalCharge"] = reviewRow["TotalCharge"];
                    dt.Rows[0]["InvoiceAmount"] = reviewRow["InvoiceAmount"];
                    dt.Rows[0]["DateCreated"] = Globals.GetDateString(reviewRow["DateCreated"]);

                    Globals.AddToSetup("Review Categories|" + category);

                    this.Lines.Append(this.RowToString(dt));
                    ++this.Count;

                    AdviserTaskLookUp.Add(reviewRow["ID"].ToString(), "Exported");
                }
            }
        }

        protected override void InitFields(DataTable dt) 
        {
            dt.Columns.Add("AdviserTaskID");
            dt.Columns.Add("Date"); 
            dt.Columns.Add("Status"); 
            dt.Columns.Add("Comments");
            dt.Columns.Add("ClientID"); 
            dt.Columns.Add("Priority"); 
            dt.Columns.Add("AssignedBy");
            dt.Columns.Add("DateCompleted");
            dt.Columns.Add("Notify");
            dt.Columns.Add("TimeSpentType");
            dt.Columns.Add("TimeSpentValue");
            dt.Columns.Add("Notify2");
            dt.Columns.Add("Subject");
            dt.Columns.Add("Frequency");
            dt.Columns.Add("AutoGen");
            dt.Columns.Add("Category Description");
            dt.Columns.Add("TimeSpentnonBillable");
            dt.Columns.Add("TimeSpentBillable");
            dt.Columns.Add("TimeSpentTotal");
            dt.Columns.Add("HourlyRate");
            dt.Columns.Add("TotalCharge");
            dt.Columns.Add("InvoiceAmount");
            dt.Columns.Add("DateCreated");
        }
	}
}
