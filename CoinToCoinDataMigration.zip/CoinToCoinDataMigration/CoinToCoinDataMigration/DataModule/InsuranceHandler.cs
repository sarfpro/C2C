using System;
using System.Data;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
	public class InsuranceHandler:ITableHandler
	{
		public InsuranceHandler()
		{
			this.Description = "Insurance";
			this.Code = "IS";
			this.DataRelated = DataRelatedEnum.Client;
		}

		public override void Import() 
		{
			DataTable dt = InitTable();
	
			string clientID = "'" + this.Importer.CurrentClient.ToString() + "'";

			string filter = "ClientID = " + clientID;

			//foreach(DataRow row in dvInsurances.Table.Rows)
			foreach(DataRow row in Globals.dsCoinByClient.Tables["Insurances"].Select(filter))
			{
				dt.Rows[0]["Primary Owner"]			= row["Primary Owner"];
				dt.Rows[0]["Insurance Type"]		= row["Insurance Type"];
				dt.Rows[0]["Product Name"]			= row["Product Name"];
				dt.Rows[0]["Underwriter"]			= row["Underwriter"];
				dt.Rows[0]["Insurance Status"]		= row["Insurance Status"];
				dt.Rows[0]["Expiry Date"]			= row["Expiry Date"];
				dt.Rows[0]["Benefit Amount / Level of Cover"]   
													= row["Benefit Amount / Level of Cover"];
				dt.Rows[0]["Escalation"]			= row["Escalation"];
				dt.Rows[0]["Benefit Frequency"]		= row["Benefit Frequency"];
				dt.Rows[0]["Current Premium"]		= row["Current Premium"];
				dt.Rows[0]["Premium Frequency"]		= row["Premium Frequency"];

				if (row["Policy Number"].ToString() == string.Empty)
					dt.Rows[0]["Policy Number"]	= "empty policy no.";
				else
					dt.Rows[0]["Policy Number"]			= row["Policy Number"];

				dt.Rows[0]["Beneficiary 1"]				= row["Beneficiary 1"];	
				dt.Rows[0]["Percentage Beneficiary 1"]	= row["Percentage Beneficiary 1"];
                //dt.Rows[0]["Beneficiary 2"]				= "";
                //dt.Rows[0]["Percentage Beneficiary 2"]	= "";
                //dt.Rows[0]["Beneficiary 3"]				= "";
                //dt.Rows[0]["Percentage Beneficiary 3"]	= "";

                dt.Rows[0]["Next Review Date"] = row["Next Review Date"];
                dt.Rows[0]["Submitted Underwriter Date"] = row["Submitted Underwriter Date"];
                dt.Rows[0]["Issue Date"] = row["Issue Date"];
                dt.Rows[0]["Anniversary Date"] = row["Anniversary Date"];
                dt.Rows[0]["Renewal Date"] = row["Renewal Date"];
                dt.Rows[0]["Issue Status"] = row["Issue Status"];

				dt.Rows[0]["Insured"]				= row["Insured"];
				dt.Rows[0]["Policy Commencement Date"]   
													= row["Policy Commencement Date"];
				dt.Rows[0]["Premium Type"]			= row["Premium Type"];
				dt.Rows[0]["Business Expense Benefit Period - Accident"]   
													= row["Business Expense Benefit Period - Accident"];
				dt.Rows[0]["Business Expense Benefit Period - Sickness"]   
													= row["Business Expense Benefit Period - Sickness"];
				dt.Rows[0]["Business Expense Waiting Period"]   
													= row["Business Expense Waiting Period"];
				dt.Rows[0]["Business Expense Benefit Type"] 
													= row["Business Expense Benefit Type"];
				dt.Rows[0]["Occupation Type"]		= row["Occupation Type"];
				dt.Rows[0]["Income Protection Benefit Period - Accident"]   
													= row["Income Protection Benefit Period - Accident"];
				dt.Rows[0]["Income Protection Benefit Period - Sickness"]   
													= row["Income Protection Benefit Period - Sickness"];
				dt.Rows[0]["Income Protection Waiting Period"]   
													= row["Income Protection Waiting Period"];
				dt.Rows[0]["Income Protection Benefit Type"]  
													= row["Income Protection Benefit Type"];
				dt.Rows[0]["Commission percentage"] = row["Commission percentage"];
				dt.Rows[0]["Adviser Entitlement"]   = row["Adviser Entitlement"];
                dt.Rows[0]["Comments"]              = Globals.NotesTextConverter(row["Comments"].ToString());
				dt.Rows[0]["Insurance ID"]			= row["Insurance ID"];

                dt.Rows[0]["Payment ID"] = row["Payment ID"];
                dt.Rows[0]["Bank Account No"] = row["Bank Account No"];
                dt.Rows[0]["Bank Account BSB"] = row["Bank Account BSB"];


                

                
                dt.Rows[0]["ClientID"] = row["ClientID"];
                dt.Rows[0]["EntityTypeCode"] = row["EntityTypeCode"];

                dt.Rows[0]["InsuredDesc"] = row["InsuredDesc"];
                dt.Rows[0]["EntityDescription"] = row["EntityDescription"];
                dt.Rows[0]["OtherEntDesc"] = row["OtherEntDesc"];

                this.Lines.Append(this.RowToString(dt));
				++this.Count;
			}

		}

		protected override void InitFields(DataTable dt)
		{
            string[] columns = { "Primary Owner", "Insurance Type", "Product Name", "Underwriter", "Insurance Status", "Expiry Date", "Benefit Amount / Level of Cover", "Escalation", "Benefit Frequency", "Current Premium", "Premium Frequency", "Policy Number", "Beneficiary 1", "Percentage Beneficiary 1", "Beneficiary 2", "Percentage Beneficiary 2", "Beneficiary 3", "Percentage Beneficiary 3", "Insured", "Policy Commencement Date", "Premium Type", "Business Expense Benefit Period - Accident", "Business Expense Benefit Period - Sickness", "Business Expense Waiting Period", "Business Expense Benefit Type", "Occupation Type", "Income Protection Benefit Period - Accident", "Income Protection Benefit Period - Sickness", "Income Protection Waiting Period", "Income Protection Benefit Type", "Commission percentage", "Adviser Entitlement", "Comments", "Insurance ID", "Payment ID", "Bank Account No", "Bank Account BSB", "Next Review Date", "Submitted Underwriter Date", "Issue Date", "Anniversary Date", "Renewal Date", "Issue Status", "ClientID", "EntityTypeCode", "InsuredDesc", "EntityDescription", "OtherEntDesc" };
			foreach(string col in columns)
				dt.Columns.Add(col);
		}
	}
}
