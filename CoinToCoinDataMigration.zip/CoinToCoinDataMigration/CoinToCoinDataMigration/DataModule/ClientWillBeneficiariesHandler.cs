using System;
using System.Data;

namespace CoinToCoinDataMigration.DataModule
{
	public class ClientWillBeneficiariesHandler:ITableHandler
	{
		public ClientWillBeneficiariesHandler()
		{
			this.Description = "Wills Beneficiaries";
			this.Code = "WB";
			this.DataRelated = DataRelatedEnum.Client;
		}

		public override void Import() 
		{
			DataTable dt = InitTable();
			DataView dv  = Globals.dsCoinByClient.Tables["ClientWillBeneficiaries"].DefaultView;
			dv.RowFilter = "ClientID ='" + this.Importer.CurrentClient.ToString() + "'";

			for (int i = 0; i < dv.Count; ++i) 
			{
				DataRow row        = dv[i].Row;

				dt.Rows[0]["GroupID"]						= row["ClientID"];
				dt.Rows[0]["EntityId"]						= row["EntityId"];
				dt.Rows[0]["BeneficiaryFirstName"]		= row["FirstName"];
				dt.Rows[0]["BeneficiaryLastName"]		= row["Surname"];
				dt.Rows[0]["EntitlementAge"]				= row["EntitlementAge"];
				dt.Rows[0]["PercentageEntitlement"]	= row["Portion"];

				this.Lines.Append(this.RowToString(dt));
				++this.Count;
			}
		}

		protected override void InitFields(DataTable dt)
		{
			string[] columns = {"GroupID","EntityID","BeneficiaryFirstName","BeneficiaryLastName","EntitlementAge","PercentageEntitlement"};
			foreach(string col in columns)
				dt.Columns.Add(col);
		}
	}
}
