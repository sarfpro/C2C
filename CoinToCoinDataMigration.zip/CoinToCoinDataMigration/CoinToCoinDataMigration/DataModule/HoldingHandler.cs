using System;
using System.Data;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
	/// <summary>
	/// Summary description for HoldingHandler.
	/// </summary>
	public class HoldingHandler : ITableHandler
	{
		public HoldingHandler()
		{
			//
			// TODO: Add constructor logic here
			//
            this.Description = "Holding";
            this.Code = "HO";
            this.DataRelated = DataRelatedEnum.Client;

            // whenever an object is created, clean the product list
            Globals.ProductInHoldingList.Clear();
		}

        public override void Import() 
        {
            DataView dvEntClients  = Globals.dsCoinByClient.Tables["Ent_Clients"].DefaultView;
            dvEntClients.RowFilter = "EntityGroupID='" + this.Importer.CurrentClient.ToString() + "'";
            ImportHoldings(dvEntClients, "CLI");

            DataView dvEntSpouses  = Globals.dsCoinByClient.Tables["Ent_Spouses"].DefaultView;
            dvEntSpouses.RowFilter = "EntityGroupID='" + this.Importer.CurrentClient.ToString() + "'";
            ImportHoldings(dvEntSpouses, "SPS");

            DataView dvJoint  = Globals.dsCoinByClient.Tables["Joint"].DefaultView;
            dvJoint.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";
            ImportHoldings(dvJoint, "JOI");

            DataView dvCompanies  = Globals.dsCoinByClient.Tables["Companies"].DefaultView;
            dvCompanies.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";
            ImportHoldings(dvCompanies, "COM");

            DataView dvSuperFund  = Globals.dsCoinByClient.Tables["SuperFund"].DefaultView;
            dvSuperFund.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";
            ImportHoldings(dvSuperFund, "SUP");

            DataView dvTrusts  = Globals.dsCoinByClient.Tables["Trusts"].DefaultView;
            dvTrusts.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";
            ImportHoldings(dvTrusts, "TRU");

            DataView dvOther  = Globals.dsCoinByClient.Tables["Other"].DefaultView;
            dvOther.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";
            ImportHoldings(dvOther, "OTH");
        }

        protected override void InitFields(DataTable dt) 
        {
            dt.Columns.Add("HoldingID");
            dt.Columns.Add("ClientID");
            dt.Columns.Add("ProductID");
            dt.Columns.Add("AccountID");
            dt.Columns.Add("TaxStructure");
            dt.Columns.Add("AccountNumber");
            dt.Columns.Add("Description");
            dt.Columns.Add("ExpiryDate");
            dt.Columns.Add("ReinvestIncome");
            dt.Columns.Add("SubjectToCGT");

            dt.Columns.Add("TrailBrokrage");
            dt.Columns.Add("AllowWCA");
            dt.Columns.Add("FUMApplies");
            dt.Columns.Add("ExcludeReport");
            dt.Columns.Add("ExcludeDist");
            dt.Columns.Add("UsedAsSecurity");
            dt.Columns.Add("ExcludeAdvice");
            dt.Columns.Add("CentrelinkExempt");

            dt.Columns.Add("Comments");
            dt.Columns.Add("MappingID");
            dt.Columns.Add("MappingSourceID");
        }

        private void ImportHoldings(DataView dv, string type) 
        {
            for (int i = 0; i < dv.Count; ++i) 
            {
                DataRow entRow = dv[i].Row;
                string entID     = (type == "CLI" || type == "SPS") ? dv[i].Row["EntityID"].ToString() : dv[i].Row["ID"].ToString();

                DataView dvAssets = Globals.dsCoinByClient.Tables["P_Assets"].DefaultView;
                dvAssets.RowFilter = "AS_EN='" + entID + "'";

                for (int j = 0; j < dvAssets.Count; ++j) 
                {
                    DataRow assetRow = dvAssets[j].Row;

                    DataView dvTrans  = Globals.dsCoinByClient.Tables["P_Trans"].DefaultView;
                    dvTrans.RowFilter = "TX_AS='" + assetRow["AS_ID"].ToString() + "'";

                    if (dvTrans.Count == 0)
                        continue;

                    DataTable dt = InitTable();
                    dt.Rows[0]["HoldingID"]     = assetRow["AS_ID"];
                    dt.Rows[0]["ClientID"]      = entID.ToString();
                    dt.Rows[0]["ProductID"]     = assetRow["AS_PR"];
                    dt.Rows[0]["AccountID"]     = assetRow["AS_AG"];
                    dt.Rows[0]["TaxStructure"]  = assetRow["TaxCode"];
                    dt.Rows[0]["AccountNumber"] = assetRow["AS_PolicyAcctNo"];
                    dt.Rows[0]["Description"]   = assetRow["AS_Desc"].ToString().Replace(",","").Replace(Environment.NewLine,"").Replace("\n","").Replace("\r","");
                    dt.Rows[0]["ExpiryDate"] = assetRow["AS_ExpDate"];
                    dt.Rows[0]["ReinvestIncome"] = Convert.ToBoolean(assetRow["AS_ReinvestIncome"]) ? 1 : 0;
                    dt.Rows[0]["SubjectToCGT"]  = Convert.ToBoolean(assetRow["AS_CGTTax"]) ? 1 : 0;
                    dt.Rows[0]["TrailBrokrage"] = Convert.ToBoolean(assetRow["AS_TrailBrokrage"]) ? 1 : 0;
                    dt.Rows[0]["AllowWCA"] = Convert.ToBoolean(assetRow["AS_IsWCA"]) ? 1 : 0;
                    dt.Rows[0]["FUMApplies"] = Convert.ToBoolean(assetRow["AS_FUM"]) ? 1 : 0;
                    dt.Rows[0]["ExcludeReport"] = Convert.ToBoolean(assetRow["AS_ReportExclude"]) ? 1 : 0;
                    dt.Rows[0]["ExcludeDist"] = Convert.ToBoolean(assetRow["AS_ExcludeDist"]) ? 1 : 0;
                    dt.Rows[0]["UsedAsSecurity"] = Convert.ToBoolean(assetRow["AS_UsedAsSecurity"]) ? 1 : 0;
                    dt.Rows[0]["ExcludeAdvice"] = Convert.ToBoolean(assetRow["AS_ExcludeFromAdvice"]) ? 1 : 0;
                    dt.Rows[0]["CentrelinkExempt"] = Convert.ToBoolean(assetRow["AS_CentrelinkExempt"]) ? 1 : 0;
                    if (!string.IsNullOrEmpty(assetRow["AS_Source"].ToString()))
                        dt.Rows[0]["Comments"] = assetRow["AS_Comments"] + "\r\n Source: " + assetRow["AS_Source"]; 
                    else
                        dt.Rows[0]["Comments"] = assetRow["AS_Comments"]; 

                    //*** Section to allow for Macquarie CMT mappings - in progress Brett 2009/08/24
                    //DataView dvDataFeed = Globals.dsCoinGlobals.Tables["DataFeedClientMapping"].DefaultView;
                    //dvDataFeed.RowFilter = "IntID=" + Hsid.StringToHsid(entID.ToString()).GetAsQuotedString();

                    //string mappingID = (dvDataFeed.Count > 0) ? dvDataFeed[0].Row["ExtID"].ToString() : "";
                    //string mappingSourceID = (dvDataFeed.Count > 0) ? dvDataFeed[0].Row["ExtGroup"].ToString() : "";

                    //dt.Rows[0]["MappingID"] = mappingID;
                    //dt.Rows[0]["MappingSourceID"] = mappingSourceID;
                    //*** 

                    this.Lines.Append(this.RowToString(dt));
                    ++this.Count;

                    // add the productid into product in holding list if it is checked
                    if (Globals.ProductsInHolding)
                    {
                        // add the product id if it is not in list
                        if (!Globals.ProductInHoldingList.Contains(assetRow["AS_PR"].ToString()))
                            Globals.ProductInHoldingList.Add(assetRow["AS_PR"].ToString());
                    }
                }
            }
        }
	}
}
