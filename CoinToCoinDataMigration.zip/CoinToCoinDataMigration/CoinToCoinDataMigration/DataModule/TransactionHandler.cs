using System;
using System.Data;
using System.Text;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
	/// <summary>
	/// Summary description for TransactionHandler.
	/// </summary>
	public class TransactionHandler : ITableHandler
	{
		public TransactionHandler()
		{
			//
			// TODO: Add constructor logic here
			//
            this.Description = "Transaction";
            this.Code = "TR";
            this.DataRelated = DataRelatedEnum.Client;
		}

        public override void Import() 
        {
            DataView dvEntClients  = Globals.dsCoinByClient.Tables["Ent_Clients"].DefaultView;
            dvEntClients.RowFilter = "EntityGroupID='" + this.Importer.CurrentClient.ToString() + "'";
            ImportTransactions(dvEntClients, "CLI");

            DataView dvEntSpouses  = Globals.dsCoinByClient.Tables["Ent_Spouses"].DefaultView;
            dvEntSpouses.RowFilter = "EntityGroupID='" + this.Importer.CurrentClient.ToString() + "'";
            ImportTransactions(dvEntSpouses, "SPS");

            DataView dvJoint  = Globals.dsCoinByClient.Tables["Joint"].DefaultView;
            dvJoint.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";
            ImportTransactions(dvJoint, "JOI");

            DataView dvCompanies  = Globals.dsCoinByClient.Tables["Companies"].DefaultView;
            dvCompanies.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";
            ImportTransactions(dvCompanies, "COM");

            DataView dvSuperFund  = Globals.dsCoinByClient.Tables["SuperFund"].DefaultView;
            dvSuperFund.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";
            ImportTransactions(dvSuperFund, "SUP");

            DataView dvTrusts  = Globals.dsCoinByClient.Tables["Trusts"].DefaultView;
            dvTrusts.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";
            ImportTransactions(dvTrusts, "TRU");

            DataView dvOther  = Globals.dsCoinByClient.Tables["Other"].DefaultView;
            dvOther.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";
            ImportTransactions(dvOther, "OTH");
        }

        protected override void InitFields(DataTable dt) 
        {
            dt.Columns.Add("TransactionID");
            dt.Columns.Add("HoldingID");
            dt.Columns.Add("TransactionType");
            dt.Columns.Add("TransactionDate");
            dt.Columns.Add("ProductID");
            dt.Columns.Add("ClientID");
            dt.Columns.Add("Units");
            dt.Columns.Add("GrossAmount");
            dt.Columns.Add("CostBase");
            dt.Columns.Add("ClientFees");
            dt.Columns.Add("Fees");
            dt.Columns.Add("Tax");
            dt.Columns.Add("NetAmount");
            dt.Columns.Add("IsInitTrans");
            dt.Columns.Add("TransactionStatus");
            dt.Columns.Add("GrossEntitlement");
            dt.Columns.Add("WithholdingTaxDomestic");
            dt.Columns.Add("WithholdingTaxForeign");
            dt.Columns.Add("OtherTax");
            dt.Columns.Add("NetEntitlement");
            dt.Columns.Add("FrankedDividends");
            dt.Columns.Add("UnfrankedDividends");
            dt.Columns.Add("ImputationCredits");
            dt.Columns.Add("DomesticInterest");
            dt.Columns.Add("ForeginInterest");
            dt.Columns.Add("ReturnOfCapital");
            dt.Columns.Add("TaxFree");
            dt.Columns.Add("TaxDeferred");
            dt.Columns.Add("CapitalGainsIndexed");
            dt.Columns.Add("CapitalGainsDiscount");
            dt.Columns.Add("CapitalGainsOther");
            dt.Columns.Add("TaxExempt");
            dt.Columns.Add("ForeignCapitalGains");
            dt.Columns.Add("ForeignTaxCredits");
            dt.Columns.Add("OtherIncome");
            dt.Columns.Add("Comments");
        }

        private void ImportTransactions(DataView dv, string type) 
        {
            StringBuilder tempLines = new StringBuilder();
            for (int i = 0; i < dv.Count; ++i) 
            {
                DataRow entRow = dv[i].Row;
                string entID   = (type == "CLI" || type == "SPS") ? dv[i].Row["EntityID"].ToString() : dv[i].Row["ID"].ToString();

                DataView dvAssets = Globals.dsCoinByClient.Tables["P_Assets"].DefaultView;
                dvAssets.RowFilter = "AS_EN='" + entID + "'";

                for (int j = 0; j < dvAssets.Count; ++j) 
                {
                    DataRow assetRow  = dvAssets[j].Row;
                    DataView dvTrans  = Globals.dsCoinByClient.Tables["P_Trans"].DefaultView;
                    dvTrans.RowFilter = "TX_AS='" + assetRow["AS_ID"].ToString() + "'";

                    for (int k = 0; k < dvTrans.Count; ++k) 
                    {
                        DataRow transRow = dvTrans[k].Row;

                        DataTable dt = InitTable();
                        dt.Rows[0]["TransactionID"] = transRow["TX_ID"];
                        dt.Rows[0]["HoldingID"] = transRow["TX_AS"];
                        dt.Rows[0]["TransactionType"] = transRow["TX_TP"];
                        dt.Rows[0]["TransactionDate"] = Globals.GetDateString(transRow["TX_Date"]);
                        dt.Rows[0]["ProductID"] = assetRow["AS_PR"];
                        dt.Rows[0]["ClientID"] = assetRow["AS_EN"];
                        dt.Rows[0]["Units"] = Math.Abs(HolisticFS.GenUtils.SafeConvert.ToDouble(transRow["TX_Quantity"].ToString()));
                        dt.Rows[0]["GrossAmount"] = Math.Abs(HolisticFS.GenUtils.SafeConvert.ToDouble(transRow["TX_GrossAmount"].ToString()));
                        dt.Rows[0]["CostBase"] = transRow["TX_UserCostBase"] != DBNull.Value ? Math.Abs(HolisticFS.GenUtils.SafeConvert.ToDouble(transRow["TX_UserCostBase"].ToString())).ToString() : "";
                        dt.Rows[0]["ClientFees"] = Math.Abs(HolisticFS.GenUtils.SafeConvert.ToDouble(transRow["TX_ClientFees"].ToString()));
                        dt.Rows[0]["Fees"] = transRow["TX_OtherFees"];
                        dt.Rows[0]["Tax"] = transRow["TX_OtherTax"];

                        double grossAmount = HolisticFS.GenUtils.SafeConvert.ToDouble(transRow["TX_GrossAmount"].ToString());
                        double clientFees = HolisticFS.GenUtils.SafeConvert.ToDouble(transRow["TX_ClientFees"].ToString());
                        double fees        = HolisticFS.GenUtils.SafeConvert.ToDouble(transRow["TX_OtherFees"].ToString());
                        double tax         = HolisticFS.GenUtils.SafeConvert.ToDouble(transRow["TX_OtherTax"].ToString());

                        dt.Rows[0]["NetAmount"] = grossAmount - clientFees - fees - tax;

                        dt.Rows[0]["IsInitTrans"] = transRow["TX_IsInitTrans"].ToString().Equals("TRUE") ? "1" : "0";
                        dt.Rows[0]["TransactionStatus"] = transRow["TX_TS"];

                        dt.Rows[0]["GrossEntitlement"] = transRow["TX_GrossEntitlement"];
                        dt.Rows[0]["WithholdingTaxDomestic"] = transRow["TX_DomesticWTax"];
                        dt.Rows[0]["WithholdingTaxForeign"] = transRow["TX_ForeignWTax"];
                        dt.Rows[0]["OtherTax"] = transRow["TX_OtherTax"];

                        double grossEntitlement = HolisticFS.GenUtils.SafeConvert.ToDouble(transRow["TX_GrossEntitlement"].ToString());
                        double domesticWTax     = HolisticFS.GenUtils.SafeConvert.ToDouble(transRow["TX_DomesticWTax"].ToString());
                        double foreignWTax      = HolisticFS.GenUtils.SafeConvert.ToDouble(transRow["TX_ForeignWTax"].ToString());
                        double otherTax         = HolisticFS.GenUtils.SafeConvert.ToDouble(transRow["TX_OtherTax"].ToString());

                        dt.Rows[0]["NetEntitlement"] = grossEntitlement - domesticWTax - foreignWTax - otherTax;
                        dt.Rows[0]["FrankedDividends"] = transRow["TX_GrossFrankDiv"];
                        dt.Rows[0]["UnfrankedDividends"] = transRow["TX_UnfrankDiv"];
                        dt.Rows[0]["ImputationCredits"] = transRow["TX_ImpCredit"];
                        dt.Rows[0]["DomesticInterest"] = transRow["TX_InterestRec"];
                        dt.Rows[0]["ForeginInterest"] = transRow["TX_ForeignInt"];
                        dt.Rows[0]["ReturnOfCapital"] = transRow["TX_RetCapGain"];
                        dt.Rows[0]["TaxFree"] = transRow["TX_TaxFree"];
                        dt.Rows[0]["TaxDeferred"] = transRow["TX_TaxDef"];
                        dt.Rows[0]["CapitalGainsIndexed"] = transRow["TX_PreAnnounce"];
                        dt.Rows[0]["CapitalGainsDiscount"] = transRow["TX_PreAnnounceDisc"];
                        dt.Rows[0]["CapitalGainsOther"] = transRow["TX_PreAnnounceUnDisc"];
                        dt.Rows[0]["TaxExempt"] = transRow["TX_TaxExemp"];
                        dt.Rows[0]["ForeignCapitalGains"] = transRow["TX_ForeignCapGain"];
                        dt.Rows[0]["ForeignTaxCredits"] = transRow["TX_ForeignTaxCred"];
                        dt.Rows[0]["OtherIncome"] = transRow["TX_OtherIncome"];
                        dt.Rows[0]["Comments"] = Globals.NotesTextConverter(transRow["TX_Comments"].ToString());

                        tempLines.Append(this.RowToString(dt));
                        ++this.Count;
                    }
                }
            }
            this.Lines.Append(tempLines);
        }
	}
}