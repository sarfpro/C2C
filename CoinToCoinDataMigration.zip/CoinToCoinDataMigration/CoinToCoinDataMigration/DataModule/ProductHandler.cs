using System;
using System.Data;
using HolisticFS.HSDB;
using System.Collections;

namespace CoinToCoinDataMigration.DataModule
{
	/// <summary>
	/// Summary description for ProductHandler.
	/// </summary>
	public class ProductHandler : ITableHandler
	{
		public ProductHandler()
		{
			//
			// TODO: Add constructor logic here
			//
            this.Description = "Product";
            this.Code = "PD";
            this.DataRelated = DataRelatedEnum.Other;
		}

        public override void Import() 
        {
//            string filter = "";
//            foreach (Hsid userID in this.Importer.Advisers) 
//            {
//                filter += ((filter == "") ? "" : " OR ") + "ID=" + userID.GetAsQuotedString();
//            }
//            DataView dvUsers = Globals.dsCoinGlobals.Tables["Users"].DefaultView;
//         //   dvUsers.RowFilter = filter;
//
//            filter = "DealerGroupID is null";
//            ArrayList dealerGroups = new ArrayList();
//            for (int i = 0; i < dvUsers.Count; ++i) 
//            {
//                Hsid dealerGroupID = Hsid.StringToHsid(dvUsers[i]["DealerGroupID"].ToString());
//                if (!dealerGroups.Contains(dealerGroupID)) 
//                {
//                    dealerGroups.Add(dealerGroupID);
//                    filter += " OR " + "DealerGroupID=" + dealerGroupID.GetAsQuotedString();
//                }
        //   }
       //     ArrayList doneProducts = new ArrayList();
            DataTable dt = InitTable();
            DataView dvProducts = Globals.dsCoinGlobals.Tables["Products"].DefaultView;
            dvProducts.Sort = "APIRCode";

           // dvProducts.RowFilter = filter;

            for (int i = 0; i < dvProducts.Count; ++i) 
            {
                

                // if product in holding is ticked, only put in the products that exists in list
                if (!Globals.ProductsInHolding)
                {
                    DataRow productRow = dvProducts[i].Row;

                    dt.Rows[0]["ProductID"] = productRow["ID"];
                    dt.Rows[0]["ProductName"] = productRow["Description"].ToString().Replace(",", "").Replace("'", "").Replace(Environment.NewLine, "").Replace("\n", "").Replace("\r", "");
                    dt.Rows[0]["Type"] = productRow["SectorCode"];
                    dt.Rows[0]["APIRCode"] = productRow["APIRCode"];
                    dt.Rows[0]["Unitised"] = (productRow["IsUnitised"].ToString().ToUpper() == "TRUE" ? "1" : "0");
                    dt.Rows[0]["FundType"] = (productRow["TaxCode"].ToString() != string.Empty ? productRow["TaxCode"] : "5"); //Null

                    this.Lines.Append(this.RowToString(dt));
                    ++this.Count;
                }
                else
                {
                    DataRow productRow = dvProducts[i].Row;

                    if (Globals.ProductInHoldingList.Contains(productRow["ID"].ToString()))
                    {
                        dt.Rows[0]["ProductID"] = productRow["ID"];
                        dt.Rows[0]["ProductName"] = productRow["Description"].ToString().Replace(",", "").Replace("'", "").Replace(Environment.NewLine, "").Replace("\n", "").Replace("\r", "");
                        dt.Rows[0]["Type"] = productRow["SectorCode"];
                        dt.Rows[0]["APIRCode"] = productRow["APIRCode"];
                        dt.Rows[0]["Unitised"] = (productRow["IsUnitised"].ToString().ToUpper() == "TRUE" ? "1" : "0");
                        dt.Rows[0]["FundType"] = (productRow["TaxCode"].ToString() != string.Empty ? productRow["TaxCode"] : "5"); //Null

                        this.Lines.Append(this.RowToString(dt));
                        ++this.Count;
                    }
                }


//				if (productRow["APIRCode"].ToString() == "" || (productRow["APIRCode"].ToString() != "" && !doneProducts.Contains(productRow["APIRCode"].ToString()))) 
//				{   
//
//					dt.Rows[0]["ProductID"]   = productRow["ID"];
//					dt.Rows[0]["ProductName"] = productRow["Description"].ToString().Replace(",","").Replace("'","").Replace(Environment.NewLine,"").Replace("\n","").Replace("\r","");
//					dt.Rows[0]["Type"] = productRow["SectorCode"];
//					dt.Rows[0]["APIRCode"]   =productRow["APIRCode"];
//					dt.Rows[0]["Unitised"]    = (productRow["IsUnitised"].ToString().ToUpper() == "TRUE"?"1":"0");
//					dt.Rows[0]["FundType"]    = (productRow["TaxCode"].ToString() != string.Empty ? productRow["TaxCode"]:"5"); //Null
//
//					this.Lines.Append(this.RowToString(dt));
//					++this.Count;
//
//				//Temp removed due to product duplicates in Products table.
//				//	doneProducts.Add(productRow["APIRCode"].ToString());
//				}
            }
        }

        protected override void InitFields(DataTable dt) 
        {
            dt.Columns.Add("ProductID");
            dt.Columns.Add("ProductName");
            dt.Columns.Add("Type");
            dt.Columns.Add("APIRCode");
            dt.Columns.Add("ASXCode");
            dt.Columns.Add("Unitised");
            dt.Columns.Add("FundType");
        }
	}
}
