using System;
using System.Data;
using System.Diagnostics;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
	/// <summary>
	/// Summary description for ClientTaskAssigneeHandler.
	/// </summary>
	public class ClientTaskAssigneeHandler : ITableHandler
	{
		public ClientTaskAssigneeHandler()
		{
			//
			// TODO: Add constructor logic here
			//
            this.Description = "Client Task Assignee";
            this.Code = "CS";
            this.DataRelated = DataRelatedEnum.Client; 
		}

        //CD 2011.4.5 bug 17404 to add _Archive _Old support, and blob storage support
        public override void Import()
        {
            Import("");
            Import("_Archive");
            Import("_Old");
        }
        // suffix: to support _Archive/_Old tabes as well.
        private void Import(string suffix) 
        {
            DataTable dt = InitTable();
            DataView dvReviewUsers  = Globals.dsCoinByClient.Tables["ClientReviewUsers" + suffix].DefaultView;
            dvReviewUsers.RowFilter = "ClientID='" + this.Importer.CurrentClient.ToString() + "'";

            if (dvReviewUsers.Count > 0)
            {
                for (int i = 0; i < dvReviewUsers.Count; ++i)
                {
                    DataRow reviewUsersRow = dvReviewUsers[i].Row;

                    // make sure the userid is not empty
                    if (!string.IsNullOrEmpty(reviewUsersRow["UserID"].ToString()))
                    {
                        dt.Rows[0]["ID"] = reviewUsersRow["ID"];
                        dt.Rows[0]["ReviewID"] = reviewUsersRow["ReviewID"];

                        DataView dvUsers = Globals.dsCoinGlobals.Tables["Users"].DefaultView;
                        Trace.WriteLine(reviewUsersRow["UserID"].ToString());
                        dvUsers.RowFilter = "ID='" + reviewUsersRow["UserID"].ToString() + "'";
                        string userName = reviewUsersRow["UserID"].ToString();
                        if (dvUsers.Count > 0)                    
                            userName = dvUsers[0].Row["UserName"].ToString();

                        dt.Rows[0]["UserID"] = userName;

                        this.Lines.Append(this.RowToString(dt));
                        ++this.Count;
                    }
                }
            }
        }

        protected override void InitFields(DataTable dt) 
        {
            dt.Columns.Add("ID");
            dt.Columns.Add("ReviewID"); 
            dt.Columns.Add("UserID"); 
        }
	}
}
