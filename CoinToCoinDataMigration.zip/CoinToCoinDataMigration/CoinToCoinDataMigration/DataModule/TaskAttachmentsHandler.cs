using System;
using System.IO;
using System.Data;
using System.Collections.Generic;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{
	/// <summary>
	/// Summary description for TaskAttachmentsHandler.
	/// </summary>
	public class TaskAttachmentsHandler : ITableHandler
	{

        private static Dictionary<string, string> AdviserTaskAttachmentLookUp = null;
        private static Dictionary<string, string> ClientTaskAttachmentLookUp = null;

		public TaskAttachmentsHandler()
		{
            this.Description = "TaskAttachments";
            this.Code = "TA";
            this.DataRelated = DataRelatedEnum.Client; 
            AdviserTaskAttachmentLookUp = new Dictionary<string, string>();
            ClientTaskAttachmentLookUp = new Dictionary<string, string>();
		}

        public override void Import() 
        {
            switch (this.DataRelated)
            {
                case DataRelatedEnum.Adviser: ImportAdviserAttachments();
                    break;
                case DataRelatedEnum.Client: ImportClientAttachments();
                    break;
            }

        }

        protected override void InitFields(DataTable dt) 
        {
            dt.Columns.Add("AttachmentID");
            dt.Columns.Add("TaskID");
            dt.Columns.Add("AttachmentDate");
            dt.Columns.Add("FileName");
            dt.Columns.Add("Location");
        }

        //CD 2011.4.5 bug 17404 to add _Archive _Old support, and blob storage support
        private void ImportAdviserAttachments()
        {
            ImportAdviserAttachments("");
            ImportAdviserAttachments("_Archive");
            ImportAdviserAttachments("_Old");
            ImportAdviserAttachments("_DeletedClientGroups");
        }
        private void ImportAdviserAttachments(string suffix)
        {
            DataView dvAdviserReviews = Globals.dsCoinByAdviser.Tables["AdviserReviews" + suffix].DefaultView;
            dvAdviserReviews.RowFilter = "(AssignedBy='" + this.Importer.CurrentAdviser.ToString()
                                    + "' OR UserID='" + this.Importer.CurrentAdviser.ToString()
                                    + "') AND ClientID is null";

            for (int i = 0; i < dvAdviserReviews.Count; ++i)
            {
                DataRow adviserReviewRow = dvAdviserReviews[i].Row;
                DataView dvTaskAttachments = Globals.dsCoinByAdviser.Tables["TaskAttachments" + suffix].DefaultView;
                dvTaskAttachments.RowFilter = "TaskID='" + adviserReviewRow["ID"].ToString() + "'";

                for (int j = 0; j < dvTaskAttachments.Count; ++j)
                {
                    DataTable dt = InitTable();
                    DataRow attachmentRow = dvTaskAttachments[j].Row;

                    //don't include task attachments that are already written - tasks can be assigned to more than one user
                    if (!AdviserTaskAttachmentLookUp.ContainsKey(attachmentRow["ID"].ToString()))
                    {
                        AddAttachmentRow(dt, attachmentRow, suffix);
                        AdviserTaskAttachmentLookUp.Add(attachmentRow["ID"].ToString(), "Exported");
                    }
                }
            }

        }

        //CD 2011.4.5 bug 17404 to add _Archive _Old support, and blob storage support
        private void ImportClientAttachments()
        {
            ImportClientAttachments("");
            ImportClientAttachments("_Archive");
            ImportClientAttachments("_Old");
            ImportClientAttachments("_DeletedClientGroups");
        }
        private void ImportClientAttachments(string suffix)
        {

            DataView dvClientReviews = Globals.dsCoinByClient.Tables["ClientReviews" + suffix].DefaultView;
            dvClientReviews.RowFilter = "ClientID = '" + this.Importer.CurrentClient.ToString() + "'";

            for (int i = 0; i < dvClientReviews.Count; ++i)
            {
                DataRow clientReviewRow = dvClientReviews[i].Row;
                DataView dvTaskAttachments = Globals.dsCoinByClient.Tables["TaskAttachments" + suffix].DefaultView;
                dvTaskAttachments.RowFilter = "TaskID='" + clientReviewRow["ID"].ToString() + "'";

                for (int j = 0; j < dvTaskAttachments.Count; ++j)
                {
                    DataTable dt = InitTable();
                    DataRow attachmentRow = dvTaskAttachments[j].Row;

                    //don't include task attachments that are already written - tasks can be assigned to more than one user
                    if (!ClientTaskAttachmentLookUp.ContainsKey(attachmentRow["ID"].ToString()))
                    {
                        AddAttachmentRow(dt, attachmentRow, suffix);
                        ClientTaskAttachmentLookUp.Add(attachmentRow["ID"].ToString(), "Exported");
                    }
                }
            }
        }

        private void AddAttachmentRow(DataTable dt, DataRow attachmentRow, string suffix)
        {
            Guid attachid = (Guid) attachmentRow["ID"];

            dt.Rows[0]["AttachmentID"] = attachid;
            dt.Rows[0]["TaskID"] = attachmentRow["TaskID"];
            dt.Rows[0]["AttachmentDate"] = Globals.GetDateString(attachmentRow["Date"]);

            string fileName = "NoName";
            if (!string.IsNullOrEmpty(attachmentRow["FileName"].ToString()))
                fileName = Utils.FileHandler.FormatFileName(attachmentRow["FileName"].ToString());
            if (fileName.Length > 60)
            {
                int fstart = fileName.Length - 59;
                fileName = fileName.Substring(fstart);
            }

            dt.Rows[0]["FileName"] = fileName;

            string location = "attachments\\" + attachmentRow["ID"].ToString();
            string filePath = location + "\\" + fileName;

            string altlocation = attachmentRow["ID"].ToString();
            string altfilepath = altlocation + "\\" + fileName;

            dt.Rows[0]["Location"] = altfilepath;

            ProcessAttachments(attachid, location, filePath, suffix);
            this.Lines.Append(this.RowToString(dt));

            ++this.Count;
        }


        private void ProcessAttachments(Guid attachid, string location, string filename, string suffix)
        {
            //string execString = string.Format("SELECT Data FROM TaskAttachments Where Id = '{0}'", attachid);

            //byte[] image;
            //image = (byte[])HSDBInterfaceManager.RunExecuteScalar(Globals.commProvider, execString);

            //bug 17404 - to add blob storage support.
            byte[] image = null;

            try
            {
                HSDBTableSpecs ts = new HSDBTableSpecs();
                ts.IsStoredProcedure = true;
                ts.SelectSql = "%HS.BS.Get.TaskAttachments" + suffix + ".Data";
                ts.AddParameter("PK_ID", attachid, ParamValueType.vtNativeID, ParameterDirection.Input);
                ts.CommandTimeout = 0;
                HSDBSqlParam pData = ts.AddOutputParameter("BlobData", ParamValueType.vtImage);

                HSDBInterfaceManager.RunExecuteNonQueryMulti(Globals.commProvider, new HSDBTableSpecs[] { ts }, false);

                if (pData.Value != DBNull.Value)
                    image = (byte[])pData.Value;
                else
                    image = new byte[0];

                string tempFileName = Path.GetTempFileName();

                Utils.FileHandler.WriteToFile(tempFileName, image);
                Directory.CreateDirectory(location);
                //Task Attachments are always compressed
                try
                {
                    Utils.FileHandler.DecompressAttachmentFile(tempFileName, filename);
                }
                catch
                {
                    Utils.FileHandler.WriteToFile(filename, image);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
	}
}