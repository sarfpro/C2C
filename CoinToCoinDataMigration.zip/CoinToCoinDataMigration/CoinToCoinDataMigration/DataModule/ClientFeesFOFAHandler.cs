﻿using System;
using System.IO;
using System.Data;
using System.Text;
using System.Collections.Generic;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.DataModule
{

    public class ClientFeesFOFAHandler : ITableHandler
    {
        public ClientFeesFOFAHandler()
        {
            //
            // TODO: Add constructor logic here
            //
            this.Description = "Client Fees - FOFA";
            this.Code = "CF";
            this.DataRelated = DataRelatedEnum.Client;
        }

        public override void Import()
        {
            DataView dvPackageEntities = Globals.dsCoinByClient.Tables["PackageEntities"].DefaultView;
            DataView dvPackage = Globals.dsCoinByClient.Tables["Package"].DefaultView;
            DataView dvPackageService = Globals.dsCoinByClient.Tables["PackageService"].DefaultView;
            DataView dvPackagePayment = Globals.dsCoinByClient.Tables["PackagePayment"].DefaultView;
            DataView dvAdditionalService = Globals.dsCoinByClient.Tables["AdditionalService"].DefaultView;

            bool createCSV = false;
            string groupID = this.Importer.CurrentClient.ToString();
            StringBuilder csvlines = new StringBuilder();
            DataTable dt;

            dvPackage.RowFilter = "EntityGroupID='" + groupID + "'";
            if (dvPackage != null && dvPackage.Count > 0)
            {
                for (int i = 0; i < dvPackage.Count; ++i)
                {
                    dt = InitTable();
                    DataRow packageRow = dvPackage[i].Row;

                    dt.Rows[0]["GroupID"] = groupID;
                    dt.Rows[0]["LineType"] = "1";
                    dt.Rows[0]["PackageID"] = packageRow["ID"].ToString();
                    dt.Rows[0]["ServiceID"] = "";
                    dt.Rows[0]["ColumnE"] = Globals.NotesTextConverter(packageRow["Name"]);
                    dt.Rows[0]["ColumnF"] = Globals.NotesTextConverter(packageRow["Description"]);
                    dt.Rows[0]["ColumnG"] = Globals.NotesTextConverter(packageRow["Comment"]);
                    dt.Rows[0]["ColumnH"] = Globals.NotesTextConverter(packageRow["IsPercentFee"]);
                    dt.Rows[0]["ColumnI"] = Globals.NotesTextConverter(packageRow["Percentage"]);
                    dt.Rows[0]["ColumnJ"] = packageRow["InvAmount"];
                    dt.Rows[0]["ColumnK"] = packageRow["Price"];
                    dt.Rows[0]["ColumnL"] = Globals.NotesTextConverter(packageRow["Indicative"]);
                    dt.Rows[0]["ColumnM"] = Globals.NotesTextConverter(packageRow["Status"]);
                    dt.Rows[0]["ColumnN"] = Globals.GetDateString(packageRow["ServiceAcceptDate"]);
                    dt.Rows[0]["ColumnO"] = Globals.GetDateString(packageRow["PeriodStart"]);
                    dt.Rows[0]["ColumnP"] = Globals.GetDateString(packageRow["PeriodEnd"]);
                    dt.Rows[0]["ColumnQ"] = Globals.GetDateString(packageRow["FDSIssued"]);
                    dt.Rows[0]["ColumnR"] = Globals.GetDateString(packageRow["NextFDSDue"]);
                    dt.Rows[0]["ColumnS"] = Globals.GetDateString(packageRow["EndedDate"]);
                    dt.Rows[0]["ColumnT"] = Globals.NotesTextConverter(packageRow["BillingRef"]);
                    dt.Rows[0]["ColumnU"] = Globals.NotesTextConverter(packageRow["ExtBillRef"]);
                    dt.Rows[0]["Columnv"] = Globals.NotesTextConverter(packageRow["IsSOA"]);
                    if (packageRow.Table.Columns.Contains("DataExtractFlag")) dt.Rows[0]["ColumnW"] = Globals.NotesTextConverter(packageRow["DataExtractFlag"]);
                    if (packageRow.Table.Columns.Contains("DataExtractDate")) dt.Rows[0]["ColumnX"] = Globals.GetDateString(packageRow["DataExtractDate"]);
                    if (packageRow.Table.Columns.Contains("OptinPeriodStart")) dt.Rows[0]["ColumnY"] = Globals.GetDateString(packageRow["OptinPeriodStart"]);
                    if (packageRow.Table.Columns.Contains("NoticeDueDate")) dt.Rows[0]["ColumnZ"] = Globals.GetDateString(packageRow["NoticeDueDate"]);
                    if (packageRow.Table.Columns.Contains("LastNoticeProvidedDate")) dt.Rows[0]["ColumnAA"] = Globals.GetDateString(packageRow["LastNoticeProvidedDate"]);
                    if (packageRow.Table.Columns.Contains("LastAcceptance")) dt.Rows[0]["ColumnAB"] = Globals.NotesTextConverter(packageRow["LastAcceptance"]);
                    if (packageRow.Table.Columns.Contains("LastAcceptanceDate")) dt.Rows[0]["ColumnAC"] = Globals.GetDateString(packageRow["LastAcceptanceDate"]);
                    if (packageRow.Table.Columns.Contains("NewNoticeProvidedDate")) dt.Rows[0]["ColumnAD"] = Globals.GetDateString(packageRow["NewNoticeProvidedDate"]);
                    if (packageRow.Table.Columns.Contains("NewAcceptance")) dt.Rows[0]["ColumnAE"] = Globals.NotesTextConverter(packageRow["NewAcceptance"]);
                    if (packageRow.Table.Columns.Contains("NewAcceptanceDate")) dt.Rows[0]["ColumnAF"] = Globals.GetDateString(packageRow["NewAcceptanceDate"]);


                    dvPackageEntities.RowFilter = "ClientBusinessID='" + packageRow["ID"].ToString() + "'";
                    dt.Rows[0]["ColumnAG"] = "";
                    if (dvPackageEntities != null && dvPackageEntities.Count > 0)
                    {
                        for (int j = 0; j < dvPackageEntities.Count; ++j)
                        { 
                            dt.Rows[0]["ColumnAG"] += dvPackageEntities[j].Row["EntityID"].ToString() + ";";
                        }
                    }

                    csvlines.Append(this.RowToString(dt));
                    this.Lines.Append(this.RowToString(dt));
                    ++Count;
                     
                    dvPackageService.RowFilter = "ClientBusinessID='" + packageRow["ID"].ToString() + "' and EntityGroupID='" + groupID + "'";
                    if (dvPackageService != null && dvPackageService.Count > 0)
                    {
                        for (int k = 0; k < dvPackageService.Count; ++k)
                        {
                            dt = InitTable();
                            DataRow packageServiceRow = dvPackageService[k].Row;
                            
                            dt.Rows[0]["GroupID"] = groupID;
                            dt.Rows[0]["LineType"] = "2";
                            dt.Rows[0]["PackageID"] = packageServiceRow["ClientBusinessID"];
                            dt.Rows[0]["ServiceID"] = packageServiceRow["FOFA_ServiceID"];
                            dt.Rows[0]["ColumnE"] = Globals.NotesTextConverter(packageServiceRow["ServiceName"]);
                            dt.Rows[0]["ColumnF"] = Globals.NotesTextConverter(packageServiceRow["ServiceDescription"]);
                            dt.Rows[0]["ColumnG"] = Globals.NotesTextConverter(packageServiceRow["Comment"]);
                            dt.Rows[0]["ColumnH"] = packageServiceRow["ServicePrice"];
                            dt.Rows[0]["ColumnI"] = Globals.NotesTextConverter(packageServiceRow["Provided"]);
                            dt.Rows[0]["ColumnJ"] = Globals.GetDateString(packageServiceRow["Date"]);
                            dt.Rows[0]["ColumnK"] = Globals.NotesTextConverter(packageServiceRow["Supplement"]);
                            if (packageServiceRow.Table.Columns.Contains("DocOnly")) dt.Rows[0]["ColumnL"] = Globals.NotesTextConverter(packageServiceRow["DocOnly"]);

                            csvlines.Append(this.RowToString(dt));
                            this.Lines.Append(this.RowToString(dt));
                            ++Count;
                        }
                    }

                    dvPackagePayment.RowFilter = "ClientBusinessID='" + packageRow["ID"].ToString() + "' and EntityGroupID='" + groupID + "'";
                    if (dvPackagePayment != null && dvPackagePayment.Count > 0)
                    {
                        for (int k = 0; k < dvPackagePayment.Count; ++k)
                        {
                            dt = InitTable();
                            DataRow packagePaymentRow = dvPackagePayment[k].Row;

                            dt.Rows[0]["GroupID"] = groupID;
                            dt.Rows[0]["LineType"] = "3";
                            dt.Rows[0]["PackageID"] = packagePaymentRow["ClientBusinessID"];
                            dt.Rows[0]["ServiceID"] = "";
                            dt.Rows[0]["ColumnE"] = Globals.NotesTextConverter(packagePaymentRow["Method"]);
                            dt.Rows[0]["ColumnF"] = Globals.NotesTextConverter(packagePaymentRow["PayType"]);
                            dt.Rows[0]["ColumnG"] = Globals.NotesTextConverter(packagePaymentRow["Comment"]);
                            dt.Rows[0]["ColumnH"] = packagePaymentRow["Amount"];
                            dt.Rows[0]["ColumnI"] = Globals.GetDateString(packagePaymentRow["Date"]);
                            dt.Rows[0]["ColumnJ"] = Globals.NotesTextConverter(packagePaymentRow["Ref"]);
                            dt.Rows[0]["ColumnK"] = Globals.NotesTextConverter(packagePaymentRow["Ref2"]);
                            dt.Rows[0]["ColumnL"] = Globals.NotesTextConverter(packagePaymentRow["EntityID"]);
                            dt.Rows[0]["ColumnM"] = Globals.NotesTextConverter(packagePaymentRow["ExtTransID"]);

                            csvlines.Append(this.RowToString(dt));
                            this.Lines.Append(this.RowToString(dt));
                            ++Count;

                        }
                    }
                }

                createCSV = true;
            }

            dvAdditionalService.RowFilter = "EntityGroupID='" + groupID + "'";
            if (dvAdditionalService != null && dvAdditionalService.Count > 0)
            {
                for (int i = 0; i < dvAdditionalService.Count; ++i)
                {
                    dt = InitTable();
                    DataRow additionalServiceRow = dvAdditionalService[i].Row;

                    dt.Rows[0]["GroupID"] = groupID;
                    dt.Rows[0]["LineType"] = "4";
                    dt.Rows[0]["PackageID"] = additionalServiceRow["ID"].ToString();
                    dt.Rows[0]["ServiceID"] = "";
                    dt.Rows[0]["ColumnE"] = Globals.NotesTextConverter(additionalServiceRow["Name"]);
                    dt.Rows[0]["ColumnF"] = Globals.NotesTextConverter(additionalServiceRow["Description"]);
                    dt.Rows[0]["ColumnG"] = Globals.NotesTextConverter(additionalServiceRow["Comment"]);
                    dt.Rows[0]["ColumnH"] = additionalServiceRow["Price"];
                    dt.Rows[0]["ColumnI"] = Globals.NotesTextConverter(additionalServiceRow["Indicative"]);
                    dt.Rows[0]["ColumnJ"] = Globals.GetDateString(additionalServiceRow["DeliveryDate"]);
                    dt.Rows[0]["ColumnK"] = Globals.GetDateString(additionalServiceRow["OfferDate"]);
                    dt.Rows[0]["ColumnL"] = Globals.NotesTextConverter(additionalServiceRow["BillingRef"]);
                    dt.Rows[0]["ColumnM"] = Globals.NotesTextConverter(additionalServiceRow["ExtBillRef"]);
                    if (additionalServiceRow.Table.Columns.Contains("DocOnly")) dt.Rows[0]["ColumnN"] = Globals.NotesTextConverter(additionalServiceRow["DocOnly"]);

                    try
                    {
                        //cb.Price - cf.owing         
                        decimal price = Convert.ToDecimal(additionalServiceRow["Price"]);
                        decimal owing = Convert.ToDecimal(additionalServiceRow["Owing"]);
                        decimal total = price - owing;                        

                        dt.Rows[0]["ColumnO"] = total.ToString();
                    }
                    catch
                    {
                        dt.Rows[0]["ColumnO"] = "0.00";
                    }

                    dvPackageEntities.RowFilter = "ClientBusinessID='" + additionalServiceRow["ID"].ToString() + "'";
                    dt.Rows[0]["ColumnP"] = "";
                    if (dvPackageEntities != null && dvPackageEntities.Count > 0)
                    {
                        for (int j = 0; j < dvPackageEntities.Count; ++j)
                            dt.Rows[0]["ColumnP"] += dvPackageEntities[j].Row["EntityID"].ToString() + ";";
                    }

                    csvlines.Append(this.RowToString(dt));
                    this.Lines.Append(this.RowToString(dt));
                    ++Count;


                    dvPackagePayment.RowFilter = "ClientBusinessID='" + additionalServiceRow["ID"].ToString() + "' and EntityGroupID='" + groupID + "'";
                    if (dvPackagePayment != null && dvPackagePayment.Count > 0)
                    {
                        for (int k = 0; k < dvPackagePayment.Count; ++k)
                        {
                            dt = InitTable();
                            DataRow packagePaymentRow = dvPackagePayment[k].Row;

                            dt.Rows[0]["GroupID"] = groupID;
                            dt.Rows[0]["LineType"] = "3";
                            dt.Rows[0]["PackageID"] = packagePaymentRow["ClientBusinessID"];
                            dt.Rows[0]["ServiceID"] = "";
                            dt.Rows[0]["ColumnE"] = Globals.NotesTextConverter(packagePaymentRow["Method"]);
                            dt.Rows[0]["ColumnF"] = Globals.NotesTextConverter(packagePaymentRow["PayType"]);
                            dt.Rows[0]["ColumnG"] = Globals.NotesTextConverter(packagePaymentRow["Comment"]);
                            dt.Rows[0]["ColumnH"] = packagePaymentRow["Amount"];
                            dt.Rows[0]["ColumnI"] = Globals.GetDateString(packagePaymentRow["Date"]);
                            dt.Rows[0]["ColumnJ"] = Globals.NotesTextConverter(packagePaymentRow["Ref"]);
                            dt.Rows[0]["ColumnK"] = Globals.NotesTextConverter(packagePaymentRow["Ref2"]);
                            dt.Rows[0]["ColumnL"] = Globals.NotesTextConverter(packagePaymentRow["EntityID"]);
                            dt.Rows[0]["ColumnM"] = Globals.NotesTextConverter(packagePaymentRow["ExtTransID"]);

                            csvlines.Append(this.RowToString(dt));
                            this.Lines.Append(this.RowToString(dt));
                            ++Count;

                        }
                    }

                }
                createCSV = true;
            }

            if (createCSV)
            {
                string fileName = "Client Group FoFA Data.CSV";
                string location = "attachments\\" + groupID;
                string path = groupID + "\\" + fileName;    //in AT.CSV, it requires the path in attachments folder.
                string fullpath = "attachments\\" + path;

                Directory.CreateDirectory(location);
                Utils.FileHandler.WriteToFile(fullpath, new string[] { csvlines.ToString() });

                Globals.ClientFeeAttachmentList.Add(groupID, path);
            }
        }

        protected override void InitFields(DataTable dt)
        {
            dt.Columns.Add("GroupID");
            dt.Columns.Add("LineType");
            dt.Columns.Add("PackageID");
            dt.Columns.Add("ServiceID");
            dt.Columns.Add("ColumnE");
            dt.Columns.Add("ColumnF");
            dt.Columns.Add("ColumnG");
            dt.Columns.Add("ColumnH");
            dt.Columns.Add("ColumnI");
            dt.Columns.Add("ColumnJ");
            dt.Columns.Add("ColumnK");
            dt.Columns.Add("ColumnL");
            dt.Columns.Add("ColumnM");
            dt.Columns.Add("ColumnN");
            dt.Columns.Add("ColumnO");
            dt.Columns.Add("ColumnP");
            dt.Columns.Add("ColumnQ");
            dt.Columns.Add("ColumnR");
            dt.Columns.Add("ColumnS");
            dt.Columns.Add("ColumnT");
            dt.Columns.Add("ColumnU");
            dt.Columns.Add("ColumnV");
            dt.Columns.Add("ColumnW");
            dt.Columns.Add("ColumnX");
            dt.Columns.Add("ColumnY");
            dt.Columns.Add("ColumnZ");
            dt.Columns.Add("ColumnAA");
            dt.Columns.Add("ColumnAB");
            dt.Columns.Add("ColumnAC");
            dt.Columns.Add("ColumnAD");
            dt.Columns.Add("ColumnAE");
            dt.Columns.Add("ColumnAF");
            dt.Columns.Add("ColumnAG");
        }

    }
}
