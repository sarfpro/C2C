﻿-------------------------
Setup before Development:
-------------------------

- You need to know the version of Coin
- Change the reference to the correct place referring to the version of Coin

- Current Coin Version: 3.2.2

-------------------------