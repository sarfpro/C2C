using System;
using System.IO;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration.Importer
{
	/// <summary>
	/// Summary description for Importer.
	/// </summary>

	public class Importer
	{
		public Importer()
		{
            SetupTableHandlers();
            SetupAdvisersAndClients();

            this.StartDate = DateTime.MinValue;
            this.EndDate = DateTime.MaxValue;
		}

        private string savePath;
        public string SavePath 
        {
            get{return this.savePath;}
            set
            {
                Globals.SavePath = value;
                this.savePath = value;
            }
        }

        private ArrayList tableHandlers;
        public ArrayList TableHandlers
        {
            get{return this.tableHandlers;}
            set{this.tableHandlers = value;}
        }

        private ArrayList advisers;
        public ArrayList Advisers 
        {
            get{return this.advisers;}
            set{this.advisers = value;}
        }

        private ArrayList clients;
        public ArrayList Clients
        {
            get{return this.clients;}
            set{this.clients = value;}
        }

        private Guid currentClient;
        public Guid CurrentClient
        {
            get{return this.currentClient;}
            set{this.currentClient = value;}
        }

        private Guid currentAdviser;
        public Guid CurrentAdviser
        {
            get { return this.currentAdviser; }
            set { this.currentAdviser = value; }
        }


        public static int TRANSACTION_DATE = 0;
        public static int MODIFIED_DATE = 1;

        private int dateType;
        public int DateType
        {
            get{return this.dateType;}
            set{this.dateType = value;}
        }

        private DateTime startDate;
        public DateTime StartDate 
        {
            get{return this.startDate;}
            set{this.startDate = value;}
        }

        private DateTime endDate;
        public DateTime EndDate
        {
            get{return this.endDate;}
            set{this.endDate = value;}
        }

        private Wait_f waitForm;

        public void BeginImport() 
        {
            waitForm = new Wait_f();
            waitForm.Show();

            int percentage = 0;
            int count = 0;

            // do the non client related table handlers
            for (int i = 0; i < this.tableHandlers.Count; ++i)
            {
                DataModule.ITableHandler tableHandler = (DataModule.ITableHandler)this.tableHandlers[i];
                if (tableHandler.IsMigrated && tableHandler.DataRelated == DataModule.DataRelatedEnum.Other && !tableHandler.Code.Equals("PD") && !tableHandler.Code.Equals("SE"))
                {
                    waitForm.SetMessage("Exporting " + tableHandler.Description);
                    tableHandler.Count = 0;
                    tableHandler.Lines.Length = 0;
                    tableHandler.Importer = this;
                    tableHandler.Import();

                    percentage = (++count) * 100 / this.tableHandlers.Count;
                    waitForm.SetPercentage(percentage);
                }
            }

            if (Directory.Exists(Path.Combine(Environment.CurrentDirectory,"attachments")))
                Directory.Delete("attachments", true);
            //big bug resulting in error for next time!
            if (Directory.Exists(Path.Combine(Environment.CurrentDirectory, "documents")))
                Directory.Delete("documents", true);
            // This is for client
            ImportAdviserAndClientRelatedData(waitForm, percentage, DataModule.DataRelatedEnum.Client);

            // This is for product and service only
            ImportProductService(percentage, count, out percentage, out count);

            // write the result to file for non-adviser related tableHandlers
            for (int j = 0; j < this.tableHandlers.Count; ++j)
            {
                DataModule.ITableHandler tableHandler = (DataModule.ITableHandler)this.tableHandlers[j];
                if (tableHandler.IsMigrated && tableHandler.DataRelated != CoinToCoinDataMigration.DataModule.DataRelatedEnum.Adviser)
                {
                    if (tableHandler.Code != "TA")
                        AddHeaderTrailerToCoinCSV(tableHandler.Code, this.SavePath, tableHandler.Count);
                }
            }

            for (int j = 0; j < this.tableHandlers.Count; ++j)
            {
                DataModule.ITableHandler tableHandler = (DataModule.ITableHandler)this.tableHandlers[j];
                if (tableHandler.Code == "TA")
                {
                    tableHandler.DataRelated = CoinToCoinDataMigration.DataModule.DataRelatedEnum.Adviser;
                }
            }

            ImportAdviserAndClientRelatedData(waitForm, percentage, DataModule.DataRelatedEnum.Adviser);

            // write the result to file for adviser related tableHandlers
            for (int j = 0; j < this.tableHandlers.Count; ++j)
            {
                DataModule.ITableHandler tableHandler = (DataModule.ITableHandler)this.tableHandlers[j];
                if (tableHandler.IsMigrated && tableHandler.DataRelated == CoinToCoinDataMigration.DataModule.DataRelatedEnum.Adviser)
                {
                    if (tableHandler.Code != "TA")
                        AddHeaderTrailerToCoinCSV(tableHandler.Code, this.SavePath, tableHandler.Count);
                }
            }

            for (int j = 0; j < this.tableHandlers.Count; ++j)
            {
                DataModule.ITableHandler tableHandler = (DataModule.ITableHandler)this.tableHandlers[j];
                    if (tableHandler.Code == "TA")
                        AddHeaderTrailerToCoinCSV(tableHandler.Code, this.SavePath, tableHandler.Count);
            }

            Globals.WriteSetupFileToText(this.savePath);
            Globals.WriteSetupFileToXML(this.savePath);

            if (Directory.Exists("attachments"))
            {
                waitForm.SetMessage("moving attachments...");

                if (Globals.ZipFileAttachments)
                    Utils.FileHandler.CompressBinaryFile("attachments", this.SavePath, "COINDM_attachments.zip");

                else
                    Directory.Move(Path.Combine(Environment.CurrentDirectory, "attachments"), Path.Combine(SavePath, "attachments"));
            }

            if (Directory.Exists("documents"))
            {
                waitForm.SetMessage("moving documents...");

                if (Globals.ZipFileAttachments)
                    Utils.FileHandler.CompressBinaryFile("documents", this.SavePath, "COINDM_documents.zip");
                else
                    Directory.Move(Path.Combine(Environment.CurrentDirectory, "documents"), Path.Combine(SavePath, "documents"));
            }

            waitForm.Hide();
            waitForm.Close();
        }

        private void ImportProductService(int percentage, int count, out int percent, out int cou)
        {
            // 11 -> product handler
            // 12 -> service handler
            //for (int i = 9; i < 11; i++)
            for (int i = 11; i < 13; i++)
            {
                // 11th one is product
                DataModule.ITableHandler tableHandler = (DataModule.ITableHandler)this.tableHandlers[i];

                waitForm.SetMessage("Exporting " + tableHandler.Description);
                tableHandler.Count = 0;
                tableHandler.Lines.Length = 0;
                tableHandler.Importer = this;
                tableHandler.Import();

                percentage = (++count) * 100 / this.tableHandlers.Count;
                percent = percentage;
                cou = count;
                waitForm.SetPercentage(percentage);

                // write to csv
                if (tableHandler.Lines.ToString() != string.Empty)
                {
                    Utils.FileHandler.WriteToFile(this.SavePath + "\\" + tableHandler.Code + ".csv", new string[] { tableHandler.Lines.ToString() });
                    tableHandler.Lines.Remove(0, tableHandler.Lines.Length);
                }
            }
            percent = percentage;
            cou = count;
        }

        private void ImportAdviserAndClientRelatedData(Wait_f waitForm, int percentage, DataModule.DataRelatedEnum dataRelated)
        {
            //Clean up the lines and count of client related or adviser table handlers
            for (int j = 0; j < this.tableHandlers.Count; ++j)
            {
                DataModule.ITableHandler tableHandler = (DataModule.ITableHandler)this.tableHandlers[j];

                waitForm.SetMessage("Exporting " + tableHandler.Description);

                if (tableHandler.IsMigrated && (tableHandler.DataRelated == CoinToCoinDataMigration.DataModule.DataRelatedEnum.Client))
                {
                    tableHandler.Count = 0;
                    tableHandler.Lines.Length = 0;
                    tableHandler.Importer = this;
                }

                if (tableHandler.IsMigrated && (tableHandler.DataRelated == CoinToCoinDataMigration.DataModule.DataRelatedEnum.Adviser))
                {
                    if (tableHandler.Code != "TA") //TaskAttachments are for Adviser & Client
                    {
                        tableHandler.Count = 0;
                        tableHandler.Lines.Length = 0;
                    }

                    tableHandler.Importer = this;
                }
            }

            int nbatch = 0;
            int maxCount = 0;

            switch (dataRelated)
            {
                case CoinToCoinDataMigration.DataModule.DataRelatedEnum.Client: 
                        maxCount = this.Clients.Count;
                        break;
                case CoinToCoinDataMigration.DataModule.DataRelatedEnum.Adviser: 
                        maxCount = this.Advisers.Count;
                        break;
            }

            //Clients & Advisers are done in batches of 10
            nbatch = 10;

            for (int i = 0; i < maxCount; i += nbatch)
            {
                ArrayList listIDs = new ArrayList();

                switch (dataRelated)
                {
                    case CoinToCoinDataMigration.DataModule.DataRelatedEnum.Client:
                        BuildIDList(listIDs, DataModule.DataRelatedEnum.Client, nbatch, i);
                        Globals.dsCoinByClient = DataModule.DMExtractor.GetCoinDataSetByClient(listIDs, this.DateType, this.StartDate, this.EndDate);
                        break;
                    case CoinToCoinDataMigration.DataModule.DataRelatedEnum.Adviser:
                        BuildIDList(listIDs, DataModule.DataRelatedEnum.Adviser, nbatch, i);
                        Globals.dsCoinByAdviser = DataModule.DMExtractor.GetCoinDataSetByAdviser(listIDs, this.DateType, this.StartDate, this.EndDate);
                        break;
                }

                for (int j = 0; j < listIDs.Count; ++j)
                {
                    DataRow egRow;

                    switch (dataRelated)
                    {
                        case CoinToCoinDataMigration.DataModule.DataRelatedEnum.Client:
                            egRow = Globals.dsCoinByClient.Tables["EntityGroups"].Rows[j];
                            this.CurrentClient = new Guid(egRow["ID"].ToString());
                            waitForm.SetMessage("Exporting " + egRow["EntityGroupName"]);
                            waitForm.SetTableName((i + j) + " Clients exported");
                            break;
                        case CoinToCoinDataMigration.DataModule.DataRelatedEnum.Adviser:
                            this.CurrentAdviser = new Guid(listIDs[j].ToString());
                            waitForm.SetTableName((i + j) + " Advisers exported");
                            break;
                    }

                    for (int k = 0; k < this.tableHandlers.Count; ++k)
                    {
                        DataModule.ITableHandler tableHandler = (DataModule.ITableHandler)this.tableHandlers[k];

                        if (dataRelated == CoinToCoinDataMigration.DataModule.DataRelatedEnum.Adviser)
                        {
                            if (tableHandler.IsMigrated && (tableHandler.DataRelated == CoinToCoinDataMigration.DataModule.DataRelatedEnum.Adviser))
                                tableHandler.Import();
                        }
                        if (dataRelated == CoinToCoinDataMigration.DataModule.DataRelatedEnum.Client)
                        {
                            if (tableHandler.IsMigrated && (tableHandler.DataRelated == CoinToCoinDataMigration.DataModule.DataRelatedEnum.Client))
                                tableHandler.Import();
                        }

                        if (tableHandler.Lines.ToString() != string.Empty)
                        {
                            Utils.FileHandler.WriteToFile(this.SavePath + "\\" + tableHandler.Code + ".csv", new string[] { tableHandler.Lines.ToString() });
                            tableHandler.Lines.Remove(0, tableHandler.Lines.Length);
                        }
                    }

                    waitForm.SetPercentage(percentage + (i * (100 - percentage) / maxCount));
                }
            }
        }

        private static void AddHeaderTrailerToCoinCSV(string recType, string exportLocationFolderPath, int recNumber)
        {
            string stream = string.Empty;

            Guid g = Guid.NewGuid();
            exportLocationFolderPath = exportLocationFolderPath + "\\";

            string fileNameFrom = exportLocationFolderPath + string.Format("{0}.csv", recType);
            //Create file with a guid in name
            string fileNameTo = exportLocationFolderPath + g.ToString() + string.Format("{0}.csv", recType);

            if (recNumber != 0)
            {
                try
                {
                    using (StreamWriter sw = new StreamWriter(fileNameTo, true, System.Text.Encoding.ASCII))
                    {
                        sw.AutoFlush = true;
                        stream = String.Format("{0},{1},{2}{3}", "Header", recType, recNumber, Environment.NewLine);
                        sw.Write(stream);

                        if (recNumber > 0)
                        {
                            using (StreamReader sr = new StreamReader(fileNameFrom))
                            {
                                for (int i = 0; i < recNumber; i++)
                                {
                                    stream = sr.ReadLine();
                                    sw.Write(stream + Environment.NewLine);
                                }
                            }
                        }

                        stream = String.Format("{0},{1},{2}", "Trailer", recType, recNumber);
                        sw.Write(stream);
                    }

                    File.Delete(fileNameFrom);
                    //Rename file back to original
                    File.Move(fileNameTo, fileNameFrom);
                }
                catch (IOException ex)
                {
                    throw new IOException("Exception occurred during adding the header and trailer of file: " + recType, ex);
                }
            }

        }


        private void BuildIDList(ArrayList listIDs, DataModule.DataRelatedEnum dataRelated, int nbatch, int i)
        {
            int maxCount = 0;

            listIDs.Clear();

            switch (dataRelated)
            {
                case CoinToCoinDataMigration.DataModule.DataRelatedEnum.Client: 
                        maxCount = Math.Min(nbatch, this.Clients.Count - i);
                        for (int j = 0; j < maxCount; ++j)
                        {
                            listIDs.Add(this.Clients[i + j]);
                        }

                        break;
                case CoinToCoinDataMigration.DataModule.DataRelatedEnum.Adviser: 
                    maxCount = Math.Min(nbatch, this.Advisers.Count - i);
                    for (int j = 0; j < maxCount; ++j)
                    {
                        listIDs.Add(this.Advisers[i + j]);
                    }

                    break;
            }
        }

        public void SetupTableHandlers() 
        {
            this.tableHandlers = new ArrayList();
            this.tableHandlers.Add(new DataModule.VersionHandler());
            this.tableHandlers.Add(new DataModule.AdviserHandler());
            this.tableHandlers.Add(new DataModule.ClientHandler());
            this.tableHandlers.Add(new DataModule.ClientFeesFOFAHandler());
            this.tableHandlers.Add(new DataModule.ClientNoteHandler());
			this.tableHandlers.Add(new DataModule.ClientCustomCategoryHandler());
			this.tableHandlers.Add(new DataModule.ClientDependentHandler());
			this.tableHandlers.Add(new DataModule.ClientWillBeneficiariesHandler());
			this.tableHandlers.Add(new DataModule.ClientEstateHandler());
            this.tableHandlers.Add(new DataModule.AttachmentsHandler());
            this.tableHandlers.Add(new DataModule.HoldingHandler());
            this.tableHandlers.Add(new DataModule.ProductHandler());
            this.tableHandlers.Add(new DataModule.ServiceHandler());
            this.tableHandlers.Add(new DataModule.ServiceMappingHandler());
            this.tableHandlers.Add(new DataModule.TransactionHandler());
            this.tableHandlers.Add(new DataModule.TransactionTypeHandler());
            this.tableHandlers.Add(new DataModule.BudgetInfoHandler());
            this.tableHandlers.Add(new DataModule.IrregularExpensesHandler());
            this.tableHandlers.Add(new DataModule.OtherIncomeHandler());
			this.tableHandlers.Add(new DataModule.RiskProfileHandler());
			this.tableHandlers.Add(new DataModule.InsuranceHandler());
            this.tableHandlers.Add(new DataModule.InsuranceOwnerHandler());
            this.tableHandlers.Add(new DataModule.InsuranceOptionAmountHandler());
            this.tableHandlers.Add(new DataModule.ClientTaskHandler());
            this.tableHandlers.Add(new DataModule.ClientTaskAssigneeHandler());
            this.tableHandlers.Add(new DataModule.AdviserTaskHandler());
            this.tableHandlers.Add(new DataModule.AdviserTaskAssigneeHandler());
            this.tableHandlers.Add(new DataModule.TaskAttachmentsHandler());
            this.tableHandlers.Add(new DataModule.DocumentListHandler());
            this.tableHandlers.Add(new DataModule.DocumentsHandler());
            this.tableHandlers.Add(new DataModule.ClientPreferenceHandler());
            this.tableHandlers.Add(new DataModule.ProfessionalAdvisersHandler());
            this.tableHandlers.Add(new DataModule.ProfessionalMappingHandler());
            this.tableHandlers.Add(new DataModule.LoansHandler());
            this.tableHandlers.Add(new DataModule.LifestyleAssetsHandler());
            this.tableHandlers.Add(new DataModule.OtherObjectiveHandler());
        }

        public void SetupAdvisersAndClients() 
        {
            this.Advisers = new ArrayList();
            this.Clients = new ArrayList();
        }

        public override string ToString() 
        {
            string importer = "<Importer>" + Environment.NewLine;
            importer += GetSavePath();
            importer += GetTableHandlers();
            importer += GetAdvisers();
            importer += GetClients();
            importer += "</Importer>" + Environment.NewLine;

            return importer;
        }

        private string GetSavePath() 
        {
            return "  <SavePath>" + this.SavePath + "</SavePath>" + Environment.NewLine;
        }

        private string GetTableHandlers() 
        {
            string tableHandlers = "  <TableHandlers>" + Environment.NewLine;
            foreach (DataModule.ITableHandler tableHandler in this.TableHandlers) 
            {
                if (tableHandler.IsMigrated) 
                {
                    tableHandlers += "    <TableHandler>" + tableHandler + "</TableHandler>" + Environment.NewLine;
                }
            }
            tableHandlers += "  </TableHandlers>" + Environment.NewLine;

            return tableHandlers;
        }

        private string GetAdvisers() 
        {
            string advisers = "  <Advisers>" + Environment.NewLine;
            foreach (Guid adviserID in this.Advisers) 
            {
                advisers += "    <Adviser>" + adviserID.ToString() + "</Adviser>" + Environment.NewLine;
            }

            advisers += "  </Advisers>" + Environment.NewLine;

            return advisers;
        }

        private string GetClients() 
        {
            string clients = "  <Clients>" + Environment.NewLine;
            foreach (Guid egID in this.Clients) 
            {
                clients += "    <Client>" + egID.ToString() + "</Client>" + Environment.NewLine;
            }

            clients += "  </Clients>" + Environment.NewLine;

            return clients;
        }
	}
}