using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using HolisticFS.HSDB;
using CommonUI;
using System.Text;
using System.Linq;

namespace CoinToCoinDataMigration
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Main_f : System.Windows.Forms.Form
	{
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private IContainer components;
        private PinkieControls.ButtonXP btImport;
        private PinkieControls.ButtonXP btClose;
        private System.Windows.Forms.CheckedListBox clInformation;
        private System.Windows.Forms.CheckedListBox clClients;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbPath;
        private PinkieControls.ButtonXP btBrowse;
        private System.Windows.Forms.CheckBox cbInformation;
        private System.Windows.Forms.CheckBox cbClients;
        private System.Windows.Forms.MainMenu mainMenu1;
        private System.Windows.Forms.MenuItem menuItem1;
        private System.Windows.Forms.MenuItem miImport;
        private System.Windows.Forms.MenuItem miSave;
        private System.Windows.Forms.MenuItem miLoad;
        private System.Windows.Forms.MenuItem miClose;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckedListBox clAdvisers;
        private System.Windows.Forms.CheckBox cbAdvisers;

        private Importer.Importer importer;
        private PinkieControls.ButtonXP btRefresh;
        private MenuItem menuItem2;
        private MenuItem btnSpecificEntityGroupIDs;
        private MenuItem menuItem3;
        private MenuItem chkZipFileAttachments;
        private MenuItem productsInHolding;
        private MenuItem mappingControl; 
        private Hashtable htClients;
        private CheckedListBox checkedList;
        private CheckedListBox uncheckedList;
        private MenuItem IncludeDatafeedHoldings;
        private CheckedListBox originalList;
        private MenuItem chkIncludeDeletedEG;
        private Wait_f waitForm;
        private static bool IsSQL =false; //Flag to skip pre-loading

		public Main_f(bool isDisplayed)
		{
			//
			// Required for Windows Form Designer support
			//            
            waitForm = new Wait_f();
            if (isDisplayed) 
            {
                waitForm.Show();            
                waitForm.SetMessage("Initializing COIN Data Set...");
            }

            InitializeGlobals();
			InitializeComponent();
            InitializeForm();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			//Added by Paul Duyker to Ensure that user is loggedout.
			Utils.LoginHandler.DoLogout();
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

        private void InitializeGlobals() 
        {
            Globals.dsCoinGlobals = DataModule.DMExtractor.GetCoinDataSetGlobals();

            // store the version number of the database into global
            Globals.CoinVersion = Globals.dsCoinGlobals.Tables["CoinVersion"].Rows[0][0].ToString();
        }

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_f));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btClose = new PinkieControls.ButtonXP();
            this.btImport = new PinkieControls.ButtonXP();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btRefresh = new PinkieControls.ButtonXP();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.clAdvisers = new System.Windows.Forms.CheckedListBox();
            this.cbAdvisers = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.clClients = new System.Windows.Forms.CheckedListBox();
            this.cbClients = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btBrowse = new PinkieControls.ButtonXP();
            this.tbPath = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cbInformation = new System.Windows.Forms.CheckBox();
            this.clInformation = new System.Windows.Forms.CheckedListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.mainMenu1 = new System.Windows.Forms.MainMenu(this.components);
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.miImport = new System.Windows.Forms.MenuItem();
            this.miSave = new System.Windows.Forms.MenuItem();
            this.miLoad = new System.Windows.Forms.MenuItem();
            this.miClose = new System.Windows.Forms.MenuItem();
            this.menuItem2 = new System.Windows.Forms.MenuItem();
            this.btnSpecificEntityGroupIDs = new System.Windows.Forms.MenuItem();
            this.menuItem3 = new System.Windows.Forms.MenuItem();
            this.chkZipFileAttachments = new System.Windows.Forms.MenuItem();
            this.productsInHolding = new System.Windows.Forms.MenuItem();
            this.mappingControl = new System.Windows.Forms.MenuItem();
            this.IncludeDatafeedHoldings = new System.Windows.Forms.MenuItem();
            this.chkIncludeDeletedEG = new System.Windows.Forms.MenuItem();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(2);
            this.panel1.Size = new System.Drawing.Size(795, 46);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
            this.label1.Location = new System.Drawing.Point(2, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(791, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "Coin To Coin Data Migration";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.btClose);
            this.panel2.Controls.Add(this.btImport);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(2, 762);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(2);
            this.panel2.Size = new System.Drawing.Size(795, 40);
            this.panel2.TabIndex = 1;
            // 
            // btClose
            // 
            this.btClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.btClose.DefaultScheme = true;
            this.btClose.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btClose.Hint = "";
            this.btClose.Image = ((System.Drawing.Image)(resources.GetObject("btClose.Image")));
            this.btClose.Location = new System.Drawing.Point(703, 4);
            this.btClose.Name = "btClose";
            this.btClose.Scheme = PinkieControls.ButtonXP.Schemes.Blue;
            this.btClose.Size = new System.Drawing.Size(88, 32);
            this.btClose.TabIndex = 1;
            this.btClose.Text = "Close";
            this.btClose.Click += new System.EventHandler(this.btClose_Click);
            // 
            // btImport
            // 
            this.btImport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btImport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.btImport.DefaultScheme = true;
            this.btImport.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btImport.Hint = "";
            this.btImport.Image = ((System.Drawing.Image)(resources.GetObject("btImport.Image")));
            this.btImport.Location = new System.Drawing.Point(589, 4);
            this.btImport.Name = "btImport";
            this.btImport.Scheme = PinkieControls.ButtonXP.Schemes.Blue;
            this.btImport.Size = new System.Drawing.Size(112, 32);
            this.btImport.TabIndex = 0;
            this.btImport.Text = "Begin Export";
            this.btImport.Click += new System.EventHandler(this.btImport_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(2, 48);
            this.panel3.Name = "panel3";
            this.panel3.Padding = new System.Windows.Forms.Padding(2);
            this.panel3.Size = new System.Drawing.Size(795, 714);
            this.panel3.TabIndex = 2;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btRefresh);
            this.panel5.Controls.Add(this.groupBox5);
            this.panel5.Controls.Add(this.groupBox2);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(2, 224);
            this.panel5.Name = "panel5";
            this.panel5.Padding = new System.Windows.Forms.Padding(2);
            this.panel5.Size = new System.Drawing.Size(791, 488);
            this.panel5.TabIndex = 1;
            // 
            // btRefresh
            // 
            this.btRefresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.btRefresh.DefaultScheme = true;
            this.btRefresh.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btRefresh.Hint = "";
            this.btRefresh.Location = new System.Drawing.Point(368, 24);
            this.btRefresh.Name = "btRefresh";
            this.btRefresh.Scheme = PinkieControls.ButtonXP.Schemes.Blue;
            this.btRefresh.Size = new System.Drawing.Size(48, 32);
            this.btRefresh.TabIndex = 2;
            this.btRefresh.Text = "Refresh";
            this.btRefresh.Click += new System.EventHandler(this.btRefresh_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.clAdvisers);
            this.groupBox5.Controls.Add(this.cbAdvisers);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox5.ForeColor = System.Drawing.Color.RoyalBlue;
            this.groupBox5.Location = new System.Drawing.Point(2, 2);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(360, 484);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "ADVISERS LIST";
            // 
            // clAdvisers
            // 
            this.clAdvisers.BackColor = System.Drawing.Color.WhiteSmoke;
            this.clAdvisers.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.clAdvisers.CheckOnClick = true;
            this.clAdvisers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.clAdvisers.Location = new System.Drawing.Point(3, 39);
            this.clAdvisers.Name = "clAdvisers";
            this.clAdvisers.Size = new System.Drawing.Size(354, 442);
            this.clAdvisers.Sorted = true;
            this.clAdvisers.TabIndex = 1;
            // 
            // cbAdvisers
            // 
            this.cbAdvisers.BackColor = System.Drawing.Color.Orange;
            this.cbAdvisers.Checked = true;
            this.cbAdvisers.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbAdvisers.Location = new System.Drawing.Point(8, 16);
            this.cbAdvisers.Name = "cbAdvisers";
            this.cbAdvisers.Size = new System.Drawing.Size(16, 24);
            this.cbAdvisers.TabIndex = 4;
            this.cbAdvisers.UseVisualStyleBackColor = false;
            this.cbAdvisers.CheckedChanged += new System.EventHandler(this.cbAdvisers_CheckedChanged);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Orange;
            this.label5.Dock = System.Windows.Forms.DockStyle.Top;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(3, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(354, 23);
            this.label5.TabIndex = 0;
            this.label5.Text = "     Please select the advisers to be migrated:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.clClients);
            this.groupBox2.Controls.Add(this.cbClients);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox2.ForeColor = System.Drawing.Color.RoyalBlue;
            this.groupBox2.Location = new System.Drawing.Point(429, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(360, 484);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "CLIENTS LIST";
            // 
            // clClients
            // 
            this.clClients.BackColor = System.Drawing.Color.WhiteSmoke;
            this.clClients.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.clClients.CheckOnClick = true;
            this.clClients.Dock = System.Windows.Forms.DockStyle.Fill;
            this.clClients.Location = new System.Drawing.Point(3, 39);
            this.clClients.Name = "clClients";
            this.clClients.Size = new System.Drawing.Size(354, 442);
            this.clClients.TabIndex = 1;
            // 
            // cbClients
            // 
            this.cbClients.BackColor = System.Drawing.Color.Orange;
            this.cbClients.Checked = true;
            this.cbClients.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbClients.Location = new System.Drawing.Point(8, 16);
            this.cbClients.Name = "cbClients";
            this.cbClients.Size = new System.Drawing.Size(16, 24);
            this.cbClients.TabIndex = 4;
            this.cbClients.UseVisualStyleBackColor = false;
            this.cbClients.CheckedChanged += new System.EventHandler(this.cbClients_CheckedChanged);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Orange;
            this.label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(3, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(354, 23);
            this.label3.TabIndex = 0;
            this.label3.Text = "     Please select the clients to be migrated:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.groupBox1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(2, 2);
            this.panel4.Name = "panel4";
            this.panel4.Padding = new System.Windows.Forms.Padding(2);
            this.panel4.Size = new System.Drawing.Size(791, 222);
            this.panel4.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.ForeColor = System.Drawing.Color.RoyalBlue;
            this.groupBox1.Location = new System.Drawing.Point(2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(787, 218);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "MIGRATION SETTINGS";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btBrowse);
            this.groupBox4.Controls.Add(this.tbPath);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox4.Location = new System.Drawing.Point(3, 167);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(781, 48);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            // 
            // btBrowse
            // 
            this.btBrowse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btBrowse.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.btBrowse.DefaultScheme = true;
            this.btBrowse.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btBrowse.Hint = "";
            this.btBrowse.Location = new System.Drawing.Point(741, 16);
            this.btBrowse.Name = "btBrowse";
            this.btBrowse.Scheme = PinkieControls.ButtonXP.Schemes.Blue;
            this.btBrowse.Size = new System.Drawing.Size(32, 24);
            this.btBrowse.TabIndex = 2;
            this.btBrowse.Text = "...";
            this.btBrowse.Click += new System.EventHandler(this.btBrowse_Click);
            // 
            // tbPath
            // 
            this.tbPath.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbPath.Location = new System.Drawing.Point(80, 16);
            this.tbPath.Name = "tbPath";
            this.tbPath.Size = new System.Drawing.Size(648, 20);
            this.tbPath.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(8, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 24);
            this.label4.TabIndex = 0;
            this.label4.Text = "Save Path:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cbInformation);
            this.groupBox3.Controls.Add(this.clInformation);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox3.Location = new System.Drawing.Point(3, 16);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(781, 152);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            // 
            // cbInformation
            // 
            this.cbInformation.BackColor = System.Drawing.Color.Orange;
            this.cbInformation.Checked = true;
            this.cbInformation.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbInformation.Location = new System.Drawing.Point(8, 16);
            this.cbInformation.Name = "cbInformation";
            this.cbInformation.Size = new System.Drawing.Size(16, 24);
            this.cbInformation.TabIndex = 3;
            this.cbInformation.UseVisualStyleBackColor = false;
            this.cbInformation.CheckedChanged += new System.EventHandler(this.cbInformation_CheckedChanged);
            // 
            // clInformation
            // 
            this.clInformation.BackColor = System.Drawing.Color.WhiteSmoke;
            this.clInformation.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.clInformation.CheckOnClick = true;
            this.clInformation.ColumnWidth = 150;
            this.clInformation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.clInformation.Location = new System.Drawing.Point(3, 40);
            this.clInformation.MultiColumn = true;
            this.clInformation.Name = "clInformation";
            this.clInformation.Size = new System.Drawing.Size(775, 109);
            this.clInformation.Sorted = true;
            this.clInformation.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Orange;
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(3, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(775, 24);
            this.label2.TabIndex = 0;
            this.label2.Text = "     Please select the information to be migrated:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem1,
            this.menuItem2,
            this.menuItem3});
            // 
            // menuItem1
            // 
            this.menuItem1.Index = 0;
            this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.miImport,
            this.miSave,
            this.miLoad,
            this.miClose});
            this.menuItem1.Text = "File";
            // 
            // miImport
            // 
            this.miImport.Index = 0;
            this.miImport.Shortcut = System.Windows.Forms.Shortcut.CtrlI;
            this.miImport.Text = "Begin Export";
            this.miImport.Click += new System.EventHandler(this.miImport_Click);
            // 
            // miSave
            // 
            this.miSave.Index = 1;
            this.miSave.Shortcut = System.Windows.Forms.Shortcut.CtrlS;
            this.miSave.Text = "Save Settings";
            this.miSave.Click += new System.EventHandler(this.miSave_Click);
            // 
            // miLoad
            // 
            this.miLoad.Index = 2;
            this.miLoad.Shortcut = System.Windows.Forms.Shortcut.CtrlL;
            this.miLoad.Text = "Load Settings";
            this.miLoad.Click += new System.EventHandler(this.miLoad_Click);
            // 
            // miClose
            // 
            this.miClose.Index = 3;
            this.miClose.Shortcut = System.Windows.Forms.Shortcut.CtrlX;
            this.miClose.Text = "Close";
            this.miClose.Click += new System.EventHandler(this.miClose_Click);
            // 
            // menuItem2
            // 
            this.menuItem2.Index = 1;
            this.menuItem2.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.btnSpecificEntityGroupIDs});
            this.menuItem2.Text = "SQL";
            // 
            // btnSpecificEntityGroupIDs
            // 
            this.btnSpecificEntityGroupIDs.Index = 0;
            this.btnSpecificEntityGroupIDs.Text = "EntityGroups Sql Form";
            this.btnSpecificEntityGroupIDs.Click += new System.EventHandler(this.btnSpecificEntityGroupIDs_Click);
            // 
            // menuItem3
            // 
            this.menuItem3.Index = 2;
            this.menuItem3.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.chkZipFileAttachments,
            this.productsInHolding,
            this.mappingControl,
            this.IncludeDatafeedHoldings,
            this.chkIncludeDeletedEG});
            this.menuItem3.Text = "Options";
            // 
            // chkZipFileAttachments
            // 
            this.chkZipFileAttachments.Index = 0;
            this.chkZipFileAttachments.Text = "Zip File Attachments";
            this.chkZipFileAttachments.Click += new System.EventHandler(this.chkZipFileAttachments_Click);
            // 
            // productsInHolding
            // 
            this.productsInHolding.Checked = true;
            this.productsInHolding.Index = 1;
            this.productsInHolding.Text = "Products and Service In Holding";
            this.productsInHolding.Click += new System.EventHandler(this.productsInHolding_Click);
            // 
            // mappingControl
            // 
            this.mappingControl.Index = 2;
            this.mappingControl.Text = "Define Custom Mapping";
            this.mappingControl.Click += new System.EventHandler(this.mappingControl_Click);
            // 
            // IncludeDatafeedHoldings
            // 
            this.IncludeDatafeedHoldings.Index = 3;
            this.IncludeDatafeedHoldings.Text = "Include Datafeed Holdings";
            this.IncludeDatafeedHoldings.Click += new System.EventHandler(this.IncludeDatafeedHoldings_Click);
            // 
            // chkIncludeDeletedEG
            // 
            this.chkIncludeDeletedEG.Index = 4;
            this.chkIncludeDeletedEG.Text = "Include Deleted Entity Groups";
            this.chkIncludeDeletedEG.Click += new System.EventHandler(this.chkIncludeDeletedEG_Click);
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.DefaultExt = "xml";
            this.saveFileDialog.FileName = "settings.xml";
            this.saveFileDialog.Filter = "XML Files (*.xml)|*.xml";
            this.saveFileDialog.FilterIndex = 2;
            // 
            // openFileDialog
            // 
            this.openFileDialog.DefaultExt = "xml";
            this.openFileDialog.FileName = "settings.xml";
            this.openFileDialog.Filter = "XML Files (*.xml)|*.xml";
            this.openFileDialog.FilterIndex = 2;
            // 
            // Main_f
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(799, 804);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Menu = this.mainMenu1;
            this.MinimizeBox = false;
            this.Name = "Main_f";
            this.Padding = new System.Windows.Forms.Padding(2);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Coin Software V4.3+";
            this.Shown += new System.EventHandler(this.Main_f_Shown);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

		}
		#endregion

        private void InitializeForm() 
        {
            originalList = new CheckedListBox();

            this.tbPath.Text = Environment.CurrentDirectory;

            this.clInformation.Items.Clear();
            this.importer = new Importer.Importer();
            foreach (DataModule.ITableHandler tableHandler in this.importer.TableHandlers) 
            {
                this.clInformation.Items.Add(tableHandler, true);
            }
            if (!IsSQL)
            {
            string userFilter = "";
            DataSet dsUsers = HSDBInterfaceManager.RunSelectOneTable(Globals.commProvider, "SELECT ID FROM dbo.fn_GetUserList_IDOnly('" + Globals.commProvider.UserID.ToString() + "')", "Users", false);
            this.clAdvisers.Items.Clear();
            foreach (DataRow row in dsUsers.Tables["Users"].Rows) 
            {
                //DataSet ds = HSDBInterfaceManager.RunSelectOneTable(Globals.commProvider, "SELECT ID, UserName FROM Users WHERE ID='" + row["ID"].ToString() + "'", "Users", false);
                DataSet ds = HSDBInterfaceManager.RunSelectOneTable(Globals.commProvider, "SELECT ug.name, u.ID, CASE WHEN ug.Name IS NULL THEN u.UserName WHEN ug.Name = '' THEN u.UserName ELSE ug.Name + ' - ' + u.UserName end as UserName FROM Users u left join UserGroups ug on u.DefaultGroupID = ug.ID WHERE u.ID='" + row["ID"].ToString() + "'", "Users", false);
                if (ds.Tables["Users"].Rows.Count > 0 && ds.Tables["Users"].Rows[0]["UserName"].ToString().Trim() != "") 
                {
                    DataRow userRow = ds.Tables["Users"].Rows[0];
                    this.clAdvisers.Items.Add(new CheckListItem(userRow["UserName"].ToString(), new Guid(userRow["ID"].ToString())), true);
                    userFilter += ((userFilter != "") ? " OR " : "") + "UserID='" + userRow["ID"].ToString() + "'";
                }
            }
            this.htClients = new Hashtable();
            //DataSet dsEntityGroups = HSDBInterfaceManager.RunSelectOneTable(Globals.commProvider, "SELECT ID FROM dbo.fn_GetClientList_GroupIDOnly(" + Globals.commProvider.UserID.GetAsQuotedString() + ", 0)", "EntityGroups", false);
            //DataSet dsEntityGroups = HSDBInterfaceManager.RunSelectOneTable(Globals.commProvider, "SELECT e.ID, e.EntityGroupName, u.UserName FROM EntityGroups e, Users u WHERE (e.Deleted is null or e.Deleted <> 1) AND (e.UserID=u.ID) AND (" + userFilter + ") ORDER BY u.UserName, e.EntityGroupName", "EntityGroups", false);
            //DataSet dsEntityGroups = HSDBInterfaceManager.RunSelectOneTable(Globals.commProvider, "SELECT e.ID, e.EntityGroupName, u.UserName, e.Deleted FROM EntityGroups e, Users u WHERE (e.Deleted is null or e.Deleted <> 1) AND (e.UserID=u.ID) AND (" + userFilter + ") ORDER BY u.UserName, e.EntityGroupName", "EntityGroups", false);
            DataSet dsEntityGroups;
            if (Globals.IncludeDeletedEG)
            {
                dsEntityGroups = HSDBInterfaceManager.RunSelectOneTable(Globals.commProvider, "SELECT e.ID, e.EntityGroupName, u.UserName, e.Deleted FROM EntityGroups e, Users u WHERE (e.UserID=u.ID) AND (" + userFilter + ") ORDER BY u.UserName, e.EntityGroupName", "EntityGroups", false);
            }
            else
            {
                dsEntityGroups = HSDBInterfaceManager.RunSelectOneTable(Globals.commProvider, "SELECT e.ID, e.EntityGroupName, u.UserName, e.Deleted FROM EntityGroups e, Users u WHERE (e.Deleted is null or e.Deleted <> 1) AND (e.UserID=u.ID) AND (" + userFilter + ") ORDER BY u.UserName, e.EntityGroupName", "EntityGroups", false);
            }

            // get delete clients
            //DataSet dsEntityGroups = HSDBInterfaceManager.RunSelectOneTable(Globals.commProvider, "SELECT e.ID, e.EntityGroupName, u.UserName FROM EntityGroups e, Users u WHERE (e.Deleted = 1) AND (e.UserID=u.ID) AND (" + userFilter + ") ORDER BY u.UserName, e.EntityGroupName", "EntityGroups", false);
            
            int i = 0;
            this.clClients.Items.Clear();
            foreach (DataRow row in dsEntityGroups.Tables["EntityGroups"].Rows)
            {
                if (row["ID"].ToString().Trim() != "") 
                {
                    string line = (row["EntityGroupName"].ToString().Trim() != ""?row["EntityGroupName"].ToString():"[[Missing group name]]") + " - (" + row["UserName"].ToString() + ")";

                    if(row["Deleted"].Equals(true))
                    {
                        line = line + " **Deleted**";
                    }

                    this.clClients.Items.Add(new CheckListItem(line.Trim(), new Guid(row["ID"].ToString())), true);
                    this.originalList.Items.Add(new CheckListItem(line.Trim(), new Guid(row["ID"].ToString())), true);
                    this.htClients[new Guid(row["ID"].ToString())] = i++;
                }
            }
        }
        }

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args) 
        {
            try 
            {
                if (args.Length <=1 && Utils.LoginHandler.DoLoginWithForm()) 
                {
                    if (args.Length == 1 && args.Contains("OnlySQL"))
                        IsSQL = true;

                    Application.Run(new Main_f(true));
                }
                // USAGE: CoinToCoinDataMigration.exe "<<my_profile>>" "<<my_username>>" "<<my_password>>" "settings.xml" "<<TRANSACTION/MODIFIED>>" "<<start_date>>" "<<end_date>>"
                else if ((args.Length >= 3 && args.Length <= 7) && Utils.LoginHandler.DoLoginWithoutForm(args[0], args[1], args[2], true)) 
                {
                    Main_f mainForm = new Main_f(false);
                    if (args.Length >= 4) 
                    {
                        mainForm.LoadSettings(args[3]);
                    }
                    if (args.Length > 5 && (args[4] == "TRANSACTION" || args[4] == "MODIFIED")) 
                    {
                        mainForm.importer.DateType = (args[4] == "TRANSACTION") ? Importer.Importer.TRANSACTION_DATE : Importer.Importer.MODIFIED_DATE;
                        if (args.Length >= 6) 
                        {
                            string[] words = args[5].Split(new char[2] {'/', '-'});
                            int startDay = HolisticFS.GenUtils.SafeConvert.ToInt(words[0]);
                            int startMonth = HolisticFS.GenUtils.SafeConvert.ToInt(words[1]);
                            int startYear = HolisticFS.GenUtils.SafeConvert.ToInt(words[2]);
                            mainForm.importer.StartDate = new DateTime(startYear, startMonth, startDay);
                        }
                        if (args.Length == 7) 
                        {
                            string[] words = args[6].Split(new char[2] {'/', '-'});
                            int endDay = HolisticFS.GenUtils.SafeConvert.ToInt(words[0]);
                            int endMonth = HolisticFS.GenUtils.SafeConvert.ToInt(words[1]);
                            int endYear = HolisticFS.GenUtils.SafeConvert.ToInt(words[2]);
                            mainForm.importer.EndDate = new DateTime(endYear, endMonth, endDay);
                        }
                    }
                    mainForm.BeginImport();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
		}

        private void btBrowse_Click(object sender, System.EventArgs e)
        {
			string path = tbPath.Text;

			FolderBrowserDialog fb = new FolderBrowserDialog();
            	fb.Description = "Please select the path to save CSV files into:";
			if (path.Length > 0 && Directory.Exists(path))
				fb.SelectedPath = path;

			if (fb.ShowDialog() == DialogResult.OK) 
				this.tbPath.Text = fb.SelectedPath;
        }

        private void btClose_Click(object sender, System.EventArgs e)
        {
            Application.Exit();
        }

        private void btImport_Click(object sender, System.EventArgs e)
        {
            //this.importer.SetupTableHandlers();
            Globals.ClientFeeNoteList.Clear();
            Globals.ClientFeeAttachmentList.Clear();

            BeginImport();
        }

        private void BeginImport() 
        {
            if (this.clClients.CheckedItems.Count <= 0 && SQLRecordCount ==0)
            {
                MessageBox.Show("No selected clients to export.");
                return;
            }

            if (!Directory.Exists(this.tbPath.Text))
            {
                MessageBox.Show("folder is not found.");
                return;
            }
            else
            {
                if (File.Exists(this.tbPath.Text + "\\CoinToCoinDataMigration.exe"))
                {
                    MessageBox.Show("please browse to a new folder from the executable folder");
                    return;
                }
                else
                {
                    string[] filePaths = Directory.GetFiles(this.tbPath.Text);
                    foreach (string filePath in filePaths)
                        File.Delete(filePath);

                    string[] dirPaths = Directory.GetDirectories(this.tbPath.Text);
                    foreach (string dirPath in dirPaths)
                        Directory.Delete(dirPath,true);
                }
            }

            this.setEnabled(false);
            
            InitializeImporter();

            this.importer.BeginImport();
            MessageBox.Show("Export has completed successfully", "Information", MessageBoxButtons.OK);
            this.setEnabled(true);

        }

        private void setEnabled(bool enabled) 
        {
            this.clInformation.Enabled = enabled;
            this.clAdvisers.Enabled    = enabled;
            this.clClients.Enabled     = enabled;
            this.btImport.Enabled      = enabled;
            this.btClose.Enabled       = enabled;
        }

        private void InitializeImporter()
        {

            for (int i = 0; i < this.clInformation.Items.Count; ++i)
            {
                DataModule.ITableHandler tableHandler = (DataModule.ITableHandler) this.clInformation.Items[i];
                tableHandler.IsMigrated = this.clInformation.GetItemChecked(i);
            }

            this.importer.SavePath = this.tbPath.Text;

            this.importer.Advisers.Clear();
            if (!IsSQL)
            {
            for (int i = 0; i < this.clAdvisers.Items.Count; ++i)
            {
                if (this.clAdvisers.GetItemChecked(i))
                {
                    this.importer.Advisers.Add((Guid)((CheckListItem)this.clAdvisers.Items[i]).Tag);
                }
            }
            }
            else
            {
                String entUserSQL = "Select Distinct UserID from EntityGroups where ID in (" + frm.Sql + ") and ISNULL(Deleted, 0) = 0";


                DataSet dsWhere = HSDBInterfaceManager.RunSelectOneTable(Globals.commProvider, entUserSQL, "Where", false);

                foreach(DataRow dr in dsWhere.Tables[0].Rows)
                {
                    this.importer.Advisers.Add((Guid)dr[0]);
                }
                
            }
            this.importer.Clients.Clear();

            if (groupBox2.Enabled)
            {
                for (int i = 0; i < this.clClients.Items.Count; ++i)
                {
                    if (this.clClients.GetItemChecked(i))
                    {
                        this.importer.Clients.Add((Guid) ((CheckListItem) this.clClients.Items[i]).Tag);
                    }
                }
            }
            else
            {
                if (frm != null)
                {
                    if (frm.Sql.Trim().Length > 0)
                    {
                        arrWhere = new ArrayList();
                        DataSet dsWhere =
                            HSDBInterfaceManager.RunSelectOneTable(Globals.commProvider, frm.Sql, "Where", false);
                        foreach (DataRow row in dsWhere.Tables["Where"].Rows)
                        {
                            Guid id = new Guid(row["ID"].ToString());
                            arrWhere.Add(id);
                        }
                        Console.WriteLine(arrWhere.Count);
                    }
                }

                importer.Clients = arrWhere;
            }
        }

	    private void cbInformation_CheckedChanged(object sender, System.EventArgs e)
        {
            for (int i = 0; i < this.clInformation.Items.Count; ++i)
            {
                this.clInformation.SetItemChecked(i, this.cbInformation.Checked);
            }
        }

        private void cbAdvisers_CheckedChanged(object sender, System.EventArgs e)
        {
            for (int i = 0; i < this.clAdvisers.Items.Count; ++i) 
            {
                this.clAdvisers.SetItemChecked(i, this.cbAdvisers.Checked);
            }
        }

 
        private void btRefresh_Click(object sender, System.EventArgs e)
        {
            this.cbClients.Checked = false;
            for (int i = 0; i < this.originalList.Items.Count; ++i) 
            {
                this.originalList.SetItemChecked(i, false);
            }
            string userFilter = "";
            foreach (CheckListItem adviser in this.clAdvisers.CheckedItems) 
            {
                Guid adviserID = (Guid) adviser.Tag;
                userFilter += ((userFilter != "") ? " OR " : "") + "UserID='" + adviserID.ToString() + "'";
            }

            if (userFilter.Length > 0)
            {
                checkedList = new CheckedListBox();
                uncheckedList = new CheckedListBox();

                DataSet dsEntityGroups = HSDBInterfaceManager.RunSelectOneTable(Globals.commProvider, "SELECT ID FROM EntityGroups WHERE " + userFilter + " order by UserID", "EntityGroups", false);
                foreach (DataRow row in dsEntityGroups.Tables["EntityGroups"].Rows)
                {
                    Guid clientID = new Guid(row["ID"].ToString());
                    object clientIndex = this.htClients[clientID];

                    if (clientIndex != null && ((int)clientIndex) >= 0)
                        this.originalList.SetItemChecked((int)clientIndex, true);
                }

                for (int i = 0; i < this.originalList.Items.Count; ++i)
                {
                    if (this.originalList.GetItemCheckState(i) == CheckState.Unchecked)
                        uncheckedList.Items.Add(this.originalList.Items[i]);
                    else
                        checkedList.Items.Add(this.originalList.Items[i]);
                }

                //to display all the checked item first in the list.
                clClients.Items.Clear();
                for (int i = 0; i < this.checkedList.Items.Count; ++i)
                {
                    this.clClients.Items.Add(checkedList.Items[i], true);
                }

                for (int i = 0; i < this.uncheckedList.Items.Count; ++i)
                {
                    this.clClients.Items.Add(uncheckedList.Items[i],false);
                }
                clClients.Refresh();
            }
            groupBox2.Text = "CLIENT LIST (" + clClients.CheckedItems.Count.ToString() + ")";
            Globals.ClientFeeNoteList.Clear();
            Globals.ClientFeeAttachmentList.Clear();
           
        }

        private void cbClients_CheckedChanged(object sender, System.EventArgs e)
        {
            for (int i = 0; i < this.clClients.Items.Count; ++i) 
            {
                this.clClients.SetItemChecked(i, this.cbClients.Checked);
            }
        }

        private void miClose_Click(object sender, System.EventArgs e)
        {
            btClose_Click(sender, e);
        }

        private void miImport_Click(object sender, System.EventArgs e)
        {
            btImport_Click(sender, e);
        }

        private void miSave_Click(object sender, System.EventArgs e)
        {
            if (saveFileDialog.ShowDialog() == DialogResult.OK) 
            {
                InitializeImporter();
                Utils.FileHandler.WriteToFile(saveFileDialog.FileName, new string[] {importer.ToString()});
            }
        }

        private void miLoad_Click(object sender, System.EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK) 
            {
                try 
                {
                    LoadSettings(openFileDialog.FileName);
                } 
                catch (Exception ex) 
                {
                    MessageBox.Show(ex.ToString());
                }
            }
        }

        private void LoadSettings(string fileName)
        {
            DataSet ds = new DataSet();
            ds.ReadXml(fileName, XmlReadMode.Auto);

            string savePath = ds.Tables["Importer"].Rows[0][0].ToString();
            this.tbPath.Text = savePath;

            // table handlers
            for (int i = 0; i < this.clInformation.Items.Count; ++i)
            {
                this.clInformation.SetItemChecked(i, false);
            }
            if (ds.Tables["TableHandler"] != null)
            {
                foreach (DataRow row in ds.Tables["TableHandler"].Rows)
                {
                    for (int i = 0; i < this.clInformation.Items.Count; ++i)
                    {
                        DataModule.ITableHandler tableHandler = (DataModule.ITableHandler) this.clInformation.Items[i];
                        if (row[0].ToString() == tableHandler.ToString())
                        {
                            this.clInformation.SetItemChecked(i, true);
                        }
                    }
                }
            }
            else
            {
                for (int i = 0; i < this.clInformation.Items.Count; ++i)
                {
                    DataModule.ITableHandler tableHandler = (DataModule.ITableHandler) this.clInformation.Items[i];
                    if (ds.Tables["TableHandlers"] != null &&
                        ds.Tables["TableHandlers"].Rows[0][0].ToString() == tableHandler.ToString())
                    {
                        this.clInformation.SetItemChecked(i, true);
                    }
                }
            }
            // advisers
            for (int i = 0; i < this.clAdvisers.Items.Count; ++i)
            {
                this.clAdvisers.SetItemChecked(i, false);
            }
            if (ds.Tables["Adviser"] != null)
            {
                foreach (DataRow row in ds.Tables["Adviser"].Rows)
                {
                    for (int i = 0; i < this.clAdvisers.Items.Count; ++i)
                    {
                        Guid tag = (Guid) ((CheckListItem) this.clAdvisers.Items[i]).Tag;
                        if (row[0].ToString() == tag.ToString())
                        {
                            this.clAdvisers.SetItemChecked(i, true);
                        }
                    }
                }
            }
            else
            {
                for (int i = 0; i < this.clAdvisers.Items.Count; ++i)
                {
                    Guid tag = (Guid)((CheckListItem)this.clAdvisers.Items[i]).Tag;
                    if (ds.Tables["Advisers"] != null && ds.Tables["Advisers"].Rows[0][0].ToString() == tag.ToString())
                    {
                        this.clAdvisers.SetItemChecked(i, true);
                    }
                }
            }
            // clients

            for (int i = 0; i < this.clClients.Items.Count; ++i)
            {
                this.clClients.SetItemChecked(i, false);
            }
            if (ds.Tables["Client"] != null)
            {
                foreach (DataRow row in ds.Tables["Client"].Rows)
                {
                    for (int i = 0; i < this.clClients.Items.Count; ++i)
                    {
                        Guid tag = (Guid)((CheckListItem)this.clClients.Items[i]).Tag;
                        if (row[0].ToString() == tag.ToString())
                        {
                            this.clClients.SetItemChecked(i, true);
                        }
                    }
                }
            }
            else
            {
                for (int i = 0; i < this.clClients.Items.Count; ++i)
                {
                    Guid tag = (Guid)((CheckListItem)this.clClients.Items[i]).Tag;
                    if (ds.Tables["Clients"] != null && ds.Tables["Clients"].Rows[0][0].ToString() == tag.ToString())
                    {
                        this.clClients.SetItemChecked(i, true);
                    }
                }
            }
        }

	    private ArrayList arrWhere;
	    private SqlForm frm;
        private double SQLRecordCount = 0;
        private void btnSpecificEntityGroupIDs_Click(object sender, EventArgs e)
        {
            btnSpecificEntityGroupIDs.Checked = !btnSpecificEntityGroupIDs.Checked;
            if(btnSpecificEntityGroupIDs.Checked)
            {
               frm = new SqlForm();

                if(frm.ShowDialog() == DialogResult.OK)
                {

                    String entGroupNamesSQL = "select EntityGroupName from EntityGroups where ID in (" + frm.Sql + ") and ISNULL(Deleted, 0) = 0";
      

                    DataSet dsWhere = HSDBInterfaceManager.RunSelectOneTable(Globals.commProvider, entGroupNamesSQL, "Where", false);

                    SQLRecordCount = dsWhere.Tables["Where"].Rows.Count;

                    if(SQLRecordCount > 0)
                    {
                        this.cbAdvisers.Checked = false;
                        this.cbClients.Checked = false;

                        this.groupBox2.Enabled = false;
                        this.groupBox5.Enabled = false;

                        this.btImport.Focus();
                    }

                    MessageBox.Show(String.Format("Extracting {0} Records", SQLRecordCount), "Entity groups to be extracted", MessageBoxButtons.OK);
                }
                else
                {
                    this.groupBox2.Enabled = true;
                    this.groupBox5.Enabled = true;
                }
            }
            else
            {
                this.groupBox2.Enabled = true;
                this.groupBox5.Enabled = true;
            }
        }

        private void chkZipFileAttachments_Click(object sender, EventArgs e)
        {
            Globals.ZipFileAttachments = chkZipFileAttachments.Checked = !chkZipFileAttachments.Checked;
        }

        private void productsInHolding_Click(object sender, EventArgs e)
        {
            Globals.ProductsInHolding = productsInHolding.Checked = !productsInHolding.Checked;
            Globals.ServiceInSM = productsInHolding.Checked;
        }

        private void mappingControl_Click(object sender, EventArgs e)
        {
            MappingControl mapform = new MappingControl();
            mapform.FormClosed += mapform_Closed;
            mapform.Show();
        }

        private void mapform_Closed(object sender, FormClosedEventArgs e)
        {
            var form = sender as MappingControl;
            form.FormClosed -= mapform_Closed;      //unhook the event handler

            if (CommonUI.MappingControl.CustomMapping)
                mappingControl.Checked = true;
            else
                mappingControl.Checked = false;
        }

        private void IncludeDatafeedHoldings_Click(object sender, EventArgs e)
        {
            IncludeSelectedDatafeed includeSelectedDatafeedform = new IncludeSelectedDatafeed();
            includeSelectedDatafeedform.FormClosed += includeSelectedDatafeedform_Closed;
            includeSelectedDatafeedform.Show();
        }

        private void includeSelectedDatafeedform_Closed(object sender, FormClosedEventArgs e)
        {
            var form = sender as IncludeSelectedDatafeed;
            form.FormClosed -= includeSelectedDatafeedform_Closed; //unhook the event handler

            if (Globals.IncludedDatafeedList.ContainsValue("TRUE"))
                IncludeDatafeedHoldings.Checked = true;
            else
                IncludeDatafeedHoldings.Checked = false;
        }

        private void Main_f_Shown(object sender, EventArgs e)
        {
            waitForm.Hide();
        }

        private void chkIncludeDeletedEG_Click(object sender, EventArgs e)
        {
            Globals.IncludeDeletedEG = chkIncludeDeletedEG.Checked = !chkIncludeDeletedEG.Checked;
            //btRefresh.PerformClick();
            InitializeForm();
        }
    }

    public class CheckListItem
    {
        private string description;
        public string Description
        {
            get{return this.description;}
            set{this.description = value;}
        }

        private object tag;
        public object Tag
        {
            get{return this.tag;}
            set{this.tag = value;}
        }

        public CheckListItem(string description, object tag) 
        {
            this.description = description;
            this.tag = tag;
        }

        public override string ToString() 
        {
            return this.Description;
        }
    }
}
