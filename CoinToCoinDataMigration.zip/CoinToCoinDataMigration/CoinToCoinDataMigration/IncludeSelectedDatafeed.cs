﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Reflection;
using System.Xml;
using System.Diagnostics;
using System.Configuration;
//using CoinDataConversionsIO;
using CommonUtility;
using HolisticFS.HSDB;

namespace CoinToCoinDataMigration
{
    public partial class IncludeSelectedDatafeed : Form
    {
        private BindingSource bindingSource1 = new BindingSource();

        public IncludeSelectedDatafeed()
        {
            InitializeComponent();

            btnSaveChange.Enabled = false;

            //dataGridViewDatafeed.Rows.Clear();
            viewCheckedDatafeed.Items.Clear();
        }

        private void btnLoadFromDB_Click(object sender, EventArgs e)
        {
            try
            {
                //dataGridViewDatafeed.DataSource = null;
                //dataGridViewDatafeed.Rows.Clear();
               
                HSDBTableSpecs[] tsCoin = HSDBTableSpecs.NewArray(1);

                int i = 0;
                tsCoin[i].TableName = "P_ASSETS";
                tsCoin[i++].SelectSql = @"select distinct AS_SOURCE from P_ASSETS order by AS_SOURCE";

                DataSet dsCoin = HSDBInterfaceManager.RunSelect(Globals.commProvider, tsCoin, false);

                //dataGridViewDatafeed.AutoGenerateColumns = true;
                //dataGridViewDatafeed.DataSource = dsCoin.Tables[0];

                viewCheckedDatafeed.Items.Clear();
                foreach (DataRow dr in dsCoin.Tables[0].Rows)
                {
                    if (dr["AS_SOURCE"] != null)
                    {
                        viewCheckedDatafeed.Items.Add(dr["AS_SOURCE"].ToString(), true);
                        if (btnSaveChange.Enabled == false)
                            btnSaveChange.Enabled = true;
                    }
                }                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "btnLoadFromDB_Click");
                //throw;
            }
        }

        private void btnSaveChange_Click(object sender, EventArgs e)
        {
            try
            {
                Globals.IncludedDatafeedList.Clear();

                if (viewCheckedDatafeed.Items.Count > 0)
                {
                    for (int i = 0; i <= viewCheckedDatafeed.Items.Count - 1; i++)
                    {
                        if (viewCheckedDatafeed.Items[i] != null)
                        {
                            if (viewCheckedDatafeed.GetItemChecked(i)) 
                            {
                                Globals.IncludedDatafeedList.Add(viewCheckedDatafeed.Items[i].ToString(), "TRUE");                                
                            }
                            else
                            {
                                Globals.IncludedDatafeedList.Add(viewCheckedDatafeed.Items[i].ToString(), "FALSE");
                            }
                        }
                    }


                    if (Globals.IncludedDatafeedList != null && Globals.IncludedDatafeedList.Count > 0)
                        MessageBox.Show("Save checked item(s) in caching", "Save");
                }
                else
                {
                    MessageBox.Show("No datafeed is available", "Save");
                }

                Globals.IncludeDatafeedHoldings = Globals.IncludedDatafeedList.ContainsValue("TRUE");
                Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "btnSave_Click");
                //throw;
            }
        }
    }
}
