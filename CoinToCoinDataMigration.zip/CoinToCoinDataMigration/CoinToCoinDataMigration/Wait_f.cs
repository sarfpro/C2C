using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CoinToCoinDataMigration
{
	/// <summary>
	/// Summary description for Wait_f.
	/// </summary>
	public class Wait_f : System.Windows.Forms.Form
	{
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbTableName;
        private System.Windows.Forms.Label lbMessage;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.Label lbPercentage;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Wait_f()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbMessage = new System.Windows.Forms.Label();
            this.lbTableName = new System.Windows.Forms.Label();
            this.lbPercentage = new System.Windows.Forms.Label();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbMessage);
            this.panel2.Controls.Add(this.lbTableName);
            this.panel2.Controls.Add(this.lbPercentage);
            this.panel2.Controls.Add(this.progressBar);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(2, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(288, 92);
            this.panel2.TabIndex = 2;
            // 
            // lbMessage
            // 
            this.lbMessage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbMessage.Location = new System.Drawing.Point(8, 64);
            this.lbMessage.Name = "lbMessage";
            this.lbMessage.Size = new System.Drawing.Size(272, 23);
            this.lbMessage.TabIndex = 3;
            this.lbMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbTableName
            // 
            this.lbTableName.Location = new System.Drawing.Point(8, 32);
            this.lbTableName.Name = "lbTableName";
            this.lbTableName.Size = new System.Drawing.Size(208, 23);
            this.lbTableName.TabIndex = 2;
            // 
            // lbPercentage
            // 
            this.lbPercentage.Location = new System.Drawing.Point(224, 32);
            this.lbPercentage.Name = "lbPercentage";
            this.lbPercentage.Size = new System.Drawing.Size(56, 24);
            this.lbPercentage.TabIndex = 1;
            this.lbPercentage.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(8, 8);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(272, 16);
            this.progressBar.TabIndex = 0;
            // 
            // Wait_f
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(292, 96);
            this.Controls.Add(this.panel2);
            this.DockPadding.All = 2;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Wait_f";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Please Wait";
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }
		#endregion

        public void SetMessage(string message) 
        {
            this.lbMessage.Text = message;
            Application.DoEvents();
        }

        public void SetTableName(string tableName) 
        {
            this.lbTableName.Text = tableName;
            Application.DoEvents();
        }

        public void SetPercentage(int percentage) 
        {
            if (percentage >= 0 && percentage <= 100) 
            {
                this.progressBar.Value = percentage;
                this.lbPercentage.Text = percentage.ToString() + "%";
                Application.DoEvents();
            }
        }
	}
}
