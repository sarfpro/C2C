using System;
using System.Windows.Forms;
using HolisticFS.HSDB;
using HolisticFS.HSDB.App;

namespace CoinToCoinDataMigration.Utils
{
	/// <summary>
	/// Summary description for LoginHandler.
	/// </summary>
	public class LoginHandler
	{
		public LoginHandler()
		{
			//
			// TODO: Add constructor logic here
			//
		}

        public static bool DoLoginWithForm() 
        {
            bool loggedIn = false;
            try
            {
                HolisticFS.HSDB.App.LoginForm.LoginFormOptions opts =
                    new HolisticFS.HSDB.App.LoginForm.LoginFormOptions();
                HSDBCommProvider commProvider = new HSDBCommProvider();
                loggedIn = HolisticFS.HSDB.App.LoginForm.DoConnectAndLogin(opts, commProvider);
                if (loggedIn) 
                {
                    Globals.commProvider = commProvider;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Configuration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);				
            }

            return loggedIn;
        }

		//Added by Paul Duyker to Ensure that user logouts out after application completes/closes.
		public static void DoLogout()
		{
			ConnectAndAutoLogin.DoLogoutAndDisconnect(Globals.commProvider);
		}

        public static bool DoLoginWithoutForm(string profile, string user, string password, bool force)
        {
            //HSDBInterfaceManager.GlobalClientTimeout = 30 * 60 * 1000; // 30 minutes timeout
            HSDBInterfaceManager.GlobalClientTimeout = 60 * 60 * 1000; // 60 minutes timeout ? 
            ConnectAndAutoLogin.ConnectAndLoginOptions opts = new ConnectAndAutoLogin.ConnectAndLoginOptions();

            if (!opts.FillConnectionOptionsFromProfile(profile))
                throw new ApplicationException("Profile \"" + profile + "\"can't be found");

            opts.StateSaver = new HSDBStateSaverForWinApp();
            opts.UserID = user;
            opts.Password = password;
            HSDBCommProvider commProvider = new HSDBCommProvider();

            int serverLoginOptions = (force ? DoLoginOptions.optSkipCheckForPreviousLogin : 0);
            LoginResult res = ConnectAndAutoLogin.DoConnectAndLogin2(opts, serverLoginOptions, out commProvider);

            if (res.ResultCode == LoginResultEnum.UserAlreadyLoggedIn)
            {
                throw new ApplicationException(
                    "Already logged in." + Environment.NewLine + "Profile:\t" + profile + Environment.NewLine + "User:\t" + user,
                    new Exception());
            }
            else if (res.ResultCode != LoginResultEnum.OK)
            {
                throw new ApplicationException(
                    "Could not login." + Environment.NewLine + Environment.NewLine + "Profile:\t" + profile + Environment.NewLine + "User:\t" + user);
            }
            Globals.commProvider = commProvider;

            return true;
        }
	}
}