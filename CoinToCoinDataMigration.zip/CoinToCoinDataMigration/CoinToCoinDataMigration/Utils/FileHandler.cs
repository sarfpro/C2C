using System;
using System.IO;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using CoinDataConversionsIO;
using NZlib.Zip;
//using ConversionTools;

namespace CoinToCoinDataMigration.Utils
{
	/// <summary>
	/// Summary description for FileHandler.
	/// </summary>
	public class FileHandler
	{
		public FileHandler()
		{
			//
			// TODO: Add constructor logic here
			//
		}

        public static void WriteToFile(string fileName, string[] lines) 
        {
            StreamWriter writer = null;
            try
            {
                writer = new StreamWriter(fileName, true);
                foreach (string line in lines) 
                {
                    writer.Write(line);
                }
            } 
            catch (Exception e) 
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                if (writer != null)
                    writer.Close();
            }
        }

        public static void WriteToFile(string fileName, byte[] bytes) 
        {
            FileStream fileStream   = new FileStream(fileName, FileMode.Create, FileAccess.Write);
            try
            {
                fileStream.Write(bytes, 0, bytes.Length);
            } 
            catch (Exception e) 
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                fileStream.Close();
            }
        }

        public static void DecompressAttachmentFile (string srcfilename, string destfilename) 
        {			
            if (!File.Exists(srcfilename))
                return;

            NZlib.Streams.InflaterInputStream iis = null;
            FileStream decompressedfs = null;
            FileStream inStream = null;
            try 
            {
                int BUFSIZE = 16 * 1024; // 16kb chunks
                byte[] buf = new byte[BUFSIZE];

                if (string.IsNullOrEmpty(destfilename))
                    destfilename = "NoName";
                //else
                //    destfilename = IOTools.CleanFileName(destfilename);

                decompressedfs = new FileStream(destfilename, FileMode.OpenOrCreate, FileAccess.Write);
                inStream = new FileStream(srcfilename, FileMode.Open);

                if (inStream.Length > 0)
                {
                    iis = new NZlib.Streams.InflaterInputStream(inStream);

                    while (true)
                    {
                        int readsize = iis.Read(buf, 0, buf.Length);
                        if (readsize <= 0)
                            break;

                        decompressedfs.Write(buf, 0, readsize);
                    }

                    iis.Flush();
                    decompressedfs.Flush();
                }
            } 
            catch (Exception e) 
            {
                //MessageBox.Show(e.ToString() + " " + e.StackTrace);
                throw e;
            }
            finally 
            {
                if (iis != null) 
                    iis.Close();

                if (decompressedfs != null) 
                    decompressedfs.Close();

                if (inStream != null)
                    inStream.Close();

                if (File.Exists(srcfilename))
                    File.Delete(srcfilename);
            }
        }

        public static void CompressBinaryFile(string sourceDirectory, string srcpath, string destfilename) 
        {
            if (!Directory.Exists(sourceDirectory))
                return;
            
            ZipOutputStream s = new ZipOutputStream(File.Create(srcpath + "\\" + destfilename));
            string[] directories = Directory.GetDirectories(sourceDirectory);

            try 
            {	
                s.SetLevel(5); // 0 - store only to 9 - means best compression
            		
                foreach (string directory in directories) 
                {
                    string[] filenames = Directory.GetFiles(directory);

                    foreach (string filename in filenames) 
                    {
                        FileStream fs = File.OpenRead(filename);            			
                        byte[] buffer = new byte[fs.Length];
                        fs.Read(buffer, 0, buffer.Length);
            			
                        ZipEntry entry = new ZipEntry(filename);
                        s.PutNextEntry(entry);
                        s.Write(buffer, 0, buffer.Length);
                        fs.Close(); //big bug!
                    }
                }
            } 
            catch (Exception e) 
            {
                MessageBox.Show(e.ToString());
            }
            finally 
            {
                s.Finish();
                s.Close();
            }
        }

        public static string FormatFileName(string uncleanFileName)
        {
            //return IOTools.CleanInvalidFileName(uncleanFileName);
            return IOTools.CleanFileName(uncleanFileName);
            //special WBC version to clean out everything that is not a-z and 0-9 and "."
            //string result = Regex.Replace(uncleanFileName, "[^{A-Z} ^{a-z} ^{0-9}.]", "", RegexOptions.Compiled);
            //return result;
        }
	}
}
