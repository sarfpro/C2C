using System;
using System.Windows.Forms;

namespace CoinToCoinDataMigration
{
    public partial class SqlForm : Form
    {
        public SqlForm()
        {
            InitializeComponent();
        }

        private string sql;

        public string Sql
        {
            get { return sql; }
            set { sql = value; }
        }


        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim().Length > 0)
            {
                sql = textBox1.Text.Trim();
                DialogResult = System.Windows.Forms.DialogResult.OK;
            }
        }
    }
}